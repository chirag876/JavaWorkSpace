package com.acme.Repository;//package com.acme.Repository;
//
//import com.acme.Entity.Item;
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
//import org.springframework.stereotype.Repository;
//
//
//public interface ItemRepository extends ReactiveMongoRepository<Item, Integer> {
//
//}
//
