package com.acme.Enum;

public enum OrderStatus {
    PENDING,
    CANCELLED,
    CREATED
}