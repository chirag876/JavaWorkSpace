package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Lead;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ILead {
    public Lead AddLead(Lead lead);

    public List<Lead> GetList();

    public Lead GetById(String id);

    public Lead Update(Lead lead);

    public String Delete(String id);
}
