package com.datapulse.Application.Lead.Request;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteLeadRequest implements Request<String> {
    private String id;
}
