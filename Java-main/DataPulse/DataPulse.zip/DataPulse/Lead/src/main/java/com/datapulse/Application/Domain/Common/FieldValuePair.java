package com.datapulse.Application.Domain.Common;

import lombok.Data;

@Data
public  class  FieldValuePair {
    private String fieldName;
    private Object value;

    public FieldValuePair(String fieldName, Object value) {
        this.fieldName = fieldName;
        this.value = value;
    }

    public String getFieldName() {
        return fieldName;
    }

    public Object getValue() {
        return value;
    }
}
