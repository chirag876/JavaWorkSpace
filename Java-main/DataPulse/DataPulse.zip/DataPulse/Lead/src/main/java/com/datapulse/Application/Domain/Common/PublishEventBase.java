package com.datapulse.Application.Domain.Common;

import lombok.Data;

import java.util.Date;

@Data
public abstract class  PublishEventBase {
    public String EventName;
    public String OperationType;
    public Date OperationDateTimeUtc;
    public String OperationSource ;
    public String ApiName;
}
