package com.datapulse.Application.Lead.Query.GetLead;

import lombok.Data;

import java.util.List;

@Data

public class LeadVm {
    public List<LeadDTO> leadList;

    public LeadVm(){}

    public LeadVm(List<LeadDTO> leadList) {
        this.leadList = leadList;
    }

    public List<LeadDTO> getLeadList() {
        return leadList;
    }

    public void setOpportunityList(List<LeadDTO> leadList) {
        this.leadList = leadList;
    }


}
