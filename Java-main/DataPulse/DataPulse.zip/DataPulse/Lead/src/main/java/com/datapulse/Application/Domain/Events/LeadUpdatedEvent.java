package com.datapulse.Application.Domain.Events;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Lead;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
@AllArgsConstructor

public class LeadUpdatedEvent implements Notification {
    private Lead lead;

    Logger logger = LoggerFactory.getLogger(LeadCreatedEvent.class);
    public LeadUpdatedEvent(Lead opportunity){

        this.lead = opportunity;

        logger.info(" LeadUpdatedEvent: " + lead);
    }

    public LeadUpdatedEvent() {

    }
}
