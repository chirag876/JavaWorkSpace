package com.datapulse.Application.Lead.Query.QueryHandlers;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Lead.Query.GetLead.GetLeadQuery;
import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.Application.Lead.Query.GetLead.LeadVm;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class LeadQueryHandler implements RequestHandler<GetLeadQuery, LeadVm> {

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private ILead _dataAcces;
    @Override
    public UUID uhandle(GetLeadQuery request) {
        return null;
    }

    @Override
    public LeadVm handle(GetLeadQuery request) {
       LeadVm leadVm = new LeadVm();
        leadVm.setLeadList(mapper.map(_dataAcces.GetList(), new TypeToken<List<LeadDTO>>() {}.getType()));
        return leadVm;
    }
}
