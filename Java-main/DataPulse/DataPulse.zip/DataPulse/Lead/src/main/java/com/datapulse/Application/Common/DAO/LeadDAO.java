package com.datapulse.Application.Common.DAO;

import com.datapulse.Application.Domain.Entity.Lead;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

@Repository
@EnableMongoRepositories
public interface LeadDAO extends MongoRepository<Lead,String> {
}
