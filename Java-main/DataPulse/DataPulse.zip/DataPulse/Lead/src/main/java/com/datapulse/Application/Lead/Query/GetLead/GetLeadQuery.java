package com.datapulse.Application.Lead.Query.GetLead;

import com.datapulse.Mediator.Request;

public class GetLeadQuery implements Request<LeadVm> {
}
