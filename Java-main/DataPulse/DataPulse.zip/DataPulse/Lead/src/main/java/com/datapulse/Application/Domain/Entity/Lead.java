package com.datapulse.Application.Domain.Entity;

import com.datapulse.Application.Domain.Common.AuditableEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Document("lead")
public class Lead  extends  AuditableEntity{

    @Id
    public String id;

    @Field("firstName")
    public String firstName;

    @Field("lastName")
    public String lastName;

    @Field("phone")
    public String phone;

    @Field("company")
    public String company;

    @Field("title")
    public String title;

    @Field("leadSource")
    public String leadSource;

    @Field("email")
    public String email;

    @Field("leadStatus")
    public String leadStatus;

    @Field("website")
    public String website;

    @Field("industry")
    public String industry;

    @Field("annualRevenue")
    public Double annualRevenue;

    @Field("createdDate")
    public String createdDate;


    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getCompany() {
        return company;
    }

    public String getTitle() {
        return title;
    }

    public String getLeadSource() {
        return leadSource;
    }

    public String getEmail() {
        return email;
    }

    public String getLeadStatus() {
        return leadStatus;
    }

    public String getWebsite() {
        return website;
    }

    public String getIndustry() {
        return industry;
    }

    public Double getAnnualRevenue() {
        return annualRevenue;
    }

    public String getCreatedDate() {
        return createdDate;
    }
}
