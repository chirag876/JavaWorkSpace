package com.datapulse.Application.Lead.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Common.FieldValuePair;
import com.datapulse.Application.Domain.Common.Property;
import com.datapulse.Application.Domain.Common.PublishEventData;
import com.datapulse.Application.Domain.Entity.Lead;

import com.datapulse.Application.Domain.Events.LeadCreatedEvent;

import com.datapulse.Application.Domain.Enum.OperationType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.Instant;
import java.util.*;

@Component
public class LeadCreatedEventHandler implements Notification.Handler<LeadCreatedEvent> {


    Logger _logger = LoggerFactory.getLogger(LeadCreatedEventHandler.class);

    @Autowired
    public   KafkaTemplate<String, Object> kafkaTemplate;
    private Lead lead;


    public LeadCreatedEventHandler() {
    }

    @Override
    public void handle(LeadCreatedEvent notification) {


        lead = new LeadCreatedEvent(notification.getLead()).getLead();
        _logger.info("LeadCreatedEventHandler " + notification.getLead());

       PublishEventData data =  PrepareEventDataFor_topic_elastic_search(lead);
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker(s) address
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArraySerializer"); // Serialize as byte array

        // Create a Kafka producer
        Producer<String, byte[]> producer = new KafkaProducer<>(props);

        try {
            // Serialize the object to a byte array
            byte[] serializedObject = serializeObject(data);

            // Create a ProducerRecord and send it to a Kafka topic
            ProducerRecord<String, byte[]> record = new ProducerRecord<>("myleaddp", serializedObject);
//            producer.send(record);

            // Close the producer
            producer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }



        _logger.info("Lead Event: " + lead);

    }


    // Kafka implementation for Events
    private void handleKafka(LeadCreatedEvent event) {
//        Properties properties = new Properties();
//        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
//        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
//        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
//
//        // Create a Kafka producer instance
//        Producer<String, Object> producer = new KafkaProducer<>(properties);
//
//        // Create a producer record with a topic, key, and value
//        String topic = "mdlead";
//        String key = "lead";
//
//        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key, event);

        // Send the record to Kafka


        // Close the producer
//        producer.close();
    }


    public PublishEventData PrepareEventDataFor_topic_elastic_search( final Lead event) {


        PublishEventData eventData = new PublishEventData(new ArrayList<Property>());


        eventData.ApiName = "Lead";
        eventData.CollectionName = "lead";
        eventData.OperationType = String.valueOf(OperationType.INSERT);
        eventData.OperationDateTimeUtc = Date.from(Instant.now());
        eventData.EventName = "LeadCreatedEvent";
        eventData.OperationSource = "Webpage";

        ArrayList<Object> values = new ArrayList<>();
        List<FieldValuePair> fieldValues = new ArrayList<>();

        Class<?> clazz = event.getClass();
        Field[] fields = clazz.getFields();

        List<Property> propertyList = new ArrayList<>();

        Method[] methods = clazz.getMethods();

        _logger.info("{}",methods.length + "Fileds count {}",fields.length);


        for (Field field : clazz.getFields()) {
            String fieldName = field.getName();
            try {
                Property prop = new Property();
                String getterMethodName = "get" + Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1);
                Method getterMethod = clazz.getMethod(getterMethodName);

                Object value = getterMethod.invoke(event);
                prop.setPropertyName(fieldName);
                String val = ""+value;
                prop.setNewValue(val );
                prop.setOldValue(null);
                propertyList.add(prop);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        eventData.Data = propertyList;

        return eventData;


    }

    private static byte[] serializeObject(PublishEventData data) throws JsonProcessingException {
        // Implement serialization logic here
        // You can use libraries like Jackson for JSON serialization or Avro for schema-based serialization
        // For simplicity, let's assume it's a simple JSON serialization:
         ObjectMapper objectMapper = new ObjectMapper();
         return objectMapper.writeValueAsBytes(data);

    }
}



