package com.datapulse.Application.Lead.Query.QueryHandlers;


import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.Application.Lead.Query.GetLeadById.GetLeadByIdQuery;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class LeadByIdQueryHandler implements RequestHandler<GetLeadByIdQuery, LeadDTO> {
    Logger _logger = LoggerFactory.getLogger(LeadByIdQueryHandler.class);

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private ILead _dataAcces;
    @Override
    public UUID uhandle(GetLeadByIdQuery request) {
        return null;
    }

    @Override
    public LeadDTO handle(GetLeadByIdQuery request) {
        _logger.info("GetLeadByIdQuery.Handle - In process");
        Lead lead = new Lead();
        lead =_dataAcces.GetById(request.getId());
        LeadDTO dto1 = mapper.map(lead, LeadDTO.class);
        return dto1;
    }
}
