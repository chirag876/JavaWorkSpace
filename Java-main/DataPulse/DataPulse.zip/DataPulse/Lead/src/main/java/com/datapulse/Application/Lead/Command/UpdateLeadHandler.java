package com.datapulse.Application.Lead.Command;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Lead.Request.UpdateLeadRequest;
import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@Component
public class UpdateLeadHandler implements RequestHandler<UpdateLeadRequest, Lead> {
    //1. Logging Information In Process
    Logger logger = LoggerFactory.getLogger(UpdateLeadHandler.class);


    @Autowired
    private ILead leadDataAccess;

    @Override
    public UUID uhandle(UpdateLeadRequest request) {
        return null;
    }

    /// <summary>
    /// Handler will recieve request ,process it and will return the response.
    /// </summary>
    /// <param name="request"></param>

    @Override
    public Lead handle(UpdateLeadRequest request) {
        Lead entity = leadDataAccess.GetById(request.getId());
        try {
            logger.info("CreateLeadRequest: " + request);
            //setter of Account Entity fields
            entity.setFirstName(request.getFirstName());
            entity.setLastName(request.getLastName());
            entity.setCompany(request.getCompany());
            entity.setEmail(request.getEmail());
            entity.setLeadSource(request.getLeadSource());
            entity.setPhone(request.getPhone());
            entity.setTitle(request.getTitle());
            entity.setWebsite(request.getWebsite());
            entity.setAnnualRevenue(request.getAnnualRevenue());
            entity.setIndustry(request.getIndustry());
            entity.setCreatedDate(request.getCreatedDate());
            entity.setLeadStatus(request.getLeadStatus());

//            entity.setCreatedDateTime(Date.from(Instant.now()));
//            entity.setUpdatedDateTime(Date.from(Instant.now()));
//            entity.setAuthorizedById("");
//            entity.setOwnerId("");
            leadDataAccess.Update(entity);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return entity;
    }



}
