package com.datapulse.EndPoint;

import com.datapulse.Application.Lead.Request.CreateLeadRequest;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.Test;

import static org.springframework.test.util.AssertionErrors.assertEquals;
public class Ep_CreateLeadRequestTest extends LeadApplicationTests{


    @Test
    public void testCraeteLead1(){

        CreateLeadRequest request = new CreateLeadRequest("1abc11","John","Doe","555-123-4567","Example Company",
                "Manager","Web","john.doe@example.com","Qualified","https://example.com",
                "Technology",1000000.0,"2023-10-27"
        );

        CreateLeadRequest responce = responce = restTemplate.postForObject(baseUrl+"/Create",request,CreateLeadRequest.class);
        assertEquals("pass", "1abc11", responce.getId());
    }

    @Test
    public void testCraeteLead2(){

        CreateLeadRequest request = new CreateLeadRequest("112345","Herry","Doe","555-123-4567","Example Company",
                "Manager","Web","herry.doe@example.com","Qualified","https://example.com",
                "Technology",1000000.0,"2023-10-27"
        );

        CreateLeadRequest responce = responce = restTemplate.postForObject(baseUrl+"/Create",request,CreateLeadRequest.class);
        assertEquals("pass", "112345", responce.getId());
    }

}
