package com.datapulse.EndPoint;

import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Ep_GetLeadById extends LeadApplicationTests {


    @Test
    public void GetLeadById(){

        LeadDTO responce = restTemplate.getForObject(baseUrl + "/{id}", LeadDTO.class, "112345");

        assertAll(

                () -> assertEquals("112345", responce.getId()),
                () -> assertEquals("Herry", responce.getFirstName())
        );
    }

    @Test
    public void GetLeadById2(){

        LeadDTO responce = restTemplate.getForObject(baseUrl + "/{id}", LeadDTO.class, "1abc11");

        assertAll(

                () -> assertEquals("1abc11", responce.getId()),
                () -> assertEquals("John", responce.getFirstName())
        );
    }
}
