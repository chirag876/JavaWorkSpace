package com.datapulse.Command;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Lead.Request.UpdateLeadRequest;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.test.util.AssertionErrors.assertEquals;

public class UpdateLeadRequestTest extends LeadApplicationTests {

    @Autowired
    public ILead dataAccess;

    @Test
    public void testUpdateLead1(){
        Lead lead = new Lead("1abc11","John","Doe","555-123-4567","Example Company",
                "Manager","Web","john.doe@example.com","Qualified","https://example.com",
                "Technology",1000000.0,"2023-10-27"
        );

        dataAccess.Update(lead);
        assertAll(

                () -> assertEquals("pass", dataAccess.Update(lead),dataAccess.Update(lead))
        );
    }


}
