package com.datapulse.Command;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Lead.Request.DeleteLeadRequest;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.AssertionErrors;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class DeleteLeadRequestTest extends LeadApplicationTests {

    @Autowired
    public ILead dataAccess;

    @Test
    public void  testDeleteTest(){
        DeleteLeadRequest request = new DeleteLeadRequest("1abc11");

        String result =dataAccess.Delete(request.getId());
        AssertionErrors.assertEquals("pass", "1abc11", result);

    }
}
