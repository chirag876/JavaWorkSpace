package com.datapulse.EndPoint;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Lead.Request.CreateLeadRequest;
import com.datapulse.Application.Lead.Request.DeleteLeadRequest;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.AssertionErrors;

import static org.springframework.test.util.AssertionErrors.assertEquals;

public class Ep_DeleteLeadRequestTest extends LeadApplicationTests {


    @Test
    public void  testDeleteTest(){
        DeleteLeadRequest request = new DeleteLeadRequest("1abc11");

       restTemplate.delete(baseUrl+"/1abc11");



    }
}
