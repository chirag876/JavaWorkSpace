package com.datapulse.EndPoint;

import com.datapulse.Application.Lead.Request.UpdateLeadRequest;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.test.util.AssertionErrors.assertEquals;

public class Ep_UpdateLeadRequestTest extends LeadApplicationTests {

    @Test
    public void testUpdateLead1(){
        UpdateLeadRequest request = new UpdateLeadRequest("1abc11","John","Doe","555-123-4567","Example Company",
                "Manager","Web","john.doe@example.com","Qualified","https://example.com",
                "Technology",1000000.0,"2023-10-27"
        );

      restTemplate.put(baseUrl+"/{id}",request,request.getId());
        assertAll(

                () -> assertEquals("pass", request,request)
        );
    }

    @Test
    public void testUpdateLead2(){

        UpdateLeadRequest request = new UpdateLeadRequest("1abc12","John","Doe","555-123-4567","Example Company",
                "Manager","Web","john.doe@example.com","Qualified","https://example.com",
                "Technology",1000000.0,"2023-10-27"
        );

        restTemplate.put(baseUrl+"/{id}",request,request.getId());

        try {
            assertAll(

                    () -> assertEquals("pass", request, request)
            );
        }
        catch (Exception e){
             e.getMessage();
        }

    }
}
