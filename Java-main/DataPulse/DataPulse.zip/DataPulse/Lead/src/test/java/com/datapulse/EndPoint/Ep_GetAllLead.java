package com.datapulse.EndPoint;

import com.datapulse.LeadApplicationTests;

public class Ep_GetAllLead extends LeadApplicationTests {


}
