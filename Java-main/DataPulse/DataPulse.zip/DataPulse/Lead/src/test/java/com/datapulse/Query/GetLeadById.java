package com.datapulse.Query;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.LeadApplicationTests;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.util.AssertionErrors.assertNotNull;

public class GetLeadById extends LeadApplicationTests {

    @Autowired
    public ILead dataAccess;


    @Test
    public void GetLeadById(){

        Lead responce= dataAccess.GetById("112345");


        assertAll(

                () -> assertEquals("112345", responce.getId()),
                () -> assertEquals("Herry", responce.getFirstName())
        );
    }


}
