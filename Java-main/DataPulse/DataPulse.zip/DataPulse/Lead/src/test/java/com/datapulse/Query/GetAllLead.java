package com.datapulse.Query;

import com.datapulse.LeadApplicationTests;

public class GetAllLead extends LeadApplicationTests {


}
