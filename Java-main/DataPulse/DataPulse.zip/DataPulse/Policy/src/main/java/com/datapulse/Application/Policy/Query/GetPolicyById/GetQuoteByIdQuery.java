package com.datapulse.Application.Policy.Query.GetPolicyById;

import com.datapulse.Application.Policy.Query.GetPolicy.PolicyDTO;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetQuoteByIdQuery implements Request<PolicyDTO> {
    private String id;
}
