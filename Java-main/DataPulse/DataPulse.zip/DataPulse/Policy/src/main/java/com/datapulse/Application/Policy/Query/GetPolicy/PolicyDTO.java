package com.datapulse.Application.Policy.Query.GetPolicy;

import com.datapulse.Application.Domain.Entity.*;

import jakarta.persistence.ElementCollection;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Setter
@Getter
public class PolicyDTO {
    private String id;
    private String quoteId;
    private Date cancellationDate;
    private String cancelReasonDescription;
    private String controllingStateOrProvinceCode;
    private Date effectiveDate;
    private Date expirationDate;
    private String lineofBusinessCode;
    private String number;
    private Date originalEffectiveDate;
    private String parentEntityId;
    private String parentEntityTypeName;
    private String statusCode;
    private double totalPremium;
    private int agentCode;
    private String policyId;
    private Date accountingDate;
    private int referalCode;
    private String renewalStatus;
    private String transactionType;
    @ElementCollection
    private List<Address> addressList = new ArrayList<>();
    private Coverage coverage;
    @ElementCollection
    private List<Insured> insured;
    private  long countryCode;
    private Producer producer;
    @ElementCollection
    private List<Reference> reference = new ArrayList<>();
    private Underwriter underwriter;
    private Claim claim;

}
