package com.datapulse.Application.Policy.Command;

import com.datapulse.Application.Common.Interface.IPolicy;
import com.datapulse.Application.Domain.Entity.Policy;
import com.datapulse.Application.Policy.Request.DeletePolicyRequest;
import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class DeleteQuoteHandler implements RequestHandler<DeletePolicyRequest, String> {

    Logger logger = LoggerFactory.getLogger(DeleteQuoteHandler.class);


    @Autowired
    private IPolicy policyDataAccess;
    @Override
    public UUID uhandle(DeletePolicyRequest request) {
        return null;
    }

    @Override
    public String handle(DeletePolicyRequest request) {
        logger.info("DeletePolicyHandler: " + request);

        Policy dto =  this.policyDataAccess.GetById(Long.valueOf(request.getId()));
        if (dto.getId().equals(request.getId())){

        }

        logger.info("DeletePolicyRequest.Handle - Completed");

        return request.getId();
    }
}
