package com.datapulse.Application.Policy.Command;


import com.datapulse.Application.Common.Interface.IPolicy;
import com.datapulse.Application.Domain.Entity.*;
import com.datapulse.Application.Policy.Request.CreatePolicyRequest;
import com.datapulse.Mediator.RequestHandler;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@Component
public class CreateQuoteHandler implements RequestHandler<CreatePolicyRequest, String> {

    Logger logger = LoggerFactory.getLogger(CreateQuoteHandler.class);


    @Autowired
    private IPolicy policyDataAccess;

    public CreateQuoteHandler(IPolicy policyDataAccess) {
        this.policyDataAccess = policyDataAccess;
    }


    @Override
    public UUID uhandle(CreatePolicyRequest request) {
        return null;
    }

    @Override
    public String handle(CreatePolicyRequest request) {
        Policy policy = new Policy();
        try {
            logger.info("CreatePolicyRequest: " + request);
            //setter of Account Entity fields

            policy.setId(request.getId());
            policy.setQuoteId(request.getQuoteId());
            policy.setCancellationDate(request.getCancellationDate());
            policy.setControllingStateOrProvinceCode(request.getControllingStateOrProvinceCode());
            policy.setCancelReasonDescription(request.getCancelReasonDescription());
            policy.setEffectiveDate(request.getEffectiveDate());
            policy.setExpirationDate(request.getExpirationDate());
            policy.setLineofBusinessCode(request.getLineofBusinessCode());
            policy.setNumber(request.getNumber());
            policy.setOriginalEffectiveDate(request.getOriginalEffectiveDate());
            policy.setParentEntityId(request.getParentEntityId());
            policy.setParentEntityTypeName(request.getParentEntityTypeName());
            policy.setStatusCode(request.getStatusCode());
            policy.setTotalPremium(request.getTotalPremium());
            policy.setAgentCode(request.getAgentCode());
            policy.setAccountingDate(request.getAccountingDate());
            policy.setReferalCode(request.getReferalCode());
            policy.setRenewalStatus(request.getRenewalStatus());
            policy.setTransactionType(request.getTransactionType());
            policy.setAddress(request.getAddress());
            policy.setInsured(request.getInsured());
            policy.setCoverage(request.getCoverage());
            policy.setCountryCode(request.getCountryCode());
            policy.setProducer(request.getProducer());
            policy.setReference(request.getReference());
            policy.setUnderwriter(request.getUnderwriter());
            policy.setClaim(request.getClaim());
            policy.setPolicyId(request.getId());

            policyDataAccess.AddPolicy(policy);



        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return policy.getQuoteId();
    }



}