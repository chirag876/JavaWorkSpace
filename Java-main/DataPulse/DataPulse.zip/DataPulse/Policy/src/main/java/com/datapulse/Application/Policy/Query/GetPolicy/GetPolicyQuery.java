package com.datapulse.Application.Policy.Query.GetPolicy;

import com.datapulse.Mediator.Request;

public class GetPolicyQuery implements Request<PolicyVm> {
}
