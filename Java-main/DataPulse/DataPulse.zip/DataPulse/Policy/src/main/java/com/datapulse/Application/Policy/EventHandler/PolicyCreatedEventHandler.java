package com.datapulse.Application.Policy.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Policy;
import com.datapulse.Application.Domain.Events.PolicyCreatedEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class PolicyCreatedEventHandler implements Notification.Handler<PolicyCreatedEvent> {


    Logger _logger = LoggerFactory.getLogger(PolicyCreatedEventHandler.class);
    private Policy policy;
    public PolicyCreatedEventHandler(){}

    @Override
    public void handle(PolicyCreatedEvent notification) {

        policy= new PolicyCreatedEvent(notification.getPolicy()).getPolicy();
        _logger.info("PolicyCreatedEventHandler "+ notification.getPolicy());

        _logger.info("Policy Event: "+ policy);

    }


    // Kafka implementation for Events
    private void handleKafka(PolicyCreatedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }


}
