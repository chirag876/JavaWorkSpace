package com.datapulse.Application.Policy.Query.QueryHandlers;


import com.datapulse.Application.Common.Interface.IPolicy;
import com.datapulse.Application.Domain.Entity.Policy;
import com.datapulse.Application.Policy.Query.GetPolicy.PolicyDTO;
import com.datapulse.Application.Policy.Query.GetPolicyById.GetQuoteByIdQuery;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class PolicyByIdQueryHandler implements RequestHandler<GetQuoteByIdQuery, PolicyDTO> {
    Logger _logger = LoggerFactory.getLogger(PolicyByIdQueryHandler.class);

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IPolicy _dataAcces;
    @Override
    public UUID uhandle(GetQuoteByIdQuery request) {
        return null;
    }

    @Override
    public PolicyDTO handle(GetQuoteByIdQuery request) {
        _logger.info("GetLeadByIdQuery.Handle - In process");
        Policy policy = new Policy();
        policy =_dataAcces.GetById(Long.valueOf(request.getId()));
        PolicyDTO dto1 = mapper.map(policy, PolicyDTO.class);
        return dto1;
    }
}
