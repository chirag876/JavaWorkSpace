package com.datapulse.Application.Policy.Query.QueryHandlers;

import com.datapulse.Application.Common.Interface.IPolicy;
import com.datapulse.Application.Policy.Query.GetPolicy.GetPolicyQuery;
import com.datapulse.Application.Policy.Query.GetPolicy.PolicyDTO;
import com.datapulse.Application.Policy.Query.GetPolicy.PolicyVm;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class PolicyQueryHandler implements RequestHandler<GetPolicyQuery, PolicyVm> {

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IPolicy _dataAcces;
    @Override
    public UUID uhandle(GetPolicyQuery request) {
        return null;
    }

    @Override
    public PolicyVm handle(GetPolicyQuery request) {
       PolicyVm policyVm = new PolicyVm();
        policyVm.setPolicyList(mapper.map(_dataAcces.GetList(), new TypeToken<List<PolicyDTO>>() {}.getType()));
        return policyVm;
    }
}
