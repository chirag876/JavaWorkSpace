package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Reference {
    private String appliesTo;
    private String description;
    @Column(insertable=false, updatable=false)
    private String id;
    private String name;
}
