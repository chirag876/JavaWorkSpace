package com.datapulse.Application.Domain.Events;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Policy;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
@AllArgsConstructor

public class PolicyUpdatedEvent implements Notification {
    private Policy policy;

    Logger logger = LoggerFactory.getLogger(PolicyCreatedEvent.class);
    public PolicyUpdatedEvent(Policy policy){

        this.policy = policy;

        logger.info(" PolicyUpdatedEvent: " + policy);
    }

    public PolicyUpdatedEvent() {

    }
}
