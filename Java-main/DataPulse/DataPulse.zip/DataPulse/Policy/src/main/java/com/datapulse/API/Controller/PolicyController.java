package com.datapulse.API.Controller;

import com.datapulse.Application.Common.Interface.IPolicy;
import com.datapulse.Application.Domain.Entity.Policy;
import com.datapulse.Application.Policy.Query.GetPolicy.GetPolicyQuery;
import com.datapulse.Application.Policy.Query.GetPolicy.PolicyDTO;
import com.datapulse.Application.Policy.Query.GetPolicy.PolicyVm;
import com.datapulse.Application.Policy.Query.GetPolicyById.GetQuoteByIdQuery;
import com.datapulse.Application.Policy.Request.CreatePolicyRequest;
import com.datapulse.Application.Policy.Request.UpdatePolicyRequest;
import com.datapulse.Mediator.Mediator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("Policy")
@CrossOrigin("*")
public class PolicyController {
    private Mediator _mediator;

    @Autowired
    private IPolicy _dataAccess;

    public PolicyController(Mediator _mediator) { this._mediator = _mediator;  }

    @PostMapping("/Create")
    public String Create(@RequestBody CreatePolicyRequest request) {
        //return this.contactDataAccess.AddContact(request);

        return	_mediator.send(request);


    }

    @GetMapping()
    public PolicyVm getAllContact(){

        return _mediator.send(new GetPolicyQuery());

    }

    @GetMapping("/{id}")
    public PolicyDTO getContactById(@PathVariable String id){

        return _mediator.send(new GetQuoteByIdQuery(id));

    }

    @PutMapping("/{id}")
    public String  Update(@PathVariable Long id,  @RequestBody UpdatePolicyRequest request){

        Policy policy = _dataAccess.GetById(id);

        if (policy.getId().equals(id)){
            return _mediator.send(request);

        }
        return "User Not Found..";
    }
//
//    //Delete
//    @DeleteMapping("/{id}")
//    public String Delete(@PathVariable String id){
//        return _mediator.send(new DeleteLeadRequest(id));
//    }



}
