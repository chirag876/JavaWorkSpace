package com.datapulse.Command;


import com.datapulse.Application.Opportunity.Request.UpdateOpportunityRequest;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.test.util.AssertionErrors.assertEquals;

public class UpdateOpportunityRequestTest extends OpportunityApplicationTests {

    @Test
    public void testUpdateOpportunity(){
        UpdateOpportunityRequest request = new UpdateOpportunityRequest("125698", "Henry ", 30.78, "2023-10-10", "webpage", "wbs", "important", "prospect");
        restTemplate.put(baseUrl+"/{id}",request,request.getId());
        assertAll(() -> assertEquals("pass", request,request));
    }
}
