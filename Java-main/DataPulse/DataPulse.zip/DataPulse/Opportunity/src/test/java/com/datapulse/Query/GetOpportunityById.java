package com.datapulse.Query;

import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.test.util.AssertionErrors.assertEquals;

public class GetOpportunityById extends OpportunityApplicationTests {


    @Test
    public void GetOpportunityById(){

        OpportunityDTO responce = restTemplate.getForObject(baseUrl + "/{id}", OpportunityDTO.class, "125698");

        assertAll(

                () -> Assertions.assertEquals("125698", responce.getId()),
                () -> Assertions.assertEquals("Henry ", responce.getAccountName())
        );
    }

    @Test
    public void GetOpportunityById2(){

        OpportunityDTO responce = restTemplate.getForObject(baseUrl + "/{id}", OpportunityDTO.class, "3");

        assertAll(

                () -> Assertions.assertEquals("3", responce.getId()),
                () -> Assertions.assertEquals("Jhone Doe", responce.getAccountName())
        );
    }
}
