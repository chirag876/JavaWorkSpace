package com.datapulse.Endpoint;


import com.datapulse.OpportunityApplicationTests;

public class GetAllLead extends OpportunityApplicationTests {


}
