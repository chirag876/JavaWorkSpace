package com.datapulse.Endpoint;

import com.datapulse.Application.Opportunity.Request.CreateOpportunityRequest;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Test;

import static org.springframework.test.util.AssertionErrors.assertEquals;
public class Ep_CreateOpportunityRequestTest extends OpportunityApplicationTests {

    @Test
    public void testCreateOpportunity() {

        CreateOpportunityRequest request = new CreateOpportunityRequest("125698", "Jhone Doe", 30.89, "2023-10-10", "webpage", "wbs", "important", "prospect");

        CreateOpportunityRequest responce = restTemplate.postForObject(baseUrl + "/Create", request,CreateOpportunityRequest.class);
        assertEquals("pass", "125698", responce.getId());
    }
    @Test
    public void testCreateOpportunity2() {

        CreateOpportunityRequest request = new CreateOpportunityRequest("125678", "Alex Doe", 30.89, "2023-10-10", "webpage", "wbs", "important", "prospect");

        CreateOpportunityRequest responce = restTemplate.postForObject(baseUrl + "/Create", request,CreateOpportunityRequest.class);
        assertEquals("pass", "125678", responce.getId());
    }
}
