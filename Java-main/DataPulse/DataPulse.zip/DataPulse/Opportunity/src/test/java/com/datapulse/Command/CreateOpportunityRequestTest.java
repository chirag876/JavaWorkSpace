package com.datapulse.Command;

import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Domain.Entity.Opportunity;
import com.datapulse.Application.Opportunity.Request.CreateOpportunityRequest;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.test.util.AssertionErrors.assertEquals;
public class CreateOpportunityRequestTest extends OpportunityApplicationTests {

    @Autowired
    public IOpportunity dataAccess;

    @Test
    public void testCreateOpportunity() {

        Opportunity opportunity = new Opportunity("125698", "Jhone Doe", 30.89, "2023-10-10", "webpage", "wbs", "important", "prospect");

        Opportunity responce =  dataAccess.AddOpportunity(opportunity);
        assertEquals("pass", "125698", responce.getId());
    }
    @Test
    public void testCreateOpportunity2() {

        Opportunity opportunity = new Opportunity("125678", "Alex Doe", 30.89, "2023-10-10", "webpage", "wbs", "important", "prospect");

        Opportunity responce =  dataAccess.AddOpportunity(opportunity);
        assertEquals("pass", "125678", responce.getId());
    }
}
