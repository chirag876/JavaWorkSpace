package com.datapulse.Endpoint;

import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;

public class Ep_GetOpportunityById extends OpportunityApplicationTests {


    @Test
    public void GetOpportunityById(){

        OpportunityDTO responce = restTemplate.getForObject(baseUrl + "/{id}", OpportunityDTO.class, "125698");

        assertAll(

                () -> Assertions.assertEquals("125698", responce.getId()),
                () -> Assertions.assertEquals("Henry ", responce.getAccountName())
        );
    }

    @Test
    public void GetOpportunityById2(){

        OpportunityDTO responce = restTemplate.getForObject(baseUrl + "/{id}", OpportunityDTO.class, "3");

        assertAll(

                () -> Assertions.assertEquals("3", responce.getId()),
                () -> Assertions.assertEquals("Jhone Doe", responce.getAccountName())
        );
    }
}
