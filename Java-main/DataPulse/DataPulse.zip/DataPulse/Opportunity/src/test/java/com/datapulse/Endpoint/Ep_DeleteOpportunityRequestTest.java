package com.datapulse.Endpoint;

import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Opportunity.Request.CreateOpportunityRequest;
import com.datapulse.Application.Opportunity.Request.DeleteOpportunityRequest;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.test.util.AssertionErrors.assertEquals;

public class Ep_DeleteOpportunityRequestTest extends OpportunityApplicationTests {


    @Test
    public void testOpportunityDelete(){
        DeleteOpportunityRequest request = new DeleteOpportunityRequest("125698");
       restTemplate.delete(baseUrl + "/125698");

    }
}
