package com.datapulse.Query;


import com.datapulse.OpportunityApplicationTests;

public class GetAllLead extends OpportunityApplicationTests {


}
