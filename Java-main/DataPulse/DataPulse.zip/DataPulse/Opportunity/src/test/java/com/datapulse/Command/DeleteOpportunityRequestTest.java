package com.datapulse.Command;

import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Opportunity.Request.DeleteOpportunityRequest;
import com.datapulse.OpportunityApplicationTests;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.test.util.AssertionErrors.assertEquals;

public class DeleteOpportunityRequestTest extends OpportunityApplicationTests {

    @Autowired
    public IOpportunity dataAccess;

    @Test
    public void testOpportunityDelete(){
        DeleteOpportunityRequest request = new DeleteOpportunityRequest("125698");
        String result =dataAccess.Delete(request.getId());
        assertEquals("pass", "125698", result);
    }
}
