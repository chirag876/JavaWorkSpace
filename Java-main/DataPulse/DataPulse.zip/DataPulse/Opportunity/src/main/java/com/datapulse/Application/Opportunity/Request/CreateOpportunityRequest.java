package com.datapulse.Application.Opportunity.Request;

import com.datapulse.Application.Domain.Entity.Opportunity;
import com.datapulse.Mediator.Request;
import jakarta.persistence.ElementCollection;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateOpportunityRequest implements Request<Opportunity> {
    private String id;
    private String accountName;
    private Double amount;
    private String closeDate;
    private String leadSource;
    private String opportunityName;
    private String stage;
    private String type;

}
