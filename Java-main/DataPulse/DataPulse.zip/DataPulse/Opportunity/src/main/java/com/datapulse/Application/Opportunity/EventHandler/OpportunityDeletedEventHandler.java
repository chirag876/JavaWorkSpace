package com.datapulse.Application.Opportunity.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Opportunity;
import com.datapulse.Application.Domain.Events.OpportunityCreatedEvent;
import com.datapulse.Application.Domain.Events.OpportunityDeletedEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class OpportunityDeletedEventHandler implements Notification.Handler<OpportunityDeletedEvent> {


    Logger _logger = LoggerFactory.getLogger(OpportunityDeletedEventHandler.class);
    private  Opportunity opportunity;
    public OpportunityDeletedEventHandler(){}

    @Override
    public void handle(OpportunityDeletedEvent notification) {

        opportunity = notification.getOpportunity();

    }

    private void handleKafka(OpportunityCreatedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }


}
