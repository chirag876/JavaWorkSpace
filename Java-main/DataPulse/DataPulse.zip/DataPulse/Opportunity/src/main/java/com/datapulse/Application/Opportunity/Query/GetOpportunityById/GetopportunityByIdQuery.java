package com.datapulse.Application.Opportunity.Query.GetOpportunityById;

import com.datapulse.Application.Domain.Entity.Opportunity;
import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.kafka.common.protocol.types.Field;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetopportunityByIdQuery implements Request<OpportunityDTO> {
    private String id;
}
