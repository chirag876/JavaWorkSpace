package com.datapulse.Application.Opportunity.Command;


import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Domain.Entity.Opportunity;
import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
import com.datapulse.Application.Opportunity.Query.GetOpportunityById.GetopportunityByIdQuery;
import com.datapulse.Application.Opportunity.Request.CreateOpportunityRequest;
import com.datapulse.Mediator.RequestHandler;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@Component
public class CreateOpportunityHandler implements RequestHandler<CreateOpportunityRequest, Opportunity> {

    Logger logger = LoggerFactory.getLogger(CreateOpportunityHandler.class);


    @Autowired
    private IOpportunity opportunityDataAccess;

    public CreateOpportunityHandler(IOpportunity opportunityDataAccess) {
        this.opportunityDataAccess = opportunityDataAccess;
    }



    @Override
    public Opportunity handle(CreateOpportunityRequest request) {
        Opportunity entity = new Opportunity();
        try {
            logger.info("CreateOpportunityRequest: " + request);
            //setter of Account Entity fields
            entity.setId(request.getId());
            entity.setAccountName(request.getAccountName());
            entity.setOpportunityName(request.getOpportunityName());
            entity.setAmount(request.getAmount());
            entity.setStage(request.getStage());
            entity.setCloseDate(request.getCloseDate());
            entity.setLeadSource(request.getLeadSource());
            entity.setType(request.getType());



//            entity.domainEvents().add(new AccountCreatedEvent(entity));
            opportunityDataAccess.AddOpportunity(entity);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return entity;
    }



    @Override
    public UUID uhandle(CreateOpportunityRequest request) {
        return null;
    }


}