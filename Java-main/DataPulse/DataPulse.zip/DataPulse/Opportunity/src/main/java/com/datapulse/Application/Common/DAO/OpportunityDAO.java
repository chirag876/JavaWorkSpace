package com.datapulse.Application.Common.DAO;

import com.datapulse.Application.Domain.Entity.Opportunity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

@Repository
@EnableMongoRepositories
public interface OpportunityDAO extends MongoRepository<Opportunity,String> {
}
