package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;

import com.datapulse.Application.Common.DAO.OpportunityDAO;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Domain.Common.DomainEvent;

import com.datapulse.Application.Domain.Entity.Opportunity;

import com.datapulse.Application.Domain.Events.OpportunityCreatedEvent;
import com.datapulse.Application.Domain.Events.OpportunityUpdatedEvent;
import com.datapulse.Application.Opportunity.EventHandler.OpportunityCreatedEventHandler;
import com.datapulse.Application.Opportunity.EventHandler.OpportunityUpdatedEventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Stream;

@Service

public class OpportunityDataAccess implements IOpportunity {

    Logger _logger  =  LoggerFactory.getLogger(OpportunityDataAccess.class);

    @Autowired
    private OpportunityDAO opportunityDAO;
    @Autowired
    private IDomainEventService domainEventService;
    @Override
    public Opportunity AddOpportunity(Opportunity opportunity) {

        try {
            _logger.info("OpportunityDataAccess.AddOpportunity - In process");


            opportunityDAO.save(opportunity);

        }
        catch(Exception ex) {
            _logger.error("OpportunityDataAccess.AddOpportunity"+ex.getMessage());

        }
        DispatchEvents(opportunity);
        return opportunity;

}

    @Override
    public List<Opportunity> GetList() {

        return opportunityDAO.findAll();
    }

    @Override
    public Opportunity GetById(String id) {

        try {
            _logger.info("OpportunityDataAccess.GetById - In process");
            return opportunityDAO.findById(id).get();
        }

        catch(Exception ex) {
            _logger.error("OpportunityDataAccess.GetById"+ex.getMessage());

        }

        return opportunityDAO.findById(id).get();
    }

    @Override
    public Opportunity Update(Opportunity account) {

        try {
            _logger.info("OpportunityDataAccess.Update - In process");


            opportunityDAO.save(account);

        }
        catch(Exception ex) {
            _logger.error("COpportunityDataAccess.Update"+ex.getMessage());

        }
        UpdateDispatchEvents(account);

        return account;
    }

    @Override
    public String Delete(String id) {
        try {
            _logger.info("OpportunityDataAccess.Delete - In process");
             opportunityDAO.deleteById(id);
             return id;
        }

        catch(Exception ex) {
            _logger.error("OpportunityDataAccess.Delete"+ex.getMessage());
            return ex.getMessage();

        }




    }


    // DispatchEvents

    public void DispatchEvents(Opportunity entity) {

        // Assuming you have a list of DomainEvent objects
//        List<DomainEvent> domainEvents = entity.;

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }
            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }
            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }
            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

//        domainEvents.add(domainEvent);


        domainEventService.Publish(domainEvent);

        _logger.info("Setting Pipeline for EventHandler");
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new OpportunityCreatedEventHandler())
        );

        OpportunityCreatedEvent opportunityCreatedEvent = new OpportunityCreatedEvent();
        opportunityCreatedEvent.setOpportunity(entity);
        opportunityCreatedEvent.send(pipeline);

    }
    public void UpdateDispatchEvents(Opportunity entity) {

        // Assuming you have a list of DomainEvent objects
//        List<DomainEvent> domainEvents = entity.domainEvents();

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }
            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }
            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }
            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

//        domainEvents.add(domainEvent);
        domainEventService.Publish(domainEvent);
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new OpportunityUpdatedEventHandler())
        );

        OpportunityUpdatedEvent opportunityUpdatedEvent = new OpportunityUpdatedEvent();
        opportunityUpdatedEvent.setOpportunity(entity);
        opportunityUpdatedEvent.send(pipeline);

    }

}
