package com.datapulse.API.Controller;

import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Domain.Entity.Opportunity;
import com.datapulse.Application.Opportunity.Query.GetOpportunity.GetOpportunityQuery;
import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityVm;
import com.datapulse.Application.Opportunity.Query.GetOpportunityById.GetopportunityByIdQuery;
import com.datapulse.Application.Opportunity.Request.CreateOpportunityRequest;
import com.datapulse.Application.Opportunity.Request.DeleteOpportunityRequest;
import com.datapulse.Application.Opportunity.Request.UpdateOpportunityRequest;
import com.datapulse.Mediator.Mediator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("Opportunity")
@CrossOrigin("*")
public class OpportunityController {
    private Mediator _mediator;

    @Autowired
    private IOpportunity _dataAccess;

    public OpportunityController(Mediator _mediator) { this._mediator = _mediator;  }

    @PostMapping("/Create")
    public ResponseEntity<?> Create(@RequestBody CreateOpportunityRequest request) {
        //return this.contactDataAccess.AddContact(request);

        return new ResponseEntity<>(_mediator.send(request), HttpStatus.OK);


    }

    @GetMapping()
    public OpportunityVm getAllContact(){

        return _mediator.send(new GetOpportunityQuery());

    }

    @GetMapping("/{id}")
    public OpportunityDTO getContactById(@PathVariable String id){

        return _mediator.send(new GetopportunityByIdQuery(id));

    }

    @PutMapping("/{id}")
    public String  Update(@PathVariable String id,  @RequestBody UpdateOpportunityRequest request){

        Opportunity opportunity = _dataAccess.GetById(id);

        if (opportunity.getId().equals(id)){
            return _mediator.send(request);

        }
        return "User Not Found..";
    }

    //Delete
    @DeleteMapping("/{id}")
    public String Delete(@PathVariable String id){
        return _mediator.send(new DeleteOpportunityRequest(id));
    }



}
