package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Opportunity;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface IOpportunity {
    public Opportunity AddOpportunity(Opportunity opportunity);

    public List<Opportunity> GetList();

    public Opportunity GetById(String id);

    public Opportunity Update(Opportunity opportunity);

    public String Delete(String id);
}
