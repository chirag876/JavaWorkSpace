package com.datapulse.Application.Opportunity.Query.GetOpportunity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class OpportunityDTO {
    private String id;
    private String accountName;
    private Double amount;
    private String closeDate;
    private String leadSource;
    private String opportunityName;
    private String stage;
    private String type;
}
