package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Communication {
    private String phoneTypeCode;
    private String phoneNumber;
    private String websiteURL;

}
