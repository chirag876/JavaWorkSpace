package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Location {
    @Column(insertable=false, updatable=false)
    private String city;
    @Column(insertable=false, updatable=false)
    private String countryCode;
    @Column(insertable=false, updatable=false)
    private String endDate;
    @Column(insertable=false, updatable=false)
    private String line1;
    @Column(insertable=false, updatable=false)
    private String postalCode;
    @Column(insertable=false, updatable=false)
    private String stateOrProvinceCode;
    @Column(insertable=false, updatable=false)
    private String startDate;
}
