package com.datapulse.Application.Quote.Query.QueryHandlers;


import com.datapulse.Application.Common.Interface.IQuote;
import com.datapulse.Application.Domain.Entity.Quote;
import com.datapulse.Application.Quote.Query.GetQuote.QuoteDTO;
import com.datapulse.Application.Quote.Query.GetQuoteById.GetQuoteByIdQuery;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class QuoteByIdQueryHandler implements RequestHandler<GetQuoteByIdQuery, QuoteDTO> {
    Logger _logger = LoggerFactory.getLogger(QuoteByIdQueryHandler.class);

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IQuote _dataAcces;
    @Override
    public UUID uhandle(GetQuoteByIdQuery request) {
        return null;
    }

    @Override
    public QuoteDTO handle(GetQuoteByIdQuery request) {
        _logger.info("GetLeadByIdQuery.Handle - In process");
        Quote quote = new Quote();
        quote =_dataAcces.GetById(request.getId());
        QuoteDTO dto1 = mapper.map(quote, QuoteDTO.class);
        return dto1;
    }
}
