package com.datapulse.Application.Quote.Query.GetQuote;

import com.datapulse.Mediator.Request;

public class GetQuoteQuery implements Request<QuoteVm> {
}
