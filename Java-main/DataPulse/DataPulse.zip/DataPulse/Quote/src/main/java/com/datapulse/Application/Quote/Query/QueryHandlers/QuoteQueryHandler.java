package com.datapulse.Application.Quote.Query.QueryHandlers;

import com.datapulse.Application.Common.Interface.IQuote;
import com.datapulse.Application.Quote.Query.GetQuote.GetQuoteQuery;
import com.datapulse.Application.Quote.Query.GetQuote.QuoteDTO;
import com.datapulse.Application.Quote.Query.GetQuote.QuoteVm;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class QuoteQueryHandler implements RequestHandler<GetQuoteQuery, QuoteVm> {

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IQuote _dataAcces;
    @Override
    public UUID uhandle(GetQuoteQuery request) {
        return null;
    }

    @Override
    public QuoteVm handle(GetQuoteQuery request) {
       QuoteVm quoteVm = new QuoteVm();
        quoteVm.setQuoteList(mapper.map(_dataAcces.GetList(), new TypeToken<List<QuoteDTO>>() {}.getType()));
        return quoteVm;
    }
}
