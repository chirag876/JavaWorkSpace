package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import lombok.Data;



@Data
@Embeddable
public class Premium {
    private Double amount;
    private String currencyCode;
    private Period period;

}
