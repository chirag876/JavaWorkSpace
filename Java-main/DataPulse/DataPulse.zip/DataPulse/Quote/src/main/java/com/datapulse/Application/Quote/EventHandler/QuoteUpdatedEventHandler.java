package com.datapulse.Application.Quote.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Entity.Quote;
import com.datapulse.Application.Domain.Events.QuoteCreatedEvent;
import com.datapulse.Application.Domain.Events.QuoteUpdatedEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class QuoteUpdatedEventHandler implements Notification.Handler<QuoteUpdatedEvent> {


    Logger _logger = LoggerFactory.getLogger(QuoteUpdatedEventHandler.class);

    private Quote quote;
    public QuoteUpdatedEventHandler(){}

    @Override
    public void handle(QuoteUpdatedEvent notification) {

        quote= new QuoteCreatedEvent(notification.getQuote()).getQuote();
        _logger.info("QuoteUpdateEventHandler "+ notification.getQuote());

        _logger.info("Quote Event: "+ quote);

    }




    private void handleKafka(QuoteUpdatedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }


}
