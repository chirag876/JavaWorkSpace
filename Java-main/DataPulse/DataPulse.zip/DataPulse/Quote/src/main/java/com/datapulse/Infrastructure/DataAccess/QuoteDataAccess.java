package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;
import com.datapulse.Application.Common.DAO.QuoteDAO;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Common.Interface.IQuote;
import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Quote;
import com.datapulse.Application.Domain.Events.QuoteCreatedEvent;
import com.datapulse.Application.Domain.Events.QuoteUpdatedEvent;
import com.datapulse.Application.Quote.EventHandler.QuoteCreatedEventHandler;
import com.datapulse.Application.Quote.EventHandler.QuoteDeletedEventHandler;
import com.datapulse.Application.Quote.EventHandler.QuoteUpdatedEventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Stream;

@Service
public class QuoteDataAccess implements IQuote {

    Logger _logger = LoggerFactory.getLogger(QuoteDataAccess.class);

    @Autowired
    private QuoteDAO quoteDAO;
    @Autowired
    private IDomainEventService domainEventService;

    @Override
    public Quote AddQuote(Quote lead) {

        try {
            _logger.info("QuoteDataAccess.AddQuote - In process");


            quoteDAO.save(lead);

        } catch (Exception ex) {
            _logger.error("QuoteDataAccess.AddQuote" + ex.getMessage());

        }
        DispatchEvents(lead);
        return lead;

    }

    @Override
    public List<Quote> GetList() {

        return quoteDAO.findAll();
    }

    @Override
    public Quote GetById(String id) {

        try {
            _logger.info("QuoteDataAccess.GetById - In process");
            return quoteDAO.findById(id).get();
        } catch (Exception ex) {
            _logger.error("QuoteDataAccess.GetById" + ex.getMessage());

        }

        return quoteDAO.findById(id).get();
    }

    @Override
    public Quote Update(Quote quote) {

        try {
            _logger.info("QuoteDataAccess.Update - In process");


            quoteDAO.save(quote);

        } catch (Exception ex) {
            _logger.error("QuoteDataAccess.Update" + ex.getMessage());

        }
        UpdateDispatchEvents(quote);

        return quote;
    }

    @Override
    public Quote Delete(String id) {
        return null;
    }


    // DispatchEvents

    public void DispatchEvents(Quote entity) {

        // Assuming you have a list of DomainEvent objects
//        List<DomainEvent> domainEvents = entity.;

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }

            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }

            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }

            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

//        domainEvents.add(domainEvent);


        domainEventService.Publish(domainEvent);

        _logger.info("Setting Pipeline for EventHandler");
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new QuoteCreatedEventHandler())
        );

        QuoteCreatedEvent opportunityCreatedEvent = new QuoteCreatedEvent();
        opportunityCreatedEvent.setQuote(entity);
        opportunityCreatedEvent.send(pipeline);

    }

    public void UpdateDispatchEvents(Quote entity) {

        //  you have a list of DomainEvent objects


        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }

            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }

            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }

            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);
//
//       domainEvents.add(domainEvent);
        domainEventService.Publish(domainEvent);
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new QuoteUpdatedEventHandler())
        );

        QuoteUpdatedEvent opportunityUpdatedEvent = new QuoteUpdatedEvent();
        opportunityUpdatedEvent.setQuote(entity);
        opportunityUpdatedEvent.send(pipeline);


//    }
    }
}
