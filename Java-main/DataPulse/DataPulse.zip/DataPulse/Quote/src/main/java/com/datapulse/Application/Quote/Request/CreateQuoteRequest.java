package com.datapulse.Application.Quote.Request;

import com.datapulse.Application.Domain.Entity.Insured;
import com.datapulse.Application.Domain.Entity.Location;
import com.datapulse.Application.Domain.Entity.Premium;
import com.datapulse.Mediator.Request;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateQuoteRequest implements Request<String> {
    private String id;
    private String quoteId;
    private Insured insured;
    private Location location;
    private Premium premium;

}
