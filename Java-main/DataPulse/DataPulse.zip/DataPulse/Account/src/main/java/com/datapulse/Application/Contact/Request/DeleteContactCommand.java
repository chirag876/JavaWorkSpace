package com.datapulse.Application.Contact.Request;


import com.datapulse.Mediator.Request;

public class DeleteContactCommand implements Request<Integer> {
	
	private int Id;

	public DeleteContactCommand(int Id) {
	this.Id = Id;
	}

	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
}


