package com.datapulse.Application.Account.Query.GetAccount;

import java.util.List;



public class AccountVm {
    public List<AccountDTO> accountList;

    public AccountVm() {}
    public AccountVm(List<AccountDTO> lists) {

        this.accountList = lists;
    }

    public List<AccountDTO> getLists() {
        return accountList;
    }

    public void setLists(List<AccountDTO> lists) {
        this.accountList = lists;
    }

}
