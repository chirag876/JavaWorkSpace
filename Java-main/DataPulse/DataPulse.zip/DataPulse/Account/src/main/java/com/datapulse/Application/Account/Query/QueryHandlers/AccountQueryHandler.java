package com.datapulse.Application.Account.Query.QueryHandlers;

import com.datapulse.Application.Account.Query.GetAccount.AccountDTO;
import com.datapulse.Application.Account.Query.GetAccount.AccountVm;
import com.datapulse.Application.Account.Query.GetAccount.GetAccountQuery;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Contact.Command.CreateContactCommandHand.ContactQueryHandler;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class AccountQueryHandler implements RequestHandler<GetAccountQuery, AccountVm> {

    Logger _logger = LoggerFactory.getLogger(ContactQueryHandler.class);
    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IAccount _dataAcces;
    @Override
    public UUID uhandle(GetAccountQuery request) {
        return null;
    }

    @Override
    public AccountVm handle(GetAccountQuery request) {
        AccountVm accountVm = new AccountVm();
        accountVm.setLists(mapper.map(_dataAcces.GetList(), new TypeToken<List<AccountDTO>>() {}.getType()));
        return accountVm;
    }
}
