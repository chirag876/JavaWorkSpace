package com.datapulse.Mediator;

import java.util.concurrent.CompletableFuture;

public interface IPublish {
	
	//void Publish(Object notification);
	// <T> Task Publish(Notification notification);

		<TNotification extends Notification> CompletableFuture<Void> publish(TNotification notification);


//	public <TNotification extends Notification> Notification Publish(TNotification notification);

}
