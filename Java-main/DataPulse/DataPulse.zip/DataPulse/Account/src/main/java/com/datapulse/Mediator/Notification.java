package com.datapulse.Mediator;

public interface Notification {

}
