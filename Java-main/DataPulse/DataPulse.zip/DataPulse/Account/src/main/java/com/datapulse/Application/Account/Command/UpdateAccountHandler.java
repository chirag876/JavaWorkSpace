package com.datapulse.Application.Account.Command;

import com.datapulse.Application.Account.Request.UpdateAccountRequest;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class UpdateAccountHandler  implements RequestHandler<UpdateAccountRequest, String> {


    Logger _logger = LoggerFactory.getLogger(UpdateAccountHandler.class);
    @Autowired
    private IAccount _dataAccess;
    @Override
    public UUID uhandle(UpdateAccountRequest request) {
        return null;
    }

    @Override
    public String handle(UpdateAccountRequest request) {
        Account account = _dataAccess.GetById(request.getId());
        if(request.getId()!=null) {

            _logger.info("Id: "+request.getId(),"Name:"+ request.getName());
            account.setName(request.getName());
            account.setPhoneNumber(request.getPhoneNumber());
            account.setPhoneExtension(request.getPhoneExtension());
            account.setCity(request.getCity());
            account.setState(request.getState());
            account.setZipCode(request.getZipCode());
            account.setAddressLine1(request.getAddressLine1());
            account.setAddressLine2(request.getAddressLine2());

//            account.domainEvents().add(new AccountUpdatedEvent(account));

            _dataAccess.Update(account);
//            account.domainEvents().add(new AccountCompletedEvent(account));
        }
        return account.getId();



        }

    }

