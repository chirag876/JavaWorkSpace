package com.datapulse.Application.Contact.Query.GetContact;


import com.datapulse.Mediator.Request;

public class GetContactQuery implements Request<ContactVm> {
	

}

