package com.datapulse.Application.Domain.Events.Contact;


import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Contact;

public class ContactDeleteEvent extends DomainEvent {
	
	private Contact contact;

	public ContactDeleteEvent(Contact contact) {
		this.contact = contact;		
	}
	public Contact getContact() {
		return contact;
	}

}
