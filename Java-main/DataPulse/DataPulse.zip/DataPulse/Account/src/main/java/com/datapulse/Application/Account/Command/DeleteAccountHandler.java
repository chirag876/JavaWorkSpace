package com.datapulse.Application.Account.Command;

import com.datapulse.Application.Account.Request.CreateAccountRequest;
import com.datapulse.Application.Account.Request.DeleteAccountRequest;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class DeleteAccountHandler implements RequestHandler<DeleteAccountRequest, Account> {

    Logger logger = LoggerFactory.getLogger(DeleteAccountHandler.class);


    @Autowired
    private IAccount accountDataAccess;
    @Override
    public UUID uhandle(DeleteAccountRequest request) {
        return null;
    }

    @Override
    public Account handle(DeleteAccountRequest request) {
        logger.info("DeleteAccountHandler: " + request);

        Account dto =  this.accountDataAccess.GetById(request.getId());
        if (dto.getId().equals(request.getId())){
            accountDataAccess.Delete(dto.getId());
            return dto;
        }

        logger.info("DeleteAccountRequest.Handle - Completed");

        return dto;
    }

}
