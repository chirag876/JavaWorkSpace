package com.datapulse.Application.Account.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Application.Domain.Events.Account.AccountCreatedEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class AccountCreatedEventHandler implements Notification.Handler<AccountCreatedEvent> {


    Logger _logger = LoggerFactory.getLogger(AccountCreatedEventHandler.class);
    private Account account;
    public  AccountCreatedEventHandler(){}


    @Override
    public void handle(AccountCreatedEvent notification) {


        account= new AccountCreatedEvent(notification.getAccount()).getAccount();
        _logger.info("AccountCreatedEventHandler "+ notification.getAccount());

        _logger.info("Account Event: "+ account);

    }

    private void handleKafka(AccountCreatedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }
}
