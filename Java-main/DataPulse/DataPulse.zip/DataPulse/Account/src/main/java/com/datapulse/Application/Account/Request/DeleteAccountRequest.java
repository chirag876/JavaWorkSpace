package com.datapulse.Application.Account.Request;

import an.awesome.pipelinr.repack.org.checkerframework.checker.units.qual.A;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteAccountRequest implements Request<Account> {
    public String id;
}
