package com.datapulse.Application.Common.Interface;


import com.datapulse.Application.Domain.Entity.Contact;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository

public interface IContact {
	
	
	public Contact AddContact(Contact contact);

	public List<Contact> GetList();
	
	public Contact GetById(int id);
	
	public Integer Update(Contact contact);
	
	public int Delete(int id);

}
