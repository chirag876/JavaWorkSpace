package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Account.Account;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IAccount {
    public Account AddAccount(Account account);

    public List<Account> GetList();

    public Account GetById(String id);

    public Account Update(Account account);

    public String Delete(String id);
}
