package com.datapulse.Endpoint;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Account.Request.CreateAccountRequest;
import com.datapulse.Application.Account.Request.DeleteAccountRequest;
import com.datapulse.Application.Common.Interface.IAccount;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.test.util.AssertionErrors.assertEquals;

public class Ep_DeleteAccountRequestTest extends AccountApplicationTests {


    @Test
    public void testAccountDelete(){

        DeleteAccountRequest request = new DeleteAccountRequest("119042");

         restTemplate.delete(baseUrl+"/119042");

    }
}
