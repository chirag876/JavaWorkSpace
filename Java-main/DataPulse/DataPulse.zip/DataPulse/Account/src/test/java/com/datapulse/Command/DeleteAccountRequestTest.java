package com.datapulse.Command;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Account.Request.DeleteAccountRequest;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class DeleteAccountRequestTest extends AccountApplicationTests {
    @Autowired
    public IAccount dataAccess;

    @Test
    public void testAccountDelete(){

        DeleteAccountRequest request = new DeleteAccountRequest("119042");

       dataAccess.Delete(request.getId());
    }
}
