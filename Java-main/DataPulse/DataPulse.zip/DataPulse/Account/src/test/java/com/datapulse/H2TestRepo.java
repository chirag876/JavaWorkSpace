//package com.datapulse;
//
//import com.datapulse.Application.Domain.Entity.Account.Account;
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//public interface H2TestRepo extends MongoRepository<Account, String> {
//}
