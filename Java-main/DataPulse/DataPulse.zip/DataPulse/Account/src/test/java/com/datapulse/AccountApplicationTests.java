package com.datapulse;

import com.datapulse.Application.Account.Request.CreateAccountRequest;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Application.Domain.Entity.Account.Contacts;
import com.datapulse.Application.Domain.Entity.Contact;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.util.AssertionErrors.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AccountApplicationTests {


	@LocalServerPort
	public int port;

	public String baseUrl= "http://localhost";
	public static RestTemplate restTemplate;

//	@Autowired
//	private H2TestRepo testRepo;

	@BeforeAll
	public static void init(){
		restTemplate = new RestTemplate();
	}

	@BeforeEach
	public void setUp(){
		baseUrl = baseUrl.concat(":").concat(port+"").concat("/Account");
	}





}
