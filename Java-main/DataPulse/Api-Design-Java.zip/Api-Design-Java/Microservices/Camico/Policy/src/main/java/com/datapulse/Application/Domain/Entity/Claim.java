package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.util.Date;
@Data
@Embeddable
public class Claim {
    private Long claimId;
    private Long claimNo;
    private Date accidentDate;
    private Date reportedDate;
    private Date registerDate;
    private String accidentZipCode;
    private double accidentLatitude;
    private double accidentLongitude;
    private String accidentMonth;
    private int accidentMonthOrder;
    private int claimSuffix;
    private String typeOfLoss;
    private String adjuster;
    private String accidentQuarter;
    private int accidentQuarterOrder;
    private String estado;
    private String suffixRegisterDate;
    private int idSuffixStatus;
    private String suffixStatus;
    @Column(insertable=false, updatable=false)
    private String fullName;
    private Date dateOfBirth;
    private String licenseNo;
    private String lossDescription;
    private String claimant;
    private String reportedBy;
    private String litigation;
    private String accidentCity;
    private String accidentCountry;
    private String driverState;
    private Date firstClaimIndReserveDate;
    private Date firstClaimExpReserveDate;
    private Date firstClaimReserveDate;
    private Date firstSuffixIndReserveDate;
    private Date firstSuffixExpReserveDate;
    private Date firstSuffixReserveDate;


}
