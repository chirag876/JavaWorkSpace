package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Document("policy")
public class Policy {
    @Id
    @Column(insertable=false, updatable=false)
    private String id;
    private String quoteId;
    private Date cancellationDate;
    private String cancelReasonDescription;
    private String controllingStateOrProvinceCode;
    private Date effectiveDate;
    private Date expirationDate;
    private String policyId;
    private String lineofBusinessCode;
    private String number;
    private Date originalEffectiveDate;
    private String parentEntityId;
    private String parentEntityTypeName;
    private String statusCode;
    private double totalPremium;
    private int agentCode;
    private Date accountingDate;
    private int referalCode;
    private String renewalStatus;
    private String transactionType;
    @ElementCollection
    private List<Address> address = new ArrayList<>();
    private Coverage coverage;
    @ElementCollection
    private List<Insured> insured;
    private  long countryCode;
    private Producer producer;
    @ElementCollection
    private List<Reference> reference = new ArrayList<>();
    private Underwriter underwriter;
    private Claim claim;

}
