package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class DetailAddress {
    private String postDirectionCode;
    private String preDirectionCode;
    private String streetName;
    private String streetNumber;
    private String streetTypeCode;
    private String unitNumber;
}
