package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Policy;

import java.util.List;

public interface IPolicy {

    public Policy AddPolicy(Policy policy);

    public List<Policy> GetList();

    public Policy GetById(Long id);

    public Policy Update(Policy policy);

    public Policy Delete(Long id);
}
