package com.datapulse.Application.Policy.Query.GetPolicy;

import lombok.Data;

import java.util.List;

@Data

public class PolicyVm {
    public List<PolicyDTO> policyList;

    public PolicyVm(){}

    public PolicyVm(List<PolicyDTO> policyList) {
        this.policyList = policyList;
    }

    public List<PolicyDTO> getPolicyList() {
        return policyList;
    }

    public void setPolicyList(List<PolicyDTO> leadList) {
        this.policyList = leadList;
    }


}
