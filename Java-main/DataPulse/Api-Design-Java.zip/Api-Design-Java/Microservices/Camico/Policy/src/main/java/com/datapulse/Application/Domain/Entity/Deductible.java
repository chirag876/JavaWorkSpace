package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Deductible {
    @Column(insertable=false, updatable=false)
    private double amount;
    @Column(insertable=false, updatable=false)
    private String id;
    @Column(insertable=false, updatable=false)
    private String parentEntityId;
    @Column(insertable=false, updatable=false)
    private String parentEntityTypeName;
    @Column(insertable=false, updatable=false)
    private String typeCode;
}
