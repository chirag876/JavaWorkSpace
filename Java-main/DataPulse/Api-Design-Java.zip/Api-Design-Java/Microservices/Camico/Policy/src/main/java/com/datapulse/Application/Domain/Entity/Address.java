package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class Address {
    private String city;
    private String countryCode;
    private String countryName;
    private String line1;
    private String line2;
    private String postalCode;
    private String stateOrProvinceCode;
    private String stateOrProvinceName;
    private String addressId;
    private String latitude;
    private String longitude;
    @Column(insertable=false, updatable=false)
    private String parentEntityId;
    @Column(insertable=false, updatable=false)
    private String parentEntityTypeName;
    private String regionCode;
    private String regionName;
    private String subRegionCode;
    private String subRegionName;
    private String typeCode;

    private DetailAddress detailAddress;
//    @ElementCollection
//    private List<Reference> reference = new ArrayList<>();

}
