package com.datapulse.Application.Common.DAO;

import com.datapulse.Application.Domain.Entity.Policy;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

@Repository
@EnableMongoRepositories
public interface PolicyDAO extends MongoRepository<Policy,Long> {
}
