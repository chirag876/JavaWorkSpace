package com.datapulse.Application.Domain.Common;

import lombok.*;

import java.time.OffsetDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public abstract class AuditableEntity {
    private String createdBy;
    private Date createdDateTime;
    private String updatedBy;
    private Date updatedDateTime;
    private String updateReason;
    private String ownerId;
    private boolean isActive;
    private boolean isDeleted;
    private boolean isApproved;
    private String approverId;
    private OffsetDateTime approvedDateTime;
    private Boolean isAuthorized;
    private String authorizedById;
    private OffsetDateTime authorizedDateTime;
    private String sysData;
    private String tenantId;
    private String subTenantId;

}
