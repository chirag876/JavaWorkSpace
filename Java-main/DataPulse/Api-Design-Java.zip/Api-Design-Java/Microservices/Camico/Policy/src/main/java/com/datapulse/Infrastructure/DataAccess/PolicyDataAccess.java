package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;
import com.datapulse.Application.Common.DAO.PolicyDAO;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Common.Interface.IPolicy;
import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Policy;
import com.datapulse.Application.Domain.Events.PolicyCreatedEvent;
import com.datapulse.Application.Domain.Events.PolicyUpdatedEvent;
import com.datapulse.Application.Policy.EventHandler.PolicyCreatedEventHandler;
import com.datapulse.Application.Policy.EventHandler.PolicyUpdatedEventHandler;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class PolicyDataAccess implements IPolicy {

    Logger _logger = LoggerFactory.getLogger(PolicyDataAccess.class);

    @Autowired
    private PolicyDAO policyDAO;
    @Autowired
    private IDomainEventService domainEventService;

    @Override
    public Policy AddPolicy(Policy policy) {

        try {
            _logger.info("QuoteDataAccess.AddQuote - In process");


            policyDAO.save(policy);

        } catch (Exception ex) {
            _logger.error("QuoteDataAccess.AddQuote" + ex.getMessage());

        }
        DispatchEvents(policy);
        return policy;

    }

    @Override
    public List<Policy> GetList() {
        return policyDAO.findAll();

    }



    @Override
    public Policy GetById(Long id) {

        try {
            _logger.info("PolicyDataAccess.GetById - In process");
            return policyDAO.findById(id).get();
        } catch (Exception ex) {
            _logger.error("PolicyDataAccess.GetById" + ex.getMessage());

        }

        return policyDAO.findById(id).get();
    }

    @Override
    public Policy Update(Policy policy) {

        try {
            _logger.info("PolicyDataAccess.Update - In process");


            policyDAO.save(policy);

        } catch (Exception ex) {
            _logger.error("PolicyDataAccess.Update" + ex.getMessage());

        }
        UpdateDispatchEvents(policy);

        return policy;
    }

    @Override
    public Policy Delete(Long id) {
        return null;
    }


    // DispatchEvents

    public void DispatchEvents(Policy entity) {

        // Assuming you have a list of DomainEvent objects
//        List<DomainEvent> domainEvents = entity.;

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }

            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }

            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }

            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

//        domainEvents.add(domainEvent);


        domainEventService.Publish(domainEvent);

        _logger.info("Setting Pipeline for EventHandler");
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new PolicyCreatedEventHandler())
        );

        PolicyCreatedEvent policyCreatedEvent = new PolicyCreatedEvent();
        policyCreatedEvent.setPolicy(entity);
        policyCreatedEvent.send(pipeline);

    }

    public void UpdateDispatchEvents(Policy entity) {

        //  you have a list of DomainEvent objects


        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }

            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }

            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }

            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);
//
//       domainEvents.add(domainEvent);
        domainEventService.Publish(domainEvent);
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new PolicyUpdatedEventHandler())
        );

        PolicyUpdatedEvent policyUpdatedEvent = new PolicyUpdatedEvent();
        policyUpdatedEvent.setPolicy(entity);
        policyUpdatedEvent.send(pipeline);


//    }
    }
}
