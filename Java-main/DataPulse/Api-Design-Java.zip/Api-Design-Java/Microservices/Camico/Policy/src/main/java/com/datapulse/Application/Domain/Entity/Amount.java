package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Amount {
    @Column(insertable=false, updatable=false)
    private String appliesToCode;
    @Column(insertable=false, updatable=false)
    private String currencyCode;
    @Column(insertable=false, updatable=false)
    private String id;
    @Column(insertable=false, updatable=false)
    private String parentEntityId;
    @Column(insertable=false, updatable=false)
    private String parentEntityTypeName;
    @Column(insertable=false, updatable=false)
    private String typeCode;
    @Column(insertable=false, updatable=false)
    private int unitCount;
    @Column(insertable=false, updatable=false)
    private double value;
}
