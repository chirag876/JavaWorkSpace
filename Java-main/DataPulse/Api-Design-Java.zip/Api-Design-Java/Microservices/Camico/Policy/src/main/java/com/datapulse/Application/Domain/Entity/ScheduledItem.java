package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.util.Date;

@Data
@Embeddable
public class ScheduledItem {
    private String categoryCode;
    private String description;
    private Date effectiveDate;
    private Date expirationDate;
    @Column(insertable=false, updatable=false)
    private String id;
    @Column(insertable=false, updatable=false)
    private String parentEntityId;
    @Column(insertable=false, updatable=false)
    private String parentEntityTypeName;
    @Column(insertable=false, updatable=false)
    private Date purchasedDate;
    private Limit limit;

}
