package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class Coverage {
    @Column(insertable=false, updatable=false)
    private Date cancellationDate;
    @Column(insertable=false, updatable=false)
    private String cancellationReasonCode;
    private String description;
    @Column(insertable=false, updatable=false)
    private Date effectiveDate;
    @Column(insertable=false, updatable=false)
    private Date expirationDate;
    private String coverageId;
    @Column(insertable=false, updatable=false)
    private Date inceptionDate;
  @Column(insertable=false, updatable=false)
    private String lineofBusinessCode;
    @Column(insertable=false, updatable=false)
    private String parentEntityId;
    @Column(insertable=false, updatable=false)
    private String parentEntityTypeName;
    private String planName;
    @Column(insertable=false, updatable=false)
    private String premiumBasisCode;
    @Column(insertable=false, updatable=false)
    private String productCode;
    @Column(insertable=false, updatable=false)
    private String typeCode;
    private Deductible deductible;
    private Limit limit;
    @ElementCollection
    private List<Valuation> valuation = new ArrayList<>();

    private long id;
}
