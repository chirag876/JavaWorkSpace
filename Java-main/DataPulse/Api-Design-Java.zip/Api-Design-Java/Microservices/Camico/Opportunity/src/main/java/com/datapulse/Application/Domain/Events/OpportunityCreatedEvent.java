package com.datapulse.Application.Domain.Events;


import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Opportunity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@Component
@Setter
@Getter
public class OpportunityCreatedEvent implements Notification {
    private Opportunity opportunity;

    Logger logger = LoggerFactory.getLogger(OpportunityCreatedEvent.class);
    public OpportunityCreatedEvent(Opportunity opportunity){

        this.opportunity = opportunity;

        logger.info(" AccountCreatedEvent: " + opportunity);
    }

    public OpportunityCreatedEvent() {

    }
}
