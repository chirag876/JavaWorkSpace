package com.datapulse.Application.Domain.Events;

import an.awesome.pipelinr.Notification;

import com.datapulse.Application.Domain.Entity.Opportunity;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
@AllArgsConstructor

public class OpportunityUpdatedEvent implements Notification {
    private Opportunity opportunity;
    Logger logger = LoggerFactory.getLogger(OpportunityUpdatedEvent.class);

    public OpportunityUpdatedEvent(Opportunity opportunity){

        this.opportunity = opportunity;
        logger.info(" AccountUpdateEvent: " + opportunity);
    }

    public OpportunityUpdatedEvent() {

    }
}
