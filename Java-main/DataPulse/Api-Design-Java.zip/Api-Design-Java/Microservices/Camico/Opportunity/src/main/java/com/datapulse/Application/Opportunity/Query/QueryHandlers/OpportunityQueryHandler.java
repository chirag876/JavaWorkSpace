//package com.datapulse.Application.Opportunity.Query.QueryHandlers;
//
//import com.datapulse.Application.Common.Interface.IOpportunity;
//import com.datapulse.Application.Opportunity.Query.GetOpportunity.GetOpportunityQuery;
//import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
//import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityVm;
//import com.datapulse.Mediator.RequestHandler;
//import org.modelmapper.ModelMapper;
//import org.modelmapper.TypeToken;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//import java.util.UUID;
//
//@Component
//public class OpportunityQueryHandler implements RequestHandler<GetOpportunityQuery, OpportunityVm> {
//
//    ModelMapper mapper = new ModelMapper();
//    @Autowired
//    private IOpportunity _dataAcces;
//    @Override
//    public UUID uhandle(GetOpportunityQuery request) {
//        return null;
//    }
//
//    @Override
//    public OpportunityVm handle(GetOpportunityQuery request) {
//       OpportunityVm opportunityVm = new OpportunityVm();
//        opportunityVm.setOpportunityList(mapper.map(_dataAcces.GetList(), new TypeToken<List<OpportunityDTO>>() {}.getType()));
//        return opportunityVm;
//    }
//}
