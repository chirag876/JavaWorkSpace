package com.datapulse.Application.Opportunity.Query.GetOpportunity;

import com.datapulse.Mediator.Request;

public class GetOpportunityQuery implements Request<OpportunityVm> {
}
