package com.datapulse.Application.Opportunity.Query.GetOpportunity;

import lombok.Data;

import java.util.List;

@Data

public class OpportunityVm {
    public List<OpportunityDTO> opportunityList;

    public  OpportunityVm(){}

    public OpportunityVm(List<OpportunityDTO> opportunityList) {
        this.opportunityList = opportunityList;
    }

    public List<OpportunityDTO> getOpportunityList() {
        return opportunityList;
    }

    public void setOpportunityList(List<OpportunityDTO> opportunityList) {
        this.opportunityList = opportunityList;
    }


}
