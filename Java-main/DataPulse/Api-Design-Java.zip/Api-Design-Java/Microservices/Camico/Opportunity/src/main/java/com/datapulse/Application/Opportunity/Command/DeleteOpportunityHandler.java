//package com.datapulse.Application.Opportunity.Command;
//
//import com.datapulse.Application.Common.Interface.IOpportunity;
//import com.datapulse.Application.Domain.Entity.Opportunity;
//import com.datapulse.Application.Opportunity.Query.GetOpportunity.OpportunityDTO;
//import com.datapulse.Application.Opportunity.Request.CreateOpportunityRequest;
//import com.datapulse.Application.Opportunity.Request.DeleteOpportunityRequest;
//import com.datapulse.Mediator.RequestHandler;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.UUID;
//@Component
//public class DeleteOpportunityHandler implements RequestHandler<DeleteOpportunityRequest, String> {
//
//    Logger logger = LoggerFactory.getLogger(DeleteOpportunityHandler.class);
//
//
//    @Autowired
//    private IOpportunity opportunityDataAccess;
//    @Override
//    public UUID uhandle(DeleteOpportunityRequest request) {
//        return null;
//    }
//
//    @Override
//    public String handle(DeleteOpportunityRequest request) {
//        logger.info("DeleteOpportunityHandler: " + request);
//
//        Opportunity dto =  this.opportunityDataAccess.GetById(request.getId());
//        if (dto.getId().equals(request.getId())){
//
//        }
//
//        logger.info("DeleteOpportunityRequest.Handle - Completed");
//
//        return request.getId();
//    }
//}
