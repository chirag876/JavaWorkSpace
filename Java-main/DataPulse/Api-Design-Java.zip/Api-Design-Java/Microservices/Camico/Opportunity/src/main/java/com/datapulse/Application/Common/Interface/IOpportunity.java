package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Opportunity;
import org.bson.Document;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface IOpportunity {


    public List<Document> GetById(int id);


}
