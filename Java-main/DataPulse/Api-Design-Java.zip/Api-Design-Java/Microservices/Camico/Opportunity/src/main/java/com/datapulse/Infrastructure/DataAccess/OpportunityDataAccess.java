package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;

import com.datapulse.Application.Common.DAO.OpportunityDAO;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Common.Interface.IOpportunity;
import com.datapulse.Application.Domain.Common.DomainEvent;

import com.datapulse.Application.Domain.Entity.Opportunity;

import com.datapulse.Application.Domain.Events.OpportunityCreatedEvent;
import com.datapulse.Application.Domain.Events.OpportunityUpdatedEvent;
import com.datapulse.Application.Opportunity.EventHandler.OpportunityCreatedEventHandler;
import com.datapulse.Application.Opportunity.EventHandler.OpportunityUpdatedEventHandler;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@Service

public class OpportunityDataAccess implements IOpportunity {

    Logger _logger  =  LoggerFactory.getLogger(OpportunityDataAccess.class);

    @Autowired
    private OpportunityDAO opportunityDAO;
    @Autowired
    private IDomainEventService domainEventService;




    @Override
    public List<Document> GetById(int id) {

        int limit = id;
        List<Document> documents = new ArrayList<>();

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        MongoCollection<Document> collection = database.getCollection("opportunity");

        // Query for all documents in the collection
        documents = collection.find().limit(10).into(new ArrayList<>());


        try {
            _logger.info("OpportunityDataAccess.GetById - In process");

            return documents;

        }

        catch(Exception ex) {
            _logger.error("OpportunityDataAccess.GetById"+ex.getMessage());

        }

        return documents;
    }








}
