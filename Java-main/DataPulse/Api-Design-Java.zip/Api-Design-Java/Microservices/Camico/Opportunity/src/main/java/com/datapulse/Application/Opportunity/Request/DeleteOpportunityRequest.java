package com.datapulse.Application.Opportunity.Request;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteOpportunityRequest implements Request<String> {
    private String id;
}
