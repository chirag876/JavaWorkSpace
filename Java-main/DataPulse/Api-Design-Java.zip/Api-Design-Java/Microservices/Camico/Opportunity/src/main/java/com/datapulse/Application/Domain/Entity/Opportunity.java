package com.datapulse.Application.Domain.Entity;


import com.datapulse.Application.Domain.Common.AuditableEntity;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Document("opportunity")
@Getter
@Setter
public class Opportunity extends AuditableEntity {

    @Id
    private String id;

    @Field("account_name")

    private String accountName;

    @Field
    private Double amount;

    @Field("close_date")
    private String closeDate;

    @Field("lead_source")
    private String leadSource;

    @Field("opportunity_name")

    private String opportunityName;

    @Field
    private String stage;

    @Field
    private String type;
}
