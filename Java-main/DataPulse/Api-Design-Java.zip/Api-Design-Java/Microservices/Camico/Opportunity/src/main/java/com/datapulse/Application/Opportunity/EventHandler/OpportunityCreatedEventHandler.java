package com.datapulse.Application.Opportunity.EventHandler;

import an.awesome.pipelinr.Notification;

import com.datapulse.Application.Domain.Entity.Opportunity;

import com.datapulse.Application.Domain.Events.OpportunityCreatedEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class OpportunityCreatedEventHandler implements Notification.Handler<OpportunityCreatedEvent> {


    Logger _logger = LoggerFactory.getLogger(OpportunityCreatedEventHandler.class);
    private  Opportunity opportunity;
    public OpportunityCreatedEventHandler(){}

    @Override
    public void handle(OpportunityCreatedEvent notification) {

        opportunity= new OpportunityCreatedEvent(notification.getOpportunity()).getOpportunity();
        _logger.info("OpportunityCreatedEventHandler "+ notification.getOpportunity());

        opportunity = notification.getOpportunity();

        opportunity.setId(notification.getOpportunity().getId());
        opportunity.setAccountName(notification.getOpportunity().getAccountName());
        opportunity.setOpportunityName(notification.getOpportunity().getOpportunityName());
        opportunity.setAmount(notification.getOpportunity().getAmount());
        opportunity.setStage(notification.getOpportunity().getStage());
        opportunity.setCloseDate(notification.getOpportunity().getCloseDate());
        opportunity.setLeadSource(notification.getOpportunity().getLeadSource());
        opportunity.setType(notification.getOpportunity().getType());

        _logger.info("Opportunity Event: "+ opportunity);

    }


    // Kafka implementation for Events
    private void handleKafka(OpportunityCreatedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }


}
