package com.camico.Application.Common.Interface;//package com.datapulse.Application.Common.Interface;
//
//import java.util.List;
//
//import org.springframework.stereotype.Repository;
//
//import com.datapulse.Application.Domain.Entity.PolicyDataExtration;
//
//@Repository
//public interface IPolicyDataExtrationDataAccess {
//
//	public PolicyDataExtration addData(PolicyDataExtration policyDataExtration);
//	public List<PolicyDataExtration> getData();
//}
