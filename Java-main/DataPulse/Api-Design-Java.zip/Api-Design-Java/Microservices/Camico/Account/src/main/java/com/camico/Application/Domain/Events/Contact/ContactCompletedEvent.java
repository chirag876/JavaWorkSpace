package com.camico.Application.Domain.Events.Contact;


import com.camico.Application.Domain.Common.DomainEvent;
import com.camico.Application.Domain.Entity.Contact;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ContactCompletedEvent extends DomainEvent {
	
	
	Logger _logger = LoggerFactory.getLogger(ContactCompletedEvent.class);	
	private Contact contact;

	public ContactCompletedEvent(Contact contact) {
		_logger.info("ContactCompletedEvent- ");
		
		this.contact = contact;
	}

	public Contact getContact() {
		return contact;
	}	
	
}
