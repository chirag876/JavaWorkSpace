package com.camico.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;

import com.camico.Application.Common.DAO.AccountDAO;
import com.camico.Application.Common.Interface.IAccount;
import com.camico.Application.Common.Interface.IDomainEventService;
import com.camico.Application.Domain.Common.DomainEvent;
import com.camico.Application.Domain.Entity.Account.Account;
import com.camico.Application.Domain.Events.Account.AccountCreatedEvent;
import com.camico.Application.Domain.Events.Account.AccountUpdatedEvent;
import com.mongodb.client.*;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service

public class AccountDataAccess implements IAccount {

    Logger _logger  =  LoggerFactory.getLogger(AccountDataAccess.class);

    @Autowired
    private AccountDAO accountDAO;
    @Autowired
    private IDomainEventService domainEventService;


    @Override
    public List<Document> GetList() {

        List<Document> documents = new ArrayList<>();

        try (MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/")) {
            MongoDatabase database = mongoClient.getDatabase("camico");
            MongoCollection<org.bson.Document> collection = database.getCollection("account");

            // Query for all documents in the collection
            documents = collection.find().limit(10).into(new ArrayList<>());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return documents;
    }



    @Override
    public List<Document> GetById(int id) {
        int limit = id;
        List<Document> documents = new ArrayList<>();

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        MongoCollection<org.bson.Document> collection = database.getCollection("account");

            // Query for all documents in the collection
        documents = collection.find().limit(10).into(new ArrayList<>());


        try {
            _logger.info("AccountDataAccess.GetById - In process");

            return documents;

        }

        catch(Exception ex) {
            _logger.error("AccountDataAccess.GetById"+ex.getMessage());

        }

        return documents;
    }



}
