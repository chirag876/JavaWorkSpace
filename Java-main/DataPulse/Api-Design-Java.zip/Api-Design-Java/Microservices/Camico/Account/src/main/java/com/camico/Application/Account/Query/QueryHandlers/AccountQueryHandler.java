package com.camico.Application.Account.Query.QueryHandlers;

import com.camico.Application.Account.Query.GetAccount.AccountDTO;
import com.camico.Application.Account.Query.GetAccount.AccountVm;
import com.camico.Application.Account.Query.GetAccount.GetAccountQuery;
import com.camico.Application.Common.Interface.IAccount;
import com.camico.Mediator.RequestHandler;
import org.bson.Document;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class AccountQueryHandler implements RequestHandler<GetAccountQuery, List<Document>> {

    Logger _logger = LoggerFactory.getLogger(AccountQueryHandler.class);
    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IAccount _dataAcces;
    @Override
    public UUID uhandle(GetAccountQuery request) {
        return null;
    }

    @Override
    public List<Document> handle(GetAccountQuery request) {
        List<Document> accountList =_dataAcces.GetById(request.getId());

        return accountList;
    }
}
