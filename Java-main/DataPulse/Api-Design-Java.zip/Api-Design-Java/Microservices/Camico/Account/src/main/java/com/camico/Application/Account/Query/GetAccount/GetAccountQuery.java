package com.camico.Application.Account.Query.GetAccount;

import com.camico.Mediator.Request;
import lombok.Data;
import org.bson.Document;

import java.util.List;
@Data
public class GetAccountQuery implements Request<List<Document>> {
    private int id;
}
