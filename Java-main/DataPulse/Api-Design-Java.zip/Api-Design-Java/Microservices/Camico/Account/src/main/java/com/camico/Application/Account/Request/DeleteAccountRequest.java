package com.camico.Application.Account.Request;

import com.camico.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteAccountRequest implements Request<String> {
    private String id;
}
