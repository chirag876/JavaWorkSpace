package com.camico.Application.Domain.Common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class AuditableEntity {
    private String createdBy;
    private OffsetDateTime createdDateTime;
    private String updatedBy;
    private OffsetDateTime updatedDateTime;
    private String updateReason;
    private String ownerId;
    private boolean isActive;
    private boolean isDeleted;
    private boolean isApproved;
    private String approverId;
    private OffsetDateTime approvedDateTime;
    private Boolean isAuthorized;
    private String authorizedById;
    private OffsetDateTime authorizedDateTime;
    private String sysData;
    private String tenantId;
    private String subTenantId;

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public OffsetDateTime getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = OffsetDateTime.now(ZoneOffset.UTC);;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public OffsetDateTime getUpdatedDateTime() {
        return updatedDateTime;
    }

    public void setUpdatedDateTime(Date updatedDateTime) {
        this.updatedDateTime = OffsetDateTime.now(ZoneOffset.UTC);
    }

    public String getUpdateReason() {
        return updateReason;
    }

    public void setUpdateReason(String updateReason) {
        this.updateReason = updateReason;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }

    public String getApproverId() {
        return approverId;
    }

    public void setApproverId(String approverId) {
        this.approverId = approverId;
    }

    public OffsetDateTime getApprovedDateTime() {
        return approvedDateTime;
    }

    public void setApprovedDateTime(Date approvedDateTime) {
        this.approvedDateTime = OffsetDateTime.now(ZoneOffset.UTC);
    }

    public Boolean getAuthorized() {
        return isAuthorized;
    }

    public void setAuthorized(Boolean authorized) {
        isAuthorized = authorized;
    }

    public String getAuthorizedById() {
        return authorizedById;
    }

    public void setAuthorizedById(String authorizedById) {
        this.authorizedById = authorizedById;
    }

    public OffsetDateTime getAuthorizedDateTime() {
        return authorizedDateTime;
    }

    public void setAuthorizedDateTime(Date authorizedDateTime) {
        this.authorizedDateTime = OffsetDateTime.now(ZoneOffset.UTC);
    }

    public String getSysData() {
        return sysData;
    }

    public void setSysData(String sysData) {
        this.sysData = sysData;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getSubTenantId() {
        return subTenantId;
    }

    public void setSubTenantId(String subTenantId) {
        this.subTenantId = subTenantId;
    }
}
