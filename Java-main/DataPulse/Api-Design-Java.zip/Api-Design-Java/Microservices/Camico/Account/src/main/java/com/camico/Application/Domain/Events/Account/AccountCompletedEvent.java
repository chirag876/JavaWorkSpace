package com.camico.Application.Domain.Events.Account;

import an.awesome.pipelinr.Notification;
import com.camico.Application.Domain.Common.DomainEvent;
import com.camico.Application.Domain.Entity.Account.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AccountCompletedEvent extends DomainEvent implements Notification {
    Logger _logger = LoggerFactory.getLogger(AccountCompletedEvent.class);
    private Account account;

    public AccountCompletedEvent(Account account) {
        _logger.info("AccountCompletedEvent- ");

        this.account = account;
    }

    public Account getAccount() {
        return account;
    }
}
