package com.camico.Application.Account.Query.GetAccount;

import com.camico.Application.Domain.Entity.Account.Contacts;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Data
@Setter
@Getter
public class AccountDTO {


}
