package com.camico.Application.Common.Interface;

import org.slf4j.Logger;

public interface ILogger<T> extends Logger {
	
	// Logger _logger = LoggerFactory.getLogger();

}
