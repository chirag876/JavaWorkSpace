package com.camico.Application.Common.Interface;

import com.camico.Application.Domain.Entity.Account.Account;
import org.bson.Document;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IAccount {

    public List<Document> GetList();

    public  List<Document> GetById(int id);

}
