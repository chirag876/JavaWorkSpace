package com.camico.Application.Account.Query.GetAccountById;

import com.camico.Application.Account.Query.GetAccount.AccountDTO;
import com.camico.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetAccountByIdQuery implements Request<List<Document>> {
    private int id;

}
