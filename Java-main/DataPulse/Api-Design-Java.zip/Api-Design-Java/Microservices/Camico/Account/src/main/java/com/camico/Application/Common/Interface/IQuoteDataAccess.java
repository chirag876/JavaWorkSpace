package com.camico.Application.Common.Interface;//package com.datapulse.Application.Common.Interface;
//
//import java.util.List;
//import java.util.UUID;
//
//
//
//import org.springframework.stereotype.Repository;
//
//import com.datapulse.Application.Domain.Entity.Quote;
//
//@Repository
//
//public interface IQuoteDataAccess {
//
//	public Quote AddQuote(Quote quote);
//
//	public List<Quote> GetList();
//
//	public Quote GetById(UUID id);
//
//	public Quote Update(Quote quote);
//
//	public UUID delete(UUID id);
//
//}
