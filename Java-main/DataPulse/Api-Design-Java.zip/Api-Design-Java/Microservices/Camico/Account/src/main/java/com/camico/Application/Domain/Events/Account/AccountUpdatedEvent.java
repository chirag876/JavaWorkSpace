package com.camico.Application.Domain.Events.Account;

import an.awesome.pipelinr.Notification;
import com.camico.Application.Domain.Entity.Account.Account;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
@AllArgsConstructor

public class AccountUpdatedEvent implements Notification {
    private Account account;
    Logger logger = LoggerFactory.getLogger(AccountCreatedEvent.class);

    public  AccountUpdatedEvent(Account account){
        logger.info(" AccountUpdateEvent: " + account);
    }

    public AccountUpdatedEvent() {

    }
}
