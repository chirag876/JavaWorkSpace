package com.camico.API.Controller;

import com.camico.Application.Account.Query.GetAccount.AccountDTO;
import com.camico.Application.Account.Query.GetAccount.AccountVm;
import com.camico.Application.Account.Query.GetAccount.GetAccountQuery;
import com.camico.Application.Account.Query.GetAccountById.GetAccountByIdQuery;
import com.camico.Application.Account.Request.CreateAccountRequest;
import com.camico.Application.Account.Request.DeleteAccountRequest;
import com.camico.Application.Account.Request.UpdateAccountRequest;
import com.camico.Application.Common.Interface.IAccount;
import com.camico.Application.Domain.Entity.Account.Account;
import com.camico.Mediator.Mediator;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("Account")
@CrossOrigin("*")
public class AccountController {

    private Mediator _mediator;
    @Autowired
    private IAccount _dataAccess;



    public AccountController(Mediator _mediator) { this._mediator = _mediator;  }



    @PostMapping("/Create")
    public String Create(@RequestBody CreateAccountRequest request) {
        //return this.contactDataAccess.AddContact(request);

        return	_mediator.send(request);


    }

//    @GetMapping()
//    public AccountVm getAllContact(){
//
//        return _mediator.send(new GetAccountQuery());
//
//    }

    @GetMapping()
    public List<Document> getContactById( int Limit){

//        return _mediator.send(new GetAccountByIdQuery(Limit));

        List<Document> accountList = _dataAccess.GetById(Limit);
        return accountList;
    }

//    @PutMapping("/{id}")
//    public String  Update(@PathVariable String id,
//                          @RequestBody UpdateAccountRequest request){
//
//
//        Account account = _dataAccess.GetById(id);
//
//        if (account.getId().equals(id)){
//            return _mediator.send(request);
//
//        }
//        return "User Not Found..";
//    }

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable String id){
        return _mediator.send(new DeleteAccountRequest(id));
    }


}
