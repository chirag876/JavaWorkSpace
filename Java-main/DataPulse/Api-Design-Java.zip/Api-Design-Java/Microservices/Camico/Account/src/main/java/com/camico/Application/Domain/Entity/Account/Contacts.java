package com.camico.Application.Domain.Entity.Account;


import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class Contacts {



    @Column(insertable=false, updatable=false)
    private String id;

    @Field("FirstName")
    private String firstName;

    @Field("LastName")
    private String lastName;

    @Field("AccountName")
    private String accountName;

    @Field("PhoneNumber")
    private String phone;

    @Field("EmailAddress")
    private String email;

    @Field("MailingCity")
    private String mailingCity;

    @Field("MailingState")
    private String mailingState;

    @Field("MailingCountry")
    private String mailingCountry;

    @Field("MailingZipCode")
    private String mailingZipCode;

}
