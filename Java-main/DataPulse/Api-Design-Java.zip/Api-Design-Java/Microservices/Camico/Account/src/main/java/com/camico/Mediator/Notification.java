package com.camico.Mediator;

public interface Notification {

}
