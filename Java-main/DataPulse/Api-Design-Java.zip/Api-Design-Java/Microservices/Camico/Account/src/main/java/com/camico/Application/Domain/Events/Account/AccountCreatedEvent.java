package com.camico.Application.Domain.Events.Account;

import an.awesome.pipelinr.Notification;
import com.camico.Application.Domain.Entity.Account.Account;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@Component
@Setter
@Getter
public class AccountCreatedEvent implements Notification {
    private Account account;

    Logger logger = LoggerFactory.getLogger(AccountCreatedEvent.class);
    public  AccountCreatedEvent(Account account){
        logger.info(" AccountCreatedEvent: " + account);
    }

    public AccountCreatedEvent() {

    }
}
