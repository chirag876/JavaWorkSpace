package com.camico.Mediator;

/**
*
* @param <T> The type of response that will be produced when handling the request.
*/
public interface Request<T> {

}
