package com.camico.Application.Domain.Events.Contact;


import com.camico.Application.Domain.Common.DomainEvent;
import com.camico.Application.Domain.Entity.Contact;

public class ContactCreatedEvent extends DomainEvent {
	
	private Contact contact;

	public ContactCreatedEvent(Contact contact) {
		this.contact = contact;		
	}
	public Contact getContact() {
		return contact;
	}
	
}
