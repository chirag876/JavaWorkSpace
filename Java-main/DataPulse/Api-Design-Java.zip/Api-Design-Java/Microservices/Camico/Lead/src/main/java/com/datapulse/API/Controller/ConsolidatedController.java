package com.datapulse.API.Controller;

import com.datapulse.Application.Consolidated.CreateSelectedColumnsGroup.CreateSelectedColumnsGroup;
import com.datapulse.Application.Consolidated.CreateVisibleColumns.CreateVisibleColumnsRequest;
import com.datapulse.Application.Consolidated.GetColumnsValue.GetVisibleColumnsValueQuery;
import com.datapulse.Application.Consolidated.GetHeaders.GetHeaders;
import com.datapulse.Application.Consolidated.Query.GetColumns.GetColumns;
import com.datapulse.Application.Consolidated.Query.GetConsolidated.ConsolidatedVm;
import com.datapulse.Application.Consolidated.Query.GetConsolidated.GetConsolidatedListQuery;
import com.datapulse.Application.Consolidated.Query.GetSelectedColumnsGroupRecords.GetSelectedColumnsGroupRecords;
import com.datapulse.Application.Consolidated.Query.GetSelectedColumnsGroupRecords.SelectedColumnsGroupRecordsVm;
import com.datapulse.Application.Lead.Query.GetLead.GetLeadQuery;
import com.datapulse.Application.Lead.Query.GetLead.LeadVm;
import com.datapulse.Mediator.Mediator;
import com.google.gson.Gson;
import org.bson.BsonDocument;
import org.bson.Document;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("Consolidate")
public class ConsolidatedController {

    private Mediator _mediator;
    public ConsolidatedController(Mediator _mediator) { this._mediator = _mediator;  }

    @GetMapping()
    public ResponseEntity<?> GetConsolidatedList(int Limit) {
       ConsolidatedVm vm =  _mediator.send(new GetConsolidatedListQuery(Limit));

        return new ResponseEntity<>(vm.getConsolidate(), HttpStatus.OK);
    }

//    @GetMapping("/GroupedColumnsRecords")
//    public ResponseEntity<?> GetColumns(String ObjectName){
//       SelectedColumnsGroupRecordsVm vm = _mediator.send(new GetSelectedColumnsGroupRecords(ObjectName));
//       return new ResponseEntity<>(vm.getSelectedGroupVm(), HttpStatus.OK);
//
//    }

    @GetMapping("/SelectedColumnsList")
    public ResponseEntity<?> GetColumns(String ObjectName){
      BsonDocument document =  this._mediator.send(new GetColumns(ObjectName));

      return  new ResponseEntity<>( document.toJson(), HttpStatus.OK);
    }

    @PostMapping("/SaveVisibleColumns")
    public ResponseEntity<?> SaveEntityIsVisibleList(@RequestBody CreateVisibleColumnsRequest request){
           Boolean result =  _mediator.send(request);
           return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @PostMapping("/GetHeaders")
    public ResponseEntity<?> GetHeaders(@RequestBody GetHeaders request){
            BsonDocument docs = _mediator.send(request);
        Gson gson = new Gson();
        String jsonString = gson.toJson(docs);
        return new ResponseEntity<>(jsonString, HttpStatus.OK);
    }

    @PostMapping("/GroupingSelectedColumns")
    public ResponseEntity<?> CreateSelectedColumnsGroup(@RequestBody CreateSelectedColumnsGroup request){
        String result = this._mediator.send(request);
        return new ResponseEntity<>(result,HttpStatus.OK);
    }

    @PostMapping("/SelectedColumnValue")
    public ResponseEntity<?> GetSelectedColumnValue(@RequestBody GetVisibleColumnsValueQuery request){

        List<Document> documents =  this._mediator.send(request).getDocuments();
        return  new ResponseEntity<>(documents, HttpStatus.OK);

    }


}
