package com.datapulse.Application.Consolidated.GetColumnsValue;

import lombok.Data;
import org.bson.BsonDocument;
import org.bson.Document;

import java.util.List;

@Data
public class GetVisibleColumnsValueQueryVm {
    public List<Document> documents;
}
