package com.datapulse.Application.Consolidated.Command;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Consolidated.CreateSelectedColumnsGroup.CreateSelectedColumnsGroup;
import com.datapulse.Application.Consolidated.CreateVisibleColumns.ColumnsVisibilityVM;
import com.datapulse.Application.Consolidated.GetColumnsValue.GetVisibleColumnsValueQuery;
import com.datapulse.Application.Consolidated.GetColumnsValue.GetVisibleColumnsValueQueryVm;
import com.datapulse.Mediator.RequestHandler;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class CreateSelectedColumnsGroupQueryHandler implements RequestHandler<GetVisibleColumnsValueQuery, GetVisibleColumnsValueQueryVm> {

    @Autowired
    private IConsolidatedDataAccess dataAccess;

    @Override
    public UUID uhandle(GetVisibleColumnsValueQuery request) {
        return null;
    }

    @Override
    public GetVisibleColumnsValueQueryVm handle(GetVisibleColumnsValueQuery request) {
        GetVisibleColumnsValueQueryVm vm = new GetVisibleColumnsValueQueryVm();
        List<Document> documents = this.dataAccess.getEntityIsVisibleList(request.getColumnsVisibilityVM(), request.getLimit());

        vm.setDocuments( documents);
        return vm;
    }
}
