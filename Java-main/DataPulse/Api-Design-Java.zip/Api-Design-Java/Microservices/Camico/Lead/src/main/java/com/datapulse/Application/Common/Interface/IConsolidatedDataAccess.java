package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Consolidated.CreateSelectedColumnsGroup.ColoumnsGroupVm;
import com.datapulse.Application.Consolidated.CreateVisibleColumns.ColumnsVisibilityVM;
import com.datapulse.Application.Domain.Entity.ColumnsVisibility;
import org.bson.BsonDocument;
import org.bson.Document;

import java.util.List;

public interface IConsolidatedDataAccess {

    public List<Document> GetConsolidatedList(int Limit);

    public List<Document> GetVisibleColumnsFromGroup(String groupName);

    public Boolean SaveEntityIsVisibleList(ColumnsVisibilityVM columnsVisibilityVM);

    public BsonDocument GetHeaders(List<ColumnsVisibility> jsonData, String collectionName);

    public String AddSelectedColumnsGroup(ColoumnsGroupVm coloumnsGroupVm);

    public List<Document> getEntityIsVisibleList(ColumnsVisibilityVM columnsVisibilityVM, int limit);

    public BsonDocument GetColumns(String ObjectName);
}
