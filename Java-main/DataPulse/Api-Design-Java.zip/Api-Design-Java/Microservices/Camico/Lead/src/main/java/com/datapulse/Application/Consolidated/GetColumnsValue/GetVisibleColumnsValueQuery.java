package com.datapulse.Application.Consolidated.GetColumnsValue;

import com.datapulse.Application.Consolidated.CreateVisibleColumns.ColumnsVisibilityVM;
import com.datapulse.Mediator.Request;
import lombok.Data;

@Data
public class GetVisibleColumnsValueQuery implements Request<GetVisibleColumnsValueQueryVm> {
    public ColumnsVisibilityVM columnsVisibilityVM;
    public int limit;
}
