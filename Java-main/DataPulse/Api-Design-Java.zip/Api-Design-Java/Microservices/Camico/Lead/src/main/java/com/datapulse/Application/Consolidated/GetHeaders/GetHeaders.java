package com.datapulse.Application.Consolidated.GetHeaders;

import com.datapulse.Application.Domain.Entity.ColumnsVisibility;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.BsonDocument;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetHeaders implements Request<BsonDocument> {
    public List<ColumnsVisibility> columnsVisibility;
    public String collectionName;
}
