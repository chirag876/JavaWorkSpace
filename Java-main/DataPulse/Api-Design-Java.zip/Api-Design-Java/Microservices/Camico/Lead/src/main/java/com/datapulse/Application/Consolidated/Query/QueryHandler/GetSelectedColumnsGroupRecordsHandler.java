package com.datapulse.Application.Consolidated.Query.QueryHandler;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Consolidated.Query.GetConsolidated.ConsolidatedVm;
import com.datapulse.Application.Consolidated.Query.GetConsolidated.GetConsolidatedListQuery;
import com.datapulse.Application.Consolidated.Query.GetSelectedColumnsGroupRecords.GetSelectedColumnsGroupRecords;
import com.datapulse.Application.Consolidated.Query.GetSelectedColumnsGroupRecords.SelectedColumnsGroupRecordsVm;
import com.datapulse.Mediator.RequestHandler;
import org.bson.Document;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class GetSelectedColumnsGroupRecordsHandler implements RequestHandler<GetSelectedColumnsGroupRecords, SelectedColumnsGroupRecordsVm> {


    Logger logger = LoggerFactory.getLogger(GetSelectedColumnsGroupRecordsHandler.class);
    ModelMapper mapper = new ModelMapper();

    @Autowired
    private IConsolidatedDataAccess _dataAcces;

    @Override
    public UUID uhandle(GetSelectedColumnsGroupRecords request) {
        return null;
    }

    @Override
    public SelectedColumnsGroupRecordsVm handle(GetSelectedColumnsGroupRecords request) {

        SelectedColumnsGroupRecordsVm vm = new SelectedColumnsGroupRecordsVm();
        List<Document> documents = _dataAcces.GetVisibleColumnsFromGroup(request.getGroupName());
        vm.setSelectedGroupVm(documents);
        return vm;

    }
}
