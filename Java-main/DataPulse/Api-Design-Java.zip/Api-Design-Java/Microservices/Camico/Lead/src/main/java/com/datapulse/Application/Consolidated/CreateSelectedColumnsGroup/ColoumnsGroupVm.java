package com.datapulse.Application.Consolidated.CreateSelectedColumnsGroup;

import com.datapulse.Application.Domain.Entity.ColumnsGroup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColoumnsGroupVm {
    public String groupName;
    public String collectionName;
    public List<ColumnsGroup> columnsGroups;
}
