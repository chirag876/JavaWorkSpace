package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.yaml.snakeyaml.events.Event;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class ColumnsGroupRecord {

    public String GroupName;
    public String CollectionName;
    public List<ColumnsGroup> columnsGroup = new ArrayList<>();
}
