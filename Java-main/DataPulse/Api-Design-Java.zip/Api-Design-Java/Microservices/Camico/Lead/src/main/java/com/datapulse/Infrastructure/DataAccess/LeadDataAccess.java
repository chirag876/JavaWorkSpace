package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;
import com.datapulse.Application.Common.DAO.LeadDAO;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Events.LeadCreatedEvent;
import com.datapulse.Application.Domain.Events.LeadUpdatedEvent;
import com.datapulse.Application.Lead.EventHandler.LeadCreatedEventHandler;
import com.datapulse.Application.Lead.EventHandler.LeadUpdatedEventHandler;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@Service
public class LeadDataAccess implements ILead {

    Logger _logger = LoggerFactory.getLogger(LeadDataAccess.class);

    @Autowired
    private LeadDAO leadDAO;
    @Autowired
    private IDomainEventService domainEventService;

    @Override
    public List<Document> GetList() {
        return null;
    }

    @Override
    public List<Document> GetById(int id) {

        int limit = id;
        List<Document> documents = new ArrayList<>();

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        MongoCollection<Document> collection = database.getCollection("lead");

        // Query for all documents in the collection
        documents = collection.find().limit(id).into(new ArrayList<>());

        try {
            _logger.info("LeadDataAccess.GetById - In process");
            return documents;

        } catch (Exception ex) {
            _logger.error("LeadDataAccess.GetById" + ex.getMessage());

        }
        return documents;
    }



  }
