package com.datapulse.Application.Common.DAO;

import org.springframework.data.mongodb.repository.MongoRepository;


