package com.datapulse.Application.Consolidated.Query.QueryHandler;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Consolidated.Query.GetColumns.GetColumns;
import com.datapulse.Mediator.RequestHandler;
import org.bson.BsonDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class GetColumnsHandler implements RequestHandler<GetColumns, BsonDocument> {

    @Autowired
    private IConsolidatedDataAccess dataAccess;

    @Override
    public UUID uhandle(GetColumns request) {
        return null;
    }

    @Override
    public BsonDocument handle(GetColumns request) {
        BsonDocument document = this.dataAccess.GetColumns(request.getObjectName());
        return document;
    }
}
