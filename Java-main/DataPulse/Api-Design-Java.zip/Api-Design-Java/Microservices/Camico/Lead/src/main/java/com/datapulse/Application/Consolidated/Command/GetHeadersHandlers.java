package com.datapulse.Application.Consolidated.Command;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Consolidated.GetHeaders.GetHeaders;
import com.datapulse.Mediator.Request;
import com.datapulse.Mediator.RequestHandler;
import org.bson.BsonDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class GetHeadersHandlers implements RequestHandler<GetHeaders, BsonDocument> {


    @Autowired
    private IConsolidatedDataAccess dataAccess;
    @Override
    public UUID uhandle(GetHeaders request) {
        return null;
    }

    @Override
    public BsonDocument handle(GetHeaders request) {
        BsonDocument headersList = dataAccess.GetHeaders(request.columnsVisibility, request.collectionName);
        return headersList;
    }
}
