package com.datapulse.Mediator;

//public interface NotificationHandler<TNotification extends Notification> {
//
//	void handle(List<TNotification> notification);
//
//}

import java.util.concurrent.CompletableFuture;

public interface NotificationHandler<TNotification extends Notification> {
	CompletableFuture<Void> handle(TNotification notification);
}
