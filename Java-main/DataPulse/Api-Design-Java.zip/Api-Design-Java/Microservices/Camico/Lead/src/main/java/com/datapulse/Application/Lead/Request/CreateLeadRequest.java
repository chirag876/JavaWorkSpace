package com.datapulse.Application.Lead.Request;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateLeadRequest implements Request<String> {
    private String id;
    private String firstName;
    private String lastName;
    private String phone;
    private String company;
    private String title;
    private String leadSource;
    private String email;
    private String leadStatus;
    private String website;
    private String industry;
    private Double annualRevenue;
    private String createdDate;

}
