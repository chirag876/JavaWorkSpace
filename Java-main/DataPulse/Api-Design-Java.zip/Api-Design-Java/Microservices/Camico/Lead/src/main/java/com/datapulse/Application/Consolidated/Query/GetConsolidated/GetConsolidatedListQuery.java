package com.datapulse.Application.Consolidated.Query.GetConsolidated;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GetConsolidatedListQuery implements Request<ConsolidatedVm> {
    private int Limit;
}
