package com.datapulse.Application.Consolidated.Command;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Consolidated.GetColumnsValue.GetVisibleColumnsValueQuery;
import com.datapulse.Application.Consolidated.GetColumnsValue.GetVisibleColumnsValueQueryVm;
import com.datapulse.Mediator.RequestHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

//@Component
//public class GetVisibleColumnsValueQueryHandler implements RequestHandler<GetVisibleColumnsValueQuery, GetVisibleColumnsValueQueryVm> {
//
//    @Autowired
//    private IConsolidatedDataAccess dataAccess;
//    @Override
//    public UUID uhandle(GetVisibleColumnsValueQuery request) {
//        return null;
//    }
//
//    @Override
//    public GetVisibleColumnsValueQueryVm handle(GetVisibleColumnsValueQuery request) {
//        GetVisibleColumnsValueQueryVm vm = new GetVisibleColumnsValueQueryVm();
//        vm.setDocuments(this.dataAccess.getEntityIsVisibleList(request.getColumnsVisibilityVM(), request.getLimit()));
//        return vm;
//    }
//}
