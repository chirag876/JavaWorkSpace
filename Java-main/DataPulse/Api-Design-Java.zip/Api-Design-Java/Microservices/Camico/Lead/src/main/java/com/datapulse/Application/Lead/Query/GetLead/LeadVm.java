package com.datapulse.Application.Lead.Query.GetLead;

import lombok.Data;
import org.bson.Document;

import java.util.List;

@Data
public class LeadVm {
    private List<Document> lead;
}
