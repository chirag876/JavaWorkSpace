package com.datapulse.Infrastructure.DataAccess;

import com.datapulse.Application.Common.DAO.LeadDAO;
import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Consolidated.CreateSelectedColumnsGroup.ColoumnsGroupVm;
import com.datapulse.Application.Consolidated.CreateVisibleColumns.ColumnsVisibilityVM;
import com.datapulse.Application.Domain.Entity.ColumnsGroup;
import com.datapulse.Application.Domain.Entity.ColumnsVisibility;
import com.google.gson.Gson;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import org.bson.BsonArray;
import org.bson.BsonDocument;
import org.bson.BsonString;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ConsolidatedDataAccess  implements IConsolidatedDataAccess {

    Logger _logger = LoggerFactory.getLogger(ConsolidatedDataAccess.class);

    @Autowired
    private LeadDAO leadDAO;
    @Autowired
    private IDomainEventService domainEventService;

    @Override
    public List<Document> GetConsolidatedList(int Limit) {
        List<Document> documents = new ArrayList<>();

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        MongoCollection<Document> collection = database.getCollection("Consolidated19");

        // Query for all documents in the collection

        switch (Limit) {
            case 0:
                break;
            default:
                documents = collection.find().limit(Limit).into(new ArrayList<>());
                break;
        }
        return documents;

    }

    @Override
    public List<Document> GetVisibleColumnsFromGroup(String groupName) {

        List<Document> documents = new ArrayList<>();

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        MongoCollection<Document> collection = database.getCollection("Columns_Visibility");
        Document groupDocument = collection.find(Filters.eq("GroupName", groupName)).first();

        String collectionName = groupName.toString();

        if (groupDocument != null) {
            List<Document> columnsGroup = groupDocument.get("columnsGroup", List.class);
            List<String> visibleColumns = new ArrayList<>();

            for (Document columnGroup : columnsGroup) {
                boolean isVisible = columnGroup.getBoolean("IsVisible");

                if (isVisible) {
                    String columnName = columnGroup.getString("ColumnName");

                    if (columnName != null && !columnName.isEmpty()) {
                        visibleColumns.add(columnName);
                    }
                }
            }

            if (!visibleColumns.isEmpty()) {
                MongoCollection<Document> accountCollection = database.getCollection(collectionName);
                List<Bson> projectionFields = new ArrayList<>();

                // Include the _id field by default
                projectionFields.add(Projections.excludeId());

                // Include the specified columns
                for (String columnName : visibleColumns) {
                    projectionFields.add(Projections.include(columnName));
                }

                // Create the dynamic projection
                Document projection = (Document) Projections.fields(projectionFields);

                FindIterable<Document> cursor = accountCollection.find()
                        .projection(projection)
                        .limit(25);

                documents = cursor.into(new ArrayList<>());
            }
        }


        return documents;
    }

    @Override
    public Boolean SaveEntityIsVisibleList(ColumnsVisibilityVM columnsVisibilityVM) {

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");


        try {
            // Update Columns_Visibility Collection
            MongoCollection<ColumnsVisibilityVM> collectionColumnsVisibility = database.getCollection("Columns_Visibility", ColumnsVisibilityVM.class);

            Bson filterTrue = Filters.eq("CollectionName", columnsVisibilityVM.getCollectionName());
            Document updateDocument = Document.parse(new Gson().toJson(columnsVisibilityVM));

            // Define the update operation to set the specified field
            Bson update = Updates.set("ColumnsVisibility", updateDocument.get("ColumnsVisibility"));
            collectionColumnsVisibility.updateOne(filterTrue, update);

            // Return true
            return true;
        } catch (Exception ex) {
            throw ex;
        }

    }

    @Override
    public BsonDocument GetHeaders(List<ColumnsVisibility> jsonData, String collectionName) {

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        try {
            // Create a list of column names that are visible
            List<String> columnNames = jsonData.stream()
                    .filter(item -> item.isVisible)
                    .map(item -> item.getColumnName())
                    .collect(Collectors.toList());

            // Get the Collection
            MongoCollection<BsonDocument> collection = database.getCollection("Columns_HeaderValue", BsonDocument.class);
            Bson filter = Filters.eq("CollectionName", collectionName);

            // Create a projection that excludes _id and CollectionName
            Bson projection = Projections.fields(
                    Projections.exclude("_id"),
                    Projections.exclude("CollectionName")
            );

            // Query the collection, limit results, project selected columns, and sort
            BsonDocument results = collection.find(filter)
                    .projection(projection)
                    .first();

            // Get the ColumnsHeaderValues array
            BsonArray columnsHeaderValuesArray = results.get("ColumnsHeaderValues").asArray();

            // Use Java streams to filter the array based on Field value
            List<BsonDocument> filteredElements = columnsHeaderValuesArray.stream()
                    .map(element -> element.asDocument())
                    .filter(element -> columnNames.contains(element.getString("Field").getValue()))
                    .collect(Collectors.toList());

            // Create a new BSON document with the filtered elements
            BsonDocument filteredDocument = new BsonDocument("ColumnsHeaderValues", new BsonArray(filteredElements));

            return filteredDocument;
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    public String AddSelectedColumnsGroup(ColoumnsGroupVm coloumnsGroupVm) {
        try {
            if (coloumnsGroupVm == null) {
                return "columnsGroupVM is null";
            }

            if (coloumnsGroupVm.getGroupName() == null ||
                    coloumnsGroupVm.getCollectionName() == null ||
                    coloumnsGroupVm.getColumnsGroups() == null) {
                return "One or more properties in columnsGroupVM are null or empty.";
            }

            // Replace with your MongoDB connection string and database name
            String connectionString = "mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/";
            String databaseName = "camico";
            String collectionName = coloumnsGroupVm.collectionName;

            MongoClient client = MongoClients.create(connectionString);
            MongoDatabase database = client.getDatabase(databaseName);
            MongoCollection<Document> collection = database.getCollection(collectionName);

            // Convert ColumnsGroupVM to a Document
            Document document = new Document();
            document.append("GroupName", coloumnsGroupVm.getGroupName())
                    .append("CollectionName", coloumnsGroupVm.getCollectionName());

            BsonArray columnsArray = new BsonArray();
            for (ColumnsGroup c : coloumnsGroupVm.getColumnsGroups()) {
                Document columnDocument = new Document();
                columnDocument.append("ColumnName", c.getColumnName())
                        .append("IsVisible", c.getIsVisible())
                        .append("ColumnValue", new BsonString(c.getColumnValue()));
                columnsArray.add(columnDocument.toBsonDocument());
            }

            document.append("columnsGroup", columnsArray);

            // Insert the Document into the MongoDB collection
            collection.insertOne(document);

            return "200";
        } catch (Exception ex) {
            // Handle any exceptions that might occur during the insert operation
            return ex.getMessage(); // You might want to handle errors more gracefully in a real application
        }
    }

    @Override
    public List<Document> getEntityIsVisibleList(ColumnsVisibilityVM columnsVisibilityVM, int limit) {
        try {

            MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
            MongoDatabase database = mongoClient.getDatabase("camico");
            // Get the MongoDB collection for opportunities
            MongoCollection<Document> collection = database.getCollection(columnsVisibilityVM.getCollectionName());

            int limitValue = (int) limit;

            List<String> columnNames = columnsVisibilityVM.getColumnsVisibility()
                    .stream()
                    .filter(item -> item.getIsVisible())
                    .map(item -> item.getColumnName())
                    .collect(Collectors.toList());

            // Create a projection that includes the selected columns
            List<String> selectedColumns = new ArrayList<>();
            selectedColumns.add("_id");
            selectedColumns.addAll(columnNames);

            Bson projection = Projections.include(selectedColumns);

            // Query the collection, limit results, project selected columns, and sort
            List<Document> results = collection
                    .find(new BsonDocument()) // Replace with your filter criteria
                    .limit(limitValue)
                    .projection(projection)
                    .into(new ArrayList<>());

            // Create a list of dictionaries to store selected column values for each document
            List<Map<String, Object>> resultObjects = new ArrayList<>();

            // Iterate through the selected column names
            for (Document document : results) {
                // Process or display the selected columns from each document
                Map<String, Object> resultObject = new HashMap<>();

                for (String columnName : columnNames) {
                    // Get the column value from the document, handle null values
                    Object columnValue = document.get(columnName);
                    resultObject.put(columnName, columnValue);
                }

                // Add the map representing this document to the result list
                resultObjects.add(resultObject);
            }

            // Return the list of selected column records
            return results;
        } catch (Exception ex) {
            // Handle the exception as needed
            ex.printStackTrace();
            return new ArrayList<>(); // Return an empty list or handle errors accordingly
        }
    }

    @Override
    public BsonDocument GetColumns(String ObjectName) {
        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");

        MongoCollection<Document> collection = database.getCollection("Columns_Visibility");

        // Define the filter based on the "CollectionName" field
        Document filter = new Document("CollectionName", ObjectName);

        // Define the projection to exclude "_id" and "CollectionName" fields
        Document projection = new Document("_id", 0).append("CollectionName", 0);

        // Find the first matching document, applying the filter and projection
        Document document = collection.find(filter).projection(projection).first();

        return document.toBsonDocument();
    }
}