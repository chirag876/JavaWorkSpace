package com.datapulse.Application.Domain.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnsVisibility {

    public String columnName;
    public Boolean isVisible;
    public String columnValue;
}
