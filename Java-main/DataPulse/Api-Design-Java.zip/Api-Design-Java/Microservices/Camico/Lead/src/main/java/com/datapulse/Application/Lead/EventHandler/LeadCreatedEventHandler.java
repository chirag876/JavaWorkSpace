package com.datapulse.Application.Lead.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Lead;

import com.datapulse.Application.Domain.Events.LeadCreatedEvent;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class LeadCreatedEventHandler implements Notification.Handler<LeadCreatedEvent> {


    Logger _logger = LoggerFactory.getLogger(LeadCreatedEventHandler.class);
    private Lead lead;
    public LeadCreatedEventHandler(){}

    @Override
    public void handle(LeadCreatedEvent notification) {

        lead= new LeadCreatedEvent(notification.getLead()).getLead();
        _logger.info("LeadCreatedEventHandler "+ notification.getLead());

        _logger.info("Lead Event: "+ lead);

    }


    // Kafka implementation for Events
    private void handleKafka(LeadCreatedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }


}
