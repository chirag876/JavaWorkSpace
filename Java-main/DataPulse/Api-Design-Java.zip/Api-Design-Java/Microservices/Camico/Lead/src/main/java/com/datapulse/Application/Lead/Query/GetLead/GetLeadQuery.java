package com.datapulse.Application.Lead.Query.GetLead;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class GetLeadQuery implements Request<LeadVm> {
    private int Limit;
}
