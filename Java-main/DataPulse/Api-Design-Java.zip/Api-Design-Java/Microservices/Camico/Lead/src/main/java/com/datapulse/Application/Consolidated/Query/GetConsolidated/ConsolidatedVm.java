package com.datapulse.Application.Consolidated.Query.GetConsolidated;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsolidatedVm {
    private List<Document> consolidate;
}
