package com.datapulse.Application.Consolidated.CreateVisibleColumns;

import com.datapulse.Application.Domain.Entity.ColumnsVisibility;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ColumnsVisibilityVM {
    public String userId;
    public String screenId;
    public String collectionName;
    public List<ColumnsVisibility> columnsVisibility = new ArrayList<>();
}
