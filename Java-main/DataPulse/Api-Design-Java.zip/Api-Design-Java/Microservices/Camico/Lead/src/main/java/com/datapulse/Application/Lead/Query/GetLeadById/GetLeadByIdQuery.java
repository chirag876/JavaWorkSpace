package com.datapulse.Application.Lead.Query.GetLeadById;

import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetLeadByIdQuery implements Request<LeadDTO> {
    private int Limit ;
}
