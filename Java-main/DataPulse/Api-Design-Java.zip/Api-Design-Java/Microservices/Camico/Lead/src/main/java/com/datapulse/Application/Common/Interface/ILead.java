package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Lead;
import org.bson.Document;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ILead {


    public List<Document> GetList();

    public List<Document> GetById(int id);

}
