//package com.datapulse.Application.Domain.Entity;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class ColumnsHeaderValue {
//    public String CollectionName ;
//    public String HeaderName ;
//    public String Field ;
//    public String Filter ;
//    public FilterParams FilterParams ;
//}
