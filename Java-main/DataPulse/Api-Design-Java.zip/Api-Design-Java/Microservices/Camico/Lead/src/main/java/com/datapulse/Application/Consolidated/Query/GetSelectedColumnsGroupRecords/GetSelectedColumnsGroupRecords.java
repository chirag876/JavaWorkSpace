package com.datapulse.Application.Consolidated.Query.GetSelectedColumnsGroupRecords;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.kafka.common.protocol.types.Field;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetSelectedColumnsGroupRecords implements Request<SelectedColumnsGroupRecordsVm> {

    public String GroupName;
}
