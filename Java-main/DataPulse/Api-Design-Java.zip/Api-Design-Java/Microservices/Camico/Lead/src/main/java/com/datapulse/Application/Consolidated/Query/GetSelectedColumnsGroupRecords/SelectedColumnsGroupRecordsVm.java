package com.datapulse.Application.Consolidated.Query.GetSelectedColumnsGroupRecords;

import lombok.Data;
import org.bson.Document;

import java.util.List;

@Data
public class SelectedColumnsGroupRecordsVm {
    private List<Document> selectedGroupVm;
}
