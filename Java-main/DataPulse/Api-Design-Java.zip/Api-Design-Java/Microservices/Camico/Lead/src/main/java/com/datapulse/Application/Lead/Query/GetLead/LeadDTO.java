package com.datapulse.Application.Lead.Query.GetLead;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class LeadDTO {

}
