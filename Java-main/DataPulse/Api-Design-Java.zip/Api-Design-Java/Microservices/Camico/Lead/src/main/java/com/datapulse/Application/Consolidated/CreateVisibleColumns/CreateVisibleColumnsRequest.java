package com.datapulse.Application.Consolidated.CreateVisibleColumns;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateVisibleColumnsRequest implements Request<Boolean> {
    public ColumnsVisibilityVM columnsVisibilityVM;
}
