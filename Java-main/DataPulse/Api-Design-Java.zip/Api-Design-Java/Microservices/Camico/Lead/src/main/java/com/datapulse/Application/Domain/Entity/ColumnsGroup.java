package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class ColumnsGroup {
    public String columnName;
    public Boolean isVisible;
    public String columnValue;
}
