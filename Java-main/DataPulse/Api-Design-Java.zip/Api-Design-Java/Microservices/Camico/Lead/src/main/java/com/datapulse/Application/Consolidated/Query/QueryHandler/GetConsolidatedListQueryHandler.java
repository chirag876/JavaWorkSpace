package com.datapulse.Application.Consolidated.Query.QueryHandler;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Consolidated.Query.GetConsolidated.ConsolidatedVm;
import com.datapulse.Application.Consolidated.Query.GetConsolidated.GetConsolidatedListQuery;
import com.datapulse.Mediator.RequestHandler;
import org.bson.Document;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class GetConsolidatedListQueryHandler implements RequestHandler<GetConsolidatedListQuery, ConsolidatedVm> {

    ModelMapper mapper = new ModelMapper();

    @Autowired
    private IConsolidatedDataAccess _dataAcces;

    @Override
    public UUID uhandle(GetConsolidatedListQuery request) {
        return null;
    }

    @Override
    public ConsolidatedVm handle(GetConsolidatedListQuery request) {
        ConsolidatedVm vm = new ConsolidatedVm();
        List<Document> documents = _dataAcces.GetConsolidatedList(request.getLimit());
        vm.setConsolidate(documents);
        return vm;
    }
}
