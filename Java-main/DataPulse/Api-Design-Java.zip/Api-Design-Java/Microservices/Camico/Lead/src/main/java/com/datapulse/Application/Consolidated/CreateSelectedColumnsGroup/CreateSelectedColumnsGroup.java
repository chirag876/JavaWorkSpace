package com.datapulse.Application.Consolidated.CreateSelectedColumnsGroup;

import an.awesome.pipelinr.repack.org.checkerframework.checker.units.qual.UnitsBottom;
import com.datapulse.Application.Consolidated.CreateVisibleColumns.ColumnsVisibilityVM;
import com.datapulse.Mediator.Request;
import lombok.Data;

@Data
public class CreateSelectedColumnsGroup implements Request<String> {

    public ColoumnsGroupVm coloumnsGroupVm;
}
