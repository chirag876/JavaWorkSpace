package com.datapulse.Application.Consolidated.Query.GetColumns;

import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.BsonDocument;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetColumns implements Request<BsonDocument> {
    public String objectName;
}
