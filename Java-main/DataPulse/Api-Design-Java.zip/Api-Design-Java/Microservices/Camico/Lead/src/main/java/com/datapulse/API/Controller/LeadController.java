package com.datapulse.API.Controller;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Lead.Query.GetLead.GetLeadQuery;
import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.Application.Lead.Query.GetLead.LeadVm;
import com.datapulse.Application.Lead.Query.GetLeadById.GetLeadByIdQuery;
import com.datapulse.Application.Lead.Request.CreateLeadRequest;
import com.datapulse.Application.Lead.Request.DeleteLeadRequest;
import com.datapulse.Application.Lead.Request.UpdateLeadRequest;
import com.datapulse.Infrastructure.DataAccess.LeadDataAccess;
import com.datapulse.Mediator.Mediator;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("Lead")
@CrossOrigin("*")
public class LeadController {
    private Mediator _mediator;

    @Autowired
    private ILead _dataAccess;

    public LeadController(Mediator _mediator) { this._mediator = _mediator;  }



    @GetMapping()
    public ResponseEntity<?> getLead(int Limit) {

        LeadVm vm =  _mediator.send(new GetLeadQuery(Limit));
        return new ResponseEntity<>(vm.getLead(), HttpStatus.OK);

   }

}
