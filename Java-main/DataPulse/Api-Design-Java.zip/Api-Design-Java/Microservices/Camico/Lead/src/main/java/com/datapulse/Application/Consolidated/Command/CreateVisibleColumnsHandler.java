package com.datapulse.Application.Consolidated.Command;

import com.datapulse.Application.Common.Interface.IConsolidatedDataAccess;
import com.datapulse.Mediator.RequestHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.datapulse.Application.Consolidated.CreateVisibleColumns.CreateVisibleColumnsRequest;

import java.util.UUID;

@Component
public class CreateVisibleColumnsHandler implements RequestHandler<CreateVisibleColumnsRequest, Boolean > {

    @Autowired
    private IConsolidatedDataAccess dataAccess;

    @Override
    public UUID uhandle(CreateVisibleColumnsRequest request) {
        return null;
    }

    @Override
    public Boolean handle(CreateVisibleColumnsRequest request) {

        Boolean result = dataAccess.SaveEntityIsVisibleList(request.getColumnsVisibilityVM());
        return  result;

    }
}
