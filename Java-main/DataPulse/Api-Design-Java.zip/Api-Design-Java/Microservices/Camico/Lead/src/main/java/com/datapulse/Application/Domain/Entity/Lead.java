package com.datapulse.Application.Domain.Entity;

import com.datapulse.Application.Domain.Common.AuditableEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Document("lead")
@Getter
@Setter
public class Lead extends AuditableEntity {

    @Id
    private String id;

    @Field("firstName")
    private String firstName;

    @Field("lastName")
    private String lastName;

    @Field("phone")
    private String phone;

    @Field("company")
    private String company;

    @Field("title")
    private String title;

    @Field("leadSource")
    private String leadSource;

    @Field("email")
    private String email;

    @Field("leadStatus")
    private String leadStatus;

    @Field("website")
    private String website;

    @Field("industry")
    private String industry;

    @Field("annualRevenue")
    private Double annualRevenue;

    @Field("createdDate")
    private String createdDate;
}
