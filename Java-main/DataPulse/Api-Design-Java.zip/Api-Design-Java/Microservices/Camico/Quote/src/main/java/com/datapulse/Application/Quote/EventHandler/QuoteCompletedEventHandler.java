package com.datapulse.Application.Quote.EventHandler;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Quote;
import com.datapulse.Application.Domain.Events.QuoteCompletedEvent;
import com.datapulse.Application.Domain.Events.QuoteCreatedEvent;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class QuoteCompletedEventHandler implements Notification.Handler<QuoteCompletedEvent> {


    Logger _logger = LoggerFactory.getLogger(QuoteCompletedEventHandler.class);
    private Quote quote;
    public QuoteCompletedEventHandler(){}

    @Override
    public void handle(QuoteCompletedEvent notification) {

        quote= new QuoteCreatedEvent(notification.getQuote()).getQuote();
        _logger.info("QuoteCreatedEventHandler "+ notification.getQuote());

        _logger.info("Quote Event: "+ quote);

    }


    // Kafka implementation for Events
    private void handleKafka(QuoteCompletedEvent event){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092"); // Kafka broker address
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        // Create a Kafka producer instance
        Producer<String, Object> producer = new KafkaProducer<>(properties);

        // Create a producer record with a topic, key, and value
        String topic = "my-topic";
        String key = "key-1";

        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, key,event);

        // Send the record to Kafka
//        producer.send(record);

        // Close the producer
        producer.close();
    }


}
