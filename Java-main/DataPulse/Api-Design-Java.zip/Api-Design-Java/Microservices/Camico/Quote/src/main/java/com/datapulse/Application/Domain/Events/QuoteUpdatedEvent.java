package com.datapulse.Application.Domain.Events;

import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Entity.Quote;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
@AllArgsConstructor

public class QuoteUpdatedEvent implements Notification {
    private Quote quote;

    Logger logger = LoggerFactory.getLogger(QuoteCreatedEvent.class);
    public QuoteUpdatedEvent(Quote quote){

        this.quote = quote;

        logger.info(" QuoteUpdatedEvent: " + quote);
    }

    public QuoteUpdatedEvent() {

    }
}
