package com.datapulse.Application.Quote.Query.GetQuote;

import lombok.Data;

import java.util.List;

@Data

public class QuoteVm {
    public List<QuoteDTO> quoteList;

    public QuoteVm(){}

    public QuoteVm(List<QuoteDTO> quoteList) {
        this.quoteList = quoteList;
    }

    public List<QuoteDTO> getQuoteList() {
        return quoteList;
    }

    public void setQuoteList(List<QuoteDTO> leadList) {
        this.quoteList = leadList;
    }


}
