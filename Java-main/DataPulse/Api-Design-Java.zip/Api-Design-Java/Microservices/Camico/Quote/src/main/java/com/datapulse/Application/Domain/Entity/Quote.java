package com.datapulse.Application.Domain.Entity;

import com.datapulse.Application.Domain.Common.AuditableEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("quote")
@Entity
@AllArgsConstructor
@NoArgsConstructor

public class Quote extends AuditableEntity {

        @Id
        @Column(insertable=false, updatable=false)
        private String id;
        private String quoteId;
        @Column(nullable = true)
        private Insured insured;
        private Location location;
        private Premium premium;




}
