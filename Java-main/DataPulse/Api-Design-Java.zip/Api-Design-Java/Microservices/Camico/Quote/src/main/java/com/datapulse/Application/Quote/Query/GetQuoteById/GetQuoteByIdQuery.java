package com.datapulse.Application.Quote.Query.GetQuoteById;

import com.datapulse.Application.Quote.Query.GetQuote.QuoteDTO;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetQuoteByIdQuery implements Request<QuoteDTO> {
    private String id;
}
