package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable

public class Insured {

    @Column(insertable=false, updatable=false)
    private Address address;
    private Business business;
    private Contact contact;
}
