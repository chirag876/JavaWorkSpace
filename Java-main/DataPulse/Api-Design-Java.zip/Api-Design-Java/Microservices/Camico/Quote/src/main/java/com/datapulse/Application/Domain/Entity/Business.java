package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Business {
    private String id;
    private String businessName;
    private String naics;
    private int numberOfEmployeeTotal;
    private String sic;
    private double annualSales;
}
