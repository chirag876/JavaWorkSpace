package com.datapulse.Application.Quote.Query.GetQuote;

import com.datapulse.Application.Domain.Entity.Insured;
import com.datapulse.Application.Domain.Entity.Location;
import com.datapulse.Application.Domain.Entity.Premium;
import jakarta.persistence.Column;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class QuoteDTO {
    private String id;
    private String quoteId;
    private Insured insured;
    private Location location;
    private Premium premium;
}
