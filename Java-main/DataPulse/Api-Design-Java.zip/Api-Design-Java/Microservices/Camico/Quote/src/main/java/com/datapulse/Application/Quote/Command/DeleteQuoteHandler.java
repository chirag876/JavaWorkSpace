package com.datapulse.Application.Quote.Command;

import com.datapulse.Application.Common.Interface.IQuote;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Entity.Quote;
import com.datapulse.Application.Quote.Request.DeleteQuoteRequest;
import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class DeleteQuoteHandler implements RequestHandler<DeleteQuoteRequest, String> {

    Logger logger = LoggerFactory.getLogger(DeleteQuoteHandler.class);


    @Autowired
    private IQuote quoteDataAccess;
    @Override
    public UUID uhandle(DeleteQuoteRequest request) {
        return null;
    }

    @Override
    public String handle(DeleteQuoteRequest request) {
        logger.info("DeleteQuoteHandler: " + request);

        Quote dto =  this.quoteDataAccess.GetById(request.getId());
        if (dto.getId().equals(request.getId())){

        }

        logger.info("DeleteQuoteRequest.Handle - Completed");

        return request.getId();
    }
}
