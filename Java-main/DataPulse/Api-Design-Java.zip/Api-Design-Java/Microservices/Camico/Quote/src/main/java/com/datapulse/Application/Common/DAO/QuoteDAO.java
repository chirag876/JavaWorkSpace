package com.datapulse.Application.Common.DAO;

import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Entity.Quote;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

@Repository
@EnableMongoRepositories
public interface QuoteDAO extends MongoRepository<Quote,String> {
}
