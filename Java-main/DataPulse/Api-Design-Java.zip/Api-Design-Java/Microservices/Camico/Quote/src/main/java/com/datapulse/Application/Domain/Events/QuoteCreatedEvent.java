package com.datapulse.Application.Domain.Events;


import an.awesome.pipelinr.Notification;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Entity.Quote;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@Component
@Setter
@Getter
public class QuoteCreatedEvent implements Notification {
    private Quote quote;

    Logger logger = LoggerFactory.getLogger(QuoteCreatedEvent.class);
    public QuoteCreatedEvent(Quote quote){

        this.quote = quote;

        logger.info(" QuoteCreatedEvent: " + quote);
    }

    public QuoteCreatedEvent() {

    }
}
