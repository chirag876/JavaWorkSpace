package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class Address {
    private String city;
    private String countryCode;
    private String countryName;
    private String line1;
    private String postalCode;
    private String stateOrProvinceCode;
    private String stateOrProvinceName;


    private DetailAddress detailAddress;
}
