package com.datapulse.Application.Quote.Command;


import com.datapulse.Application.Common.Interface.IQuote;
import com.datapulse.Application.Domain.Entity.*;
import com.datapulse.Application.Quote.Request.CreateQuoteRequest;
import com.datapulse.Mediator.RequestHandler;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@Component
public class CreateQuoteHandler implements RequestHandler<CreateQuoteRequest, String> {

    Logger logger = LoggerFactory.getLogger(CreateQuoteHandler.class);


    @Autowired
    private IQuote quoteDataAccess;

    public CreateQuoteHandler(IQuote quoteDataAccess) {
        this.quoteDataAccess = quoteDataAccess;
    }


    @Override
    public UUID uhandle(CreateQuoteRequest request) {
        return null;
    }

    @Override
    public String handle(CreateQuoteRequest request) {
        Quote quote = new Quote();
        try {
            logger.info("CreateQuoteRequest: " + request);
            //setter of Account Entity fields


            Address address = new Address();
            DetailAddress detailAddress = new DetailAddress();
            detailAddress.setPostDirectionCode(request.getInsured().getAddress().getDetailAddress().getPostDirectionCode());
            detailAddress.setPreDirectionCode(request.getInsured().getAddress().getDetailAddress().getPreDirectionCode());
            detailAddress.setStreetName(request.getInsured().getAddress().getDetailAddress().getStreetName());
            detailAddress.setStreetNumber(request.getInsured().getAddress().getDetailAddress().getStreetNumber());
            detailAddress.setStreetTypeCode(request.getInsured().getAddress().getDetailAddress().getStreetTypeCode());
            address.setCity(request.getInsured().getAddress().getCity());
            address.setCountryName(request.getInsured().getAddress().getCountryName());
            address.setCountryCode(request.getInsured().getAddress().getCountryCode());
            address.setPostalCode(request.getInsured().getAddress().getPostalCode());
            address.setLine1(request.getInsured().getAddress().getLine1());
            address.setStateOrProvinceName(request.getInsured().getAddress().getStateOrProvinceName());
            address.setStateOrProvinceCode(request.getInsured().getAddress().getStateOrProvinceCode());
            address.setDetailAddress(detailAddress);
            Business business = request.getInsured().getBusiness();
            Insured insured = new Insured();
            insured.setAddress(address);
            insured.setBusiness(business);
            insured.setContact(request.getInsured().getContact());

            Location location = request.getLocation();
            Period period = request.getPremium().getPeriod();
            Premium premium = new Premium();
            premium.setPeriod(period);
            premium.setAmount(request.getPremium().getAmount());
            premium.setCurrencyCode(request.getPremium().getCurrencyCode());


            quote.setQuoteId(request.getQuoteId());
            quote.setId(request.getId());
            quote.setInsured(insured);
            quote.setPremium(premium);
            quote.setLocation(location);

            quote.setCreatedDateTime(Date.from(Instant.now()));
            quote.setUpdatedDateTime(Date.from(Instant.now()));
            quote.setAuthorizedById("");
            quote.setOwnerId("");

//            entity.domainEvents().add(new AccountCreatedEvent(entity));
            quoteDataAccess.AddQuote(quote);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return quote.getId();
    }



}