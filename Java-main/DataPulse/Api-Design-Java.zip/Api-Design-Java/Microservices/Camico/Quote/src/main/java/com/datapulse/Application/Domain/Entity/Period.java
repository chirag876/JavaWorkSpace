package com.datapulse.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class Period {
    private String startDate;
    private String endDate;
}
