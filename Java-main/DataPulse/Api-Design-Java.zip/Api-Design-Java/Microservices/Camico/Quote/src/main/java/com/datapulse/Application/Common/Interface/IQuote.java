package com.datapulse.Application.Common.Interface;

import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Entity.Quote;

import java.util.List;

public interface IQuote {

    public Quote AddQuote(Quote quote);

    public List<Quote> GetList();

    public Quote GetById(String id);

    public Quote Update(Quote quote);

    public Quote Delete(String id);
}
