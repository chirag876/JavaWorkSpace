package com.datapulse.API.Controller;

import com.datapulse.Application.Common.Interface.IQuote;
import com.datapulse.Application.Domain.Entity.Quote;
import com.datapulse.Application.Quote.Query.GetQuote.GetQuoteQuery;
import com.datapulse.Application.Quote.Query.GetQuote.QuoteDTO;
import com.datapulse.Application.Quote.Query.GetQuote.QuoteVm;
import com.datapulse.Application.Quote.Query.GetQuoteById.GetQuoteByIdQuery;
import com.datapulse.Application.Quote.Request.CreateQuoteRequest;
import com.datapulse.Application.Quote.Request.UpdateQuoteRequest;
import com.datapulse.Mediator.Mediator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("lead")
@CrossOrigin("*")
public class QuoteController {
    private Mediator _mediator;

    @Autowired
    private IQuote _dataAccess;

    public QuoteController(Mediator _mediator) { this._mediator = _mediator;  }

    @PostMapping("/Create")
    public String Create(@RequestBody CreateQuoteRequest request) {
        //return this.contactDataAccess.AddContact(request);

        return	_mediator.send(request);


    }

    @GetMapping()
    public QuoteVm getAllContact(){

        return _mediator.send(new GetQuoteQuery());

    }

    @GetMapping("/{id}")
    public QuoteDTO getContactById(@PathVariable String id){

        return _mediator.send(new GetQuoteByIdQuery(id));

    }

    @PutMapping("/{id}")
    public String  Update(@PathVariable String id,  @RequestBody UpdateQuoteRequest request){

        Quote quote = _dataAccess.GetById(id);

        if (quote.getId().equals(id)){
            return _mediator.send(request);

        }
        return "User Not Found..";
    }
//
//    //Delete
//    @DeleteMapping("/{id}")
//    public String Delete(@PathVariable String id){
//        return _mediator.send(new DeleteLeadRequest(id));
//    }



}
