package com.camico.Application.Csv.Query.GetCsv;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.Document;

import java.util.List;

@Data
@NoArgsConstructor
public class CsvVm {
    private List<Document> predicted_csv ;

}
