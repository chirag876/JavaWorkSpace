package com.camico.Application.Csv.Query.ExportCsv;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportCsvVm {

    private String fileName;
    private String contentType;
    private byte[] content;
    private String errorMessage;
}
