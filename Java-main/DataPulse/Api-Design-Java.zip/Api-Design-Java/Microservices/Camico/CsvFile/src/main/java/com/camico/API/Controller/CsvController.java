package com.camico.API.Controller;

import com.camico.Application.Common.Interface.ICSV;
import com.camico.Application.Csv.Query.ExportCsv.ExportCsvQuery;
import com.camico.Application.Csv.Query.ExportCsv.ExportCsvVm;
import com.camico.Application.Csv.Query.GetCsv.CsvDTO;
import com.camico.Application.Csv.Query.GetCsv.CsvVm;
import com.camico.Application.Csv.Query.GetCsv.GetCsvListQuery;
import com.camico.Application.Csv.Request.CreateCsvRequest;
import com.camico.Mediator.Mediator;
import com.camico.Mediator.Request;
import org.apache.http.protocol.HTTP;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin("*")
@RequestMapping("Csv")
public class CsvController {

    Logger logger = LoggerFactory.getLogger(CsvController.class);
    private Mediator _mediator;

    @Autowired
    private ICSV _dataAccess;
    public CsvController(Mediator _mediator) { this._mediator = _mediator;  }

    @PostMapping("/Upload")
    public String Create(@RequestPart("file") MultipartFile request) {
        //return this.contactDataAccess.AddContact(request);
        return	_mediator.send(new CreateCsvRequest(request));
    }

    @GetMapping("Download/Csv/MongoDb")
    public ResponseEntity<?>getAllCsv(){
//
        CsvVm vm = _mediator.send(new GetCsvListQuery());

        return new ResponseEntity<>(vm,HttpStatus.OK);


    }

    @GetMapping("/Download")
    public ResponseEntity<?> GetDownload(String FileName){
        ExportCsvVm vm = _mediator.send(new ExportCsvQuery(FileName));

        // if file have Some content
        if (vm.getErrorMessage() == null && vm.getContent() != null && vm.getContent().length > 0) {

            logger.info("file Downloaded");

            return ResponseEntity
                    .ok()
                    .contentLength(vm.getContent().length)
                    .header("Content-type", "application/octet-stream")
                    .header("Content-disposition", "attachment; filename=\"" + vm.getFileName() + "\"")
                    .body(vm.getContent());

        } else if (vm.getContent() == null || vm.getContent().length == 0) {
            return new ResponseEntity<>("File Not Found", HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }




}
