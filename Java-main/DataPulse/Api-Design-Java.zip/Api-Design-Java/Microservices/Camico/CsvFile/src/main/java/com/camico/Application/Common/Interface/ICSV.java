package com.camico.Application.Common.Interface;

import com.camico.Application.Csv.Query.GetCsv.CsvDTO;
import org.bson.Document;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Repository
public interface ICSV {

    public List<Document> GetCsvList();

    public String Upload(MultipartFile file);

    public byte[] Download(String fileName);
}
