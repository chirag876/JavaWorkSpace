package com.camico.Application.Domain.Entity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Entity
@Data
@Document("csv")
@AllArgsConstructor
@NoArgsConstructor
public class CSV {
    @Id
    private String filename;
}
