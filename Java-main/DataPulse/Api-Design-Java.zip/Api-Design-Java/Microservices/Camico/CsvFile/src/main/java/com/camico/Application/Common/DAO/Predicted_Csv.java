package com.camico.Application.Common.DAO;

import com.camico.Application.Csv.Query.GetCsv.CsvDTO;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Predicted_Csv extends MongoRepository<CsvDTO, String> {
}
