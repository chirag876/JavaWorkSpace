package com.camico.Application.Csv.Request;

import com.camico.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCsvRequest  implements Request<String> {

    private MultipartFile file;
}
