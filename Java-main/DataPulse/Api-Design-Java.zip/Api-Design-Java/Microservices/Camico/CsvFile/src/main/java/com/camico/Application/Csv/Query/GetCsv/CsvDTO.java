package com.camico.Application.Csv.Query.GetCsv;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
public class CsvDTO {

    public String InputCSV;
    public String OutputCSV;
}
