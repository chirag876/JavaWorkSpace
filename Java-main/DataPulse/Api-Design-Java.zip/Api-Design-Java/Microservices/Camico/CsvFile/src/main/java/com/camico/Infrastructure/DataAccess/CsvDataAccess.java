package com.camico.Infrastructure.DataAccess;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.camico.Application.Common.DAO.CSVFileDAO;
import com.camico.Application.Common.DAO.Predicted_Csv;
import com.camico.Application.Common.Interface.ICSV;
import com.camico.Application.Csv.Query.GetCsv.CsvDTO;
import com.camico.Application.Domain.Entity.CSV;
import com.mongodb.client.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class CsvDataAccess implements ICSV {

    Logger logger = LoggerFactory.getLogger(CsvDataAccess.class);

    @Autowired
    private CSVFileDAO csvFileDAO;
    @Autowired
    private Predicted_Csv predictedCsv;


    @Override
    public List<Document> GetCsvList() {
        List<Document> documents = new ArrayList<>();



        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("datapulse0");
        MongoCollection<Document> collection = database.getCollection("predicted_csv");

        Document projection = new Document("_id", 0);

        // Query for all documents in the collection
        MongoCursor<Document> cursor = collection.find().iterator();

        documents =collection.find()
                .projection(projection)
                .into(new ArrayList<>());


        try{

            logger.info("getting data from db");
            return documents;
        }
        catch (Exception e){

        }
        return  documents;


    }

        // getting bucket name
    @Value("${application.bucket.name}")
    private String bucketName;
    @Value("${application.bucket.key}")
    private String keyName;


    // connection with S3 client
    @Autowired
    private AmazonS3 s3Client;
    @Override
    public String Upload(MultipartFile file) {



        if (file.isEmpty()) {
            return "Please select a file to upload.";
        }

        try (InputStream inputStream = file.getInputStream();
             InputStreamReader reader = new InputStreamReader(inputStream);
             CSVParser csvParser = CSVFormat.DEFAULT.parse(reader)) {

            // Adding File in AWS S3 Bucket
            File fileObj = convertMultiPartFileToFile(file);
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();


//            // Adding into S3 bucket
            s3Client.putObject(new PutObjectRequest(bucketName,keyName +fileName, fileObj));
            fileObj.delete();
            logger.info("CSV file sent int S3 bucket {}",fileName );

            String filename = file.getOriginalFilename();

            AddFileNameToMongoDB(filename);
            storeFileInLocal(file);

            return "File uploaded and processed successfully";

        } catch (IOException e) {
            return "Error processing the uploaded file.";
        }

    }

    // download file from S3 bucket
    @Override
    public byte[] Download(String fileName) {
        S3Object s3Object = s3Client.getObject(bucketName, keyName +fileName);
        S3ObjectInputStream inputStream = s3Object.getObjectContent();
        try {
            byte[] content = IOUtils.toByteArray(inputStream);

            ByteArrayResource resource = new ByteArrayResource(content);
            return content;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public  String AddFileNameToMongoDB(String fileName){
        CSV csv = new CSV();

        csv.setFilename(fileName);

        csvFileDAO.save(csv);

        logger.info("File Added into MongoDB, filename {} ", fileName);

        return "File Added in MongoDb";

    }




    private File convertMultiPartFileToFile(MultipartFile file) {
        File convertedFile = new File(file.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
            fos.write(file.getBytes());
        } catch (IOException e) {
            logger.error("Error converting multipartFile to file", e);
        }
        return convertedFile;
    }

    private  String storeFileInLocal(MultipartFile file){
        try {
            File newFile = new File("C:/Users/Roshan/Downloads/" + file.getOriginalFilename());
            FileOutputStream os = new FileOutputStream(newFile);
            os.write(file.getBytes());
            os.close();
            logger.info("file Added in Local");
            return "File uploaded successfully!";
        } catch (IOException e) {
            return "File upload failed: " + e.getMessage();
        }
    }

}
