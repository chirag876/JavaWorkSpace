package com.camico.Application.Csv.Query.ExportCsv;

import com.camico.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportCsvQuery implements Request<ExportCsvVm> {
    private String FileName;
}
