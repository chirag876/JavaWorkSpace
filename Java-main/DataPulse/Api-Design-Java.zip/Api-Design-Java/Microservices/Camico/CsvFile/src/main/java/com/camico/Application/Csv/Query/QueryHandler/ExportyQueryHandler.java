package com.camico.Application.Csv.Query.QueryHandler;

import com.camico.Application.Common.Interface.ICSV;
import com.camico.Application.Csv.Query.ExportCsv.ExportCsvQuery;
import com.camico.Application.Csv.Query.ExportCsv.ExportCsvVm;
import com.camico.Mediator.Request;
import com.camico.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class ExportyQueryHandler implements RequestHandler<ExportCsvQuery, ExportCsvVm> {


    Logger _logger = LoggerFactory.getLogger(ExportyQueryHandler.class);

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private ICSV _dataAccess;

    @Override
    public UUID uhandle(ExportCsvQuery request) {
        return null;
    }

    @Override
    public ExportCsvVm handle(ExportCsvQuery request) {

        ExportCsvVm vm = new ExportCsvVm();
       vm.setContent( _dataAccess.Download(request.getFileName()));
       vm.setContentType("text/csv");
       vm.setFileName(request.getFileName());
       return vm;
    }
}
