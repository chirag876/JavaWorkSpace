package com.camico.Application.Csv.Query.QueryHandler;

import com.camico.Application.Common.Interface.ICSV;
import com.camico.Application.Csv.Query.GetCsv.CsvDTO;
import com.camico.Application.Csv.Query.GetCsv.CsvVm;
import com.camico.Application.Csv.Query.GetCsv.GetCsvListQuery;
import com.camico.Mediator.RequestHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class GetCsvListQueryHandler implements RequestHandler<GetCsvListQuery,CsvVm> {

    Logger _logger = LoggerFactory.getLogger(GetCsvListQueryHandler.class);

    ModelMapper mapper = new ModelMapper();
    @Autowired
    private ICSV _dataAcces;

    @Override
    public UUID uhandle(GetCsvListQuery request) {
        return null;
    }

    @Override
    public CsvVm handle(GetCsvListQuery request) {
        CsvVm vm = new CsvVm();

        List<Document> documents = _dataAcces.GetCsvList();
        if (!documents.isEmpty() && documents.get(0).containsKey("predicted_csv")) {
            // Get the inner list
            List<Document> innerList = documents.get(0).getList("predicted_csv", Document.class);

            vm.setPredicted_csv(innerList);

        }
        return vm;

    }
}
