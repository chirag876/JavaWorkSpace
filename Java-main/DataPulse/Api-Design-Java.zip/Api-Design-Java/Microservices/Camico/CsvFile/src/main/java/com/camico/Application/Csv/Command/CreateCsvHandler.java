package com.camico.Application.Csv.Command;

import com.camico.Application.Common.Interface.ICSV;
import com.camico.Application.Csv.Request.CreateCsvRequest;
import com.camico.Mediator.RequestHandler;
import org.apache.kafka.common.protocol.types.Field;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CreateCsvHandler implements RequestHandler<CreateCsvRequest, String> {


    @Autowired
    private ICSV _dataAccess;
    @Override
    public UUID uhandle(CreateCsvRequest request) {
        return null;
    }

    @Override
    public String handle(CreateCsvRequest request) {
         return  _dataAccess.Upload(request.getFile());

    }
}
