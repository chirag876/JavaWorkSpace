package com.camico.Application.Csv.Query.GetCsv;

import com.camico.Mediator.Request;
import lombok.Data;
import org.bson.Document;

import java.util.List;

public class GetCsvListQuery implements Request<CsvVm> {


}
