package com.camico.Application.Common.Interface;


import com.camico.Application.Domain.Common.DomainEvent;

public interface IDomainEventService {
	
	/**
	 * This method publishes the given list of domain events.
	 * 
	 * @param domainEvent a list of DomainEvent objects to be published
	 */
	void Publish(DomainEvent domainEvent);

}
