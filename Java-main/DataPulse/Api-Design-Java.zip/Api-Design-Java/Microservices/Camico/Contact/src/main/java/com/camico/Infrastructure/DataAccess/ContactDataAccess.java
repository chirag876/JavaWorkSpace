package com.camico.Infrastructure.DataAccess;

import com.camico.Application.Common.Interface.IContact;

import com.camico.Application.Common.Interface.IDomainEventService;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service

public class ContactDataAccess implements IContact {

    Logger _logger  =  LoggerFactory.getLogger(ContactDataAccess.class);


    @Autowired
    private IDomainEventService domainEventService;




    @Override
    public List<Document> GetById(int id) {

        int limit = id;
        List<Document> documents = new ArrayList<>();

        MongoClient mongoClient = MongoClients.create("mongodb+srv://Project0:Diagnostics11@cluster0.w9m3hlk.mongodb.net/");
        MongoDatabase database = mongoClient.getDatabase("camico");
        MongoCollection<Document> collection = database.getCollection("contact");

        // Query for all documents in the collection
        documents = collection.find().limit(10).into(new ArrayList<>());


        try {
            _logger.info("OpportunityDataAccess.GetById - In process");

            return documents;

        }

        catch(Exception ex) {
            _logger.error("OpportunityDataAccess.GetById"+ex.getMessage());

        }

        return documents;
    }








}
