package com.camico.Application.Contact.Command;//package com.datapulse.Application.Opportunity.Command;
//
//import com.datapulse.Application.Common.Interface.IOpportunity;
//import com.datapulse.Application.Domain.Entity.Opportunity;
//import com.datapulse.Application.Opportunity.Request.UpdateOpportunityRequest;
//import com.datapulse.Mediator.RequestHandler;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.UUID;
//@Component
//public class UpdateOpportunityHandler implements RequestHandler<UpdateOpportunityRequest, String> {
//    Logger logger = LoggerFactory.getLogger(UpdateOpportunityHandler.class);
//
//
//    @Autowired
//    private IOpportunity opportunityDataAccess;
//    @Override
//    public UUID uhandle(UpdateOpportunityRequest request) {
//        return null;
//    }
//
//    @Override
//    public String handle(UpdateOpportunityRequest request) {
//        Opportunity entity = new Opportunity();
//        try {
//            logger.info("AccountCreatedEvent: " + request);
//            //setter of Account Entity fields
//            entity.setId(request.getId());
//            entity.setAccountName(request.getAccountName());
//            entity.setOpportunityName(request.getOpportunityName());
//            entity.setAmount(request.getAmount());
//            entity.setStage(request.getStage());
//            entity.setCloseDate(request.getCloseDate());
//            entity.setLeadSource(request.getLeadSource());
//            entity.setType(request.getType());
//
//
//
////            entity.domainEvents().add(new AccountCreatedEvent(entity));
//            opportunityDataAccess.AddOpportunity(entity);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//
//        return entity.getAccountName();
//
//
//    }
//}
