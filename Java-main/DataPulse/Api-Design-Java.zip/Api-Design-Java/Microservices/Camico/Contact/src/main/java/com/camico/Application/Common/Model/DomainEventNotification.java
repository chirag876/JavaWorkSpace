package com.camico.Application.Common.Model;


import com.camico.Application.Domain.Common.DomainEvent;
import com.camico.Mediator.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//
//public class DomainEventNotification <TDomainEvent extends DomainEvent> implements Notification{
//
//
//
//	// Create a Logger instance to log messages
//		Logger _logger = LoggerFactory.getLogger(DomainEventNotification.class);
//		private TDomainEvent domainEvent;
//
//		public DomainEventNotification(){}
//
//		// Constructor that takes a list of domain events as argument
////		public DomainEventNotification(List<TDomainEvent> domainEvent) {
////			// Log that the DomainEventNotification is being processed
////			_logger.info("DomainEventNotification in process"+ domainEvent);
////			this.domainEvent = domainEvent;
////		}
//
//	public DomainEventNotification(DomainEvent domainEvent) {
//		_logger.info("DomainEventNotification in process"+ domainEvent);
//		this.domainEvent = (TDomainEvent) domainEvent;
//	}
//
//	// Get the domain event
////		public TDomainEvent getDomainEvent() {
////			// Cast the list of domain events to a single domain event and return it
////			return (TDomainEvent) domainEvent;
////		}
//
//}


public class DomainEventNotification<TDomainEvent extends DomainEvent> implements Notification {

	private final TDomainEvent domainEvent;
	Logger _logger = LoggerFactory.getLogger(DomainEventNotification.class);

	public DomainEventNotification(TDomainEvent domainEvent) {
		_logger.info("DomainEventNotification in process "+ domainEvent);
		this.domainEvent = domainEvent;
	}

	public TDomainEvent getDomainEvent() {
		return domainEvent;
	}
}

