package com.camico.API.Controller;


import com.camico.Application.Common.Interface.IContact;
import com.camico.Mediator.Mediator;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("Contact")
@CrossOrigin("*")
public class ContactController {
    private Mediator _mediator;

    @Autowired
    private IContact _dataAccess;

    public ContactController(Mediator _mediator) { this._mediator = _mediator;  }

//    @PostMapping("/Create")
//    public String Create(@RequestBody CreateOpportunityRequest request) {
//        //return this.contactDataAccess.AddContact(request);
//
//        return	_mediator.send(request);
//
//
//    }

//    @GetMapping()
//    public OpportunityVm getAllContact(){
//
//        return _mediator.send(new GetOpportunityQuery());
//
//    }

    @GetMapping()
    public List<Document> getContact(int Limit){

//        return _mediator.send(new GetopportunityByIdQuery(id));

        return _dataAccess.GetById(Limit);

    }
//
//    @PutMapping("/{id}")
//    public String  Update(@PathVariable String id,  @RequestBody UpdateOpportunityRequest request){
//
//        Opportunity opportunity = _dataAccess.GetById(id);
//
//        if (opportunity.getId().equals(id)){
//            return _mediator.send(request);
//
//        }
//        return "User Not Found..";
//    }
//
//    //Delete
//    @DeleteMapping("/{id}")
//    public String Delete(@PathVariable String id){
//        return _mediator.send(new DeleteOpportunityRequest(id));
//    }



}
