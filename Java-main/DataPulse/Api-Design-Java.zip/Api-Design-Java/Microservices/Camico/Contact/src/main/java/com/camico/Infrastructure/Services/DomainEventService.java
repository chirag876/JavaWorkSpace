package com.camico.Infrastructure.Services;


import com.camico.Application.Common.Interface.IDomainEventService;
import com.camico.Application.Common.Model.DomainEventNotification;
import com.camico.Application.Domain.Common.DomainEvent;
import com.camico.Mediator.IPublish;
import com.camico.Mediator.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DomainEventService implements IDomainEventService {
	
	// Mediator instance to publish notifications
	    @Autowired
		private IPublish _meditor;

		// Logger instance for logging
		Logger _logger = LoggerFactory.getLogger(DomainEventService.class);

		// Constructor with IPublish dependency injection
		public DomainEventService(IPublish _meditor) {
			this._meditor = _meditor;
		}

		// Default constructor
		public DomainEventService() {
		}

		// Method to publish a list of domain events
		@Override
		public void Publish(DomainEvent domainEvent) {
			_logger.info("Publishing domain event. Event -" + domainEvent.getIsPublished());

//			 Get the notification corresponding to the domain event
				Notification notification = GetNotificationCorrespondingToDomainEvent(domainEvent);

				// Publish the notification using mediator
				_meditor.publish(notification);
			GetNotificationCorrespondingToDomainEvent(domainEvent);
			 _meditor.publish(GetNotificationCorrespondingToDomainEvent(domainEvent));
		}

		// Method to get notification corresponding to a domain event
		private Notification GetNotificationCorrespondingToDomainEvent(DomainEvent domainEvent) {
			// Create a DomainEventNotification with the domain event list
			DomainEventNotification<DomainEvent> notification = new DomainEventNotification<>(domainEvent);
			return notification;
		}

}
