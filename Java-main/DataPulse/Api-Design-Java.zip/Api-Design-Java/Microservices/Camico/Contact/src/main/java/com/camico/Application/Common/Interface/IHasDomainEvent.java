package com.camico.Application.Common.Interface;



import com.camico.Application.Domain.Common.DomainEvent;

import java.util.List;

public interface IHasDomainEvent {
		public  List<DomainEvent> getDomainEvents();
	 public void setDomainEvents(List<DomainEvent> domainEvents);



}
