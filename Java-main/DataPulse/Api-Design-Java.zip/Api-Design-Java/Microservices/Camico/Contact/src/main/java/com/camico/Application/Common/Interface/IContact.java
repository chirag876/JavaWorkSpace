package com.camico.Application.Common.Interface;

import org.bson.Document;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface IContact {


    public List<Document> GetById(int id);


}
