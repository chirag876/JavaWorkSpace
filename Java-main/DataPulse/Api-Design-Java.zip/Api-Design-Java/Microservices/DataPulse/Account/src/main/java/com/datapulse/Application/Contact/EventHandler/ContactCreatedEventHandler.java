package com.datapulse.Application.Contact.EventHandler;



import com.datapulse.Application.Common.Model.DomainEventNotification;
import com.datapulse.Application.Domain.Events.Contact.ContactCreatedEvent;
import com.datapulse.Mediator.NotificationHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Component
public class ContactCreatedEventHandler implements NotificationHandler<DomainEventNotification<ContactCreatedEvent>> {
	Logger _logger = LoggerFactory.getLogger(ContactCreatedEventHandler.class);	
	
	public ContactCreatedEventHandler(){}
	
	public ContactCreatedEventHandler(Logger _logger) {
		this._logger = _logger;
	}
	
	//Handler will receive Response  
	

//	@Override
//	public void handle(List<DomainEventNotification<ContactCreatedEvent>> notification) {
//
//		_logger.info("Domain Event: "+  notification);
//
//	}

	@Override
	public CompletableFuture<Void> handle(DomainEventNotification<ContactCreatedEvent> notification) {
		_logger.info("Domain Event: AccountCreatedEventHandler "+  notification);
		return CompletableFuture.completedFuture(null);
	}
}
