package com.datapulse.Application.Account.Command;

import com.datapulse.Application.Account.Request.CreateAccountRequest;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Application.Domain.Entity.Account.Contacts;
import com.datapulse.Mediator.RequestHandler;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@Component
public class CreateAccountHandler  implements RequestHandler<CreateAccountRequest, String> {

    Logger logger = LoggerFactory.getLogger(CreateAccountHandler.class);


    @Autowired
    private IAccount accountDataAccess;

    public CreateAccountHandler(IAccount accountDataAccess) {
        this.accountDataAccess = accountDataAccess;
    }

    @Override
    public UUID uhandle(CreateAccountRequest request) {
        return null;
    }

    @Override
    public String handle(CreateAccountRequest request) {
        Account entity = new Account();
        try {
            logger.info("AccountCreatedEvent: " + request);
            //setter of Account Entity fields

            entity.setId(request.getId());
            entity.setName(request.getName());
            entity.setAddressLine1(request.getAddressLine1());
            entity.setAddressLine2(request.getAddressLine2());
            entity.setCity(request.getCity());
            entity.setState(request.getState());
            entity.setZipCode(request.getZipCode());
            entity.setPhoneNumber(request.getPhoneNumber());
            entity.setPhoneExtension(request.getPhoneExtension());
            entity.setIndustryId(request.getIndustryId());

            //setter for Contact Entity fields
            List<Contacts> contacts = request.getContacts();
            entity.setContactsList(contacts);

//            entity.domainEvents().add(new AccountCreatedEvent(entity));
            accountDataAccess.AddAccount(entity);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return entity.getId();
    }
}