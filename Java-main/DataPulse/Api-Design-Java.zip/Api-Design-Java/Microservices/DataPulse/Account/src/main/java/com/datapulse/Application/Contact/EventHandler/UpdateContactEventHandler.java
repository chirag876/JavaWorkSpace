package com.datapulse.Application.Contact.EventHandler;//package com.datapulse.Application.Contact.EventHandler;
//
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.List;
//
//public class UpdateContactEventHandler  implements NotificationHandler<DomainEventNotification<UpdateContactEvent>> {
//
//	Logger _logger = LoggerFactory.getLogger(ContactCreatedEventHandler.class);
//
//
//
//	public UpdateContactEventHandler(Logger _logger) {
//		this._logger = _logger;
//	}
//
//	//Handler will receive Response
//
//
//	@Override
//	public void handle(List<DomainEventNotification<UpdateContactEvent>> notification) {
//
//		_logger.info("Domain Event: "+  notification);
//
//	}
//
//}
