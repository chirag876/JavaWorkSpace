package com.datapulse.Command;


import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Application.Domain.Entity.Account.Contacts;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.util.AssertionErrors.assertEquals;

public class CreateAccountRequestTest extends AccountApplicationTests {

    @Autowired
    public IAccount dataAccess;

    @Test
    public void testAddAccount(){

        List<Contacts> contact= new ArrayList<>();

        Contacts contact1 = new Contacts();
        contact1.setFirstName("John");
        contact1.setLastName("Doe");
        contact1.setAccountName("Test Account");
        contact1.setPhone("555-123-4567");
        contact1.setEmail("john.doe@example.com");
        contact1.setMailingCity("Sample City");
        contact1.setMailingState("CA");
        contact1.setMailingCountry("USA");
        contact1.setMailingZipCode("54321");
        contact.add(contact1);

        Account account = new Account("testId" ,"John mee","123 Main St","Apt 45", "Sample City",
                "CA", "12345", "555-555-5555", "123", 1L, contact);


        assertEquals("pass", "testId", account.getId());

    }

}
