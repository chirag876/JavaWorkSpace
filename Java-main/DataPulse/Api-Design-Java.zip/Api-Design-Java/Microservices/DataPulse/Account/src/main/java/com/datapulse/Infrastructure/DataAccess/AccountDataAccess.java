package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;
import com.datapulse.Application.Account.EventHandler.AccountCreatedEventHandler;
import com.datapulse.Application.Account.EventHandler.AccountUpdatedEventHandler;
import com.datapulse.Application.Common.DAO.AccountDAO;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Application.Domain.Events.Account.AccountCreatedEvent;
import com.datapulse.Application.Domain.Events.Account.AccountUpdatedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Stream;

@Service
public class AccountDataAccess implements IAccount {

    Logger _logger  =  LoggerFactory.getLogger(AccountDataAccess.class);

    @Autowired
    private AccountDAO accountDAO;
    @Autowired
    private IDomainEventService domainEventService;
    @Override
    public Account AddAccount(Account account) {

        try {
            _logger.info("AccountDataAccess.AddContact - In process");

            accountDAO.save(account);

        }
        catch(Exception ex) {
            _logger.error("AccountDataAccess.AddContact"+ex.getMessage());

        }
        DispatchEvents(account);
        return account;

}

    @Override
    public List<Account> GetList() {
        return accountDAO.findAll();
    }

    @Override
    public Account GetById(String id) {

        try {
            _logger.info("AccountDataAccess.GetById - In process");
            return accountDAO.findById(id).get();
        }

        catch(Exception ex) {
            _logger.error("AccountDataAccess.GetById"+ex.getMessage());

        }

        return accountDAO.findById(id).get();
    }

    @Override
    public Account Update(Account account) {

        try {
            _logger.info("AccountDataAccess.Update - In process");


            accountDAO.save(account);

        }
        catch(Exception ex) {
            _logger.error("ContactDataAccess.Update"+ex.getMessage());

        }
        UpdateDispatchEvents(account);

        return account;
    }

    @Override
    public Account Delete(String id) {
        return null;
    }


    // DispatchEvents

    public void DispatchEvents(Account entity) {

        // Assuming you have a list of DomainEvent objects
        List<DomainEvent> domainEvents = entity.domainEvents();

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }
            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }
            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }
            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

        domainEvents.add(domainEvent);
        domainEventService.Publish(domainEvent);
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new AccountCreatedEventHandler())
        );

        AccountCreatedEvent accountCreatedEvent = new AccountCreatedEvent();
        accountCreatedEvent.setAccount(entity);
        accountCreatedEvent.send(pipeline);

    }
    public void UpdateDispatchEvents(Account entity) {

        // Assuming you have a list of DomainEvent objects
        List<DomainEvent> domainEvents = entity.domainEvents();

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }
            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }
            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }
            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

        domainEvents.add(domainEvent);
        domainEventService.Publish(domainEvent);
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new AccountUpdatedEventHandler())
        );

        AccountUpdatedEvent accountUpdatedEvent = new AccountUpdatedEvent();
        accountUpdatedEvent.setAccount(entity);
        accountUpdatedEvent.send(pipeline);

    }

}
