package com.datapulse.Endpoint;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Account.Request.UpdateAccountRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.test.util.AssertionErrors.assertEquals;

public class Ep_UpdateAccountRequestTest extends AccountApplicationTests {

    @Test
    public void testUpdateAccount(){
        UpdateAccountRequest request = new UpdateAccountRequest("119042", "Harry Y. Parker", "Street5454","North", "NY", "US", "80726", "4545454545", "+912");
        restTemplate.put(baseUrl+"/{id}",request,request.getId());
        assertAll(() -> assertEquals("pass", request,request));
    }

    @Test
    public void testUpdateAccount2(){
        UpdateAccountRequest request = new UpdateAccountRequest("testId", "John mee Markram", "Street5454","North", "NY", "US", "80726", "4545454545", "+912");
        restTemplate.put(baseUrl+"/{id}",request,request.getId());
        assertAll(() -> assertEquals("pass", request,request));
    }
}
