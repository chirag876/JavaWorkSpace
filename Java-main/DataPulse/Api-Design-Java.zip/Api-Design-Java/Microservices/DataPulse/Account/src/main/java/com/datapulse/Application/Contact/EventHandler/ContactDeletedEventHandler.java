package com.datapulse.Application.Contact.EventHandler;


import com.datapulse.Application.Common.Model.DomainEventNotification;
import com.datapulse.Application.Domain.Events.Contact.ContactDeleteEvent;
import com.datapulse.Mediator.NotificationHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

public class ContactDeletedEventHandler implements NotificationHandler<DomainEventNotification<ContactDeleteEvent>> {

		Logger _logger = LoggerFactory.getLogger(ContactDeletedEventHandler.class);	
	
	
	
	public ContactDeletedEventHandler(Logger _logger) {
		this._logger = _logger;
	}
	
	//Handler will receive Response  
	

//	@Override
//	public void handle(List<DomainEventNotification<ContactDeleteEvent>> notification) {
//
//		_logger.info("Domain Event: "+  notification);
//
//	}

	@Override
	public CompletableFuture<Void> handle(DomainEventNotification<ContactDeleteEvent> notification) {
		return null;
	}
}
