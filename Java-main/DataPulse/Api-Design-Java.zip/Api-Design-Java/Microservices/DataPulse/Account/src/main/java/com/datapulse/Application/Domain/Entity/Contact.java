package com.datapulse.Application.Domain.Entity;


import com.datapulse.Application.Domain.Common.DomainEvent;
import jakarta.persistence.Entity;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Contact {
	
	@jakarta.persistence.Id
	private int Id;

	private String Name;
	
	private String Phone;	
	
	
	
	public int getId() {
		return Id;
	}
	
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	
	
	
	//@ElementCollection(targetClass=Integer.class)
	//private 
	
	
	public List<DomainEvent> domainEvents() {
		List<DomainEvent> domainEvent = new ArrayList<DomainEvent>();
		return domainEvent;
	}
	


	
	
}