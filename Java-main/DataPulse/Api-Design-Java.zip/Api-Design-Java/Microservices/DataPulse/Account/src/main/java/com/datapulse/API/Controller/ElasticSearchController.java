package com.datapulse.API.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController

public class ElasticSearchController {
}
