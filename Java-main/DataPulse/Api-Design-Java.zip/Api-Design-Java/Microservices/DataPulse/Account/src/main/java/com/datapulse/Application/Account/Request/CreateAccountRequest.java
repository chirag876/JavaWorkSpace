package com.datapulse.Application.Account.Request;

import com.datapulse.Application.Domain.Entity.Account.Contacts;
import com.datapulse.Mediator.Request;
import jakarta.persistence.ElementCollection;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateAccountRequest implements Request<String> {
    private String id;
    private String name;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String zipCode;
    private String phoneNumber;
    private String phoneExtension;
    private Long industryId;
    @ElementCollection
    List<Contacts> contacts = new ArrayList<Contacts>();
}
