package com.datapulse.Application.Contact.Command.CreateContactCommandHand;


import com.datapulse.Application.Common.Interface.IContact;
import com.datapulse.Application.Contact.Request.CreateContactRequest;
import com.datapulse.Application.Domain.Entity.Contact;
import com.datapulse.Application.Domain.Events.Contact.ContactCreatedEvent;
import com.datapulse.Infrastructure.DataAccess.ContactDataAccess;
import com.datapulse.Mediator.RequestHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CreateContactHandler implements RequestHandler<CreateContactRequest, Integer> {
	
	@Autowired 
	private IContact contactDataAccess;

	
	public CreateContactHandler(ContactDataAccess contactDataAccess) {
		
		this.contactDataAccess = contactDataAccess;
		
	}
	
	//Assign Requested Contact value
	public Integer handle(CreateContactRequest request) {	
	
		
		Contact entity = new Contact();
		entity.setId(request.getId());
		entity.setName(request.getName());
		entity.setPhone(request.getPhone());
//		contact.setId(request.getId());
//		contact.setName(request.getName());
//		contact.setPhone(request.getPhone());
		
		// Adding DomainEvent to Contact Object
		
		entity.domainEvents().add(new ContactCreatedEvent(entity));
		// Add Requested to Contact 
		contactDataAccess.AddContact(entity);
		
//		entity.domainEvents().add(new ContactCompletedEvent(entity));

		return request.getId();
	}

	@Override
	public UUID uhandle(CreateContactRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

} 

