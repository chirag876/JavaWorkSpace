package com.datapulse.Application.Domain.Entity.Account;

import com.datapulse.Application.Domain.Common.AuditableEntity;
import com.datapulse.Application.Domain.Common.DomainEvent;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.ArrayList;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Document("account")
@Getter
@Setter
public class Account extends AuditableEntity {

    @Id
    private String id; // This field will be automatically mapped to MongoDB's ObjectId

    @Field("name")
    private String name;

    @Field("addressLine1")
    private String addressLine1;

    @Field("addressLine2")
    private String addressLine2;

    @Field("city")
    private String city;

    @Field("state")
    private String state;

    @Field("zipCode")
    private String zipCode;

    @Field("phoneNumber")
    private String phoneNumber;

    @Field("phoneExtension")
    private String phoneExtension;

    @Field("industryId")
    private Long industryId;
    @ElementCollection
    List<Contacts> contactsList = new ArrayList<>();

//    @ElementCollection
//    List<DomainEvent> domainEvents = new ArrayList<>();
//    @Override
//    public List<DomainEvent> getDomainEvents() {
//        return domainEvents();
//    }
//
//    @Override
//    public void setDomainEvents(List<DomainEvent> domainEvents) {
//        domainEvents = domainEvents;
//
//    }

    public List<DomainEvent> domainEvents() {

        List<DomainEvent> domainEvent = new ArrayList<>();

        return domainEvent;
    }




}
