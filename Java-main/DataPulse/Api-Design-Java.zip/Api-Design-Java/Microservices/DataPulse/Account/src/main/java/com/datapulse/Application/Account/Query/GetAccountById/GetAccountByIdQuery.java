package com.datapulse.Application.Account.Query.GetAccountById;

import com.datapulse.Application.Account.Query.GetAccount.AccountDTO;
import com.datapulse.Mediator.Request;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetAccountByIdQuery implements Request<AccountDTO> {
    private String id;

}
