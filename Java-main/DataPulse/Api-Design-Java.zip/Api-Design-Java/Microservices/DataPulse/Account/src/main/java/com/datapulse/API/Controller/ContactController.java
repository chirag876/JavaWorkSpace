package com.datapulse.API.Controller;

import com.datapulse.Application.Contact.Query.GetContact.ContactVm;
import com.datapulse.Application.Contact.Query.GetContact.GetContactQuery;
import com.datapulse.Application.Contact.Request.CreateContactRequest;
import com.datapulse.Application.Contact.Request.DeleteContactCommand;
import com.datapulse.Application.Contact.Request.UpdateContactRequest;
import com.datapulse.Mediator.Mediator;
import org.springframework.web.bind.annotation.*;

@RestController
public class ContactController {
	
	private Mediator _mediator;
	
	//public DomainEventService domainEventService; 
		
	public ContactController(Mediator _mediator) {
		
		this._mediator = _mediator;	
		
	}

	@PostMapping("/Create")

	public Integer Create(@RequestBody CreateContactRequest request) {
		//return this.contactDataAccess.AddContact(request);
	
	   return	_mediator.send(request);
			
		
	}
	
	// Get all Value from DataBase
	@GetMapping("/GetContact")
	public ContactVm getAllContact(){


		return _mediator.send(new GetContactQuery());

	}

	@DeleteMapping("/Delete")
	public Integer Delete(@PathVariable int Id)
     {
          return _mediator.send(new DeleteContactCommand(Id));

     }

	@PutMapping("/Update")
	public Integer  Update( @RequestBody UpdateContactRequest request){
		 return _mediator.send(request);


	}
	
	
	
	
	
	
	

}
