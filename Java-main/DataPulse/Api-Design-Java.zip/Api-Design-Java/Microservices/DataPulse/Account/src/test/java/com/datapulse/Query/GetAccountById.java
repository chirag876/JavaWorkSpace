package com.datapulse.Query;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertAll;

public class GetAccountById extends AccountApplicationTests {

    @Autowired
    public IAccount dataAccess;


    @Test
    public void GetAccountById(){

        Account account = dataAccess.GetById("789637");

        assertAll(

                () -> Assertions.assertEquals("789637", account.getId()),
                () -> Assertions.assertEquals("string", account.getName())
        );
    }
}
