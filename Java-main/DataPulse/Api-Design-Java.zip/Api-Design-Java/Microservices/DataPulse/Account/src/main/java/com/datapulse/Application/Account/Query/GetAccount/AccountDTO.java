package com.datapulse.Application.Account.Query.GetAccount;

import com.datapulse.Application.Domain.Entity.Account.Contacts;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Data
@Setter
@Getter
public class AccountDTO {
//    ModelMapper mapper = new ModelMapper();
//    @Autowired
//    private Account account;

    private String id;
    private String name;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String zipCode;
    private String phoneNumber;
    private String phoneExtension;
    private Long industryId;
    List<Contacts> contactsList = new ArrayList<>();




}
