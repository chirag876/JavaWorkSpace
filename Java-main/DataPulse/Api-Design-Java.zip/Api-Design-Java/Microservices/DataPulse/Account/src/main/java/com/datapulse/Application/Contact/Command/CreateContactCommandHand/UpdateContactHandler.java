package com.datapulse.Application.Contact.Command.CreateContactCommandHand;


import com.datapulse.Application.Common.Interface.IContact;
import com.datapulse.Application.Contact.Request.UpdateContactRequest;
import com.datapulse.Application.Domain.Entity.Contact;
import com.datapulse.Application.Domain.Events.Contact.ContactCreatedEvent;
import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class UpdateContactHandler implements RequestHandler<UpdateContactRequest, Integer> {

	@Autowired
	private IContact _dataAccess;
	Logger _logger = LoggerFactory.getLogger(UpdateContactHandler.class);	

	@Override
	public Integer handle(UpdateContactRequest request) {
		Contact entity = _dataAccess.GetById(request.getId());
		if(request.getId()!=0) {
			
			_logger.info("Id: "+request.getId(),"Name:"+ request.getName());
			
		
		entity.setName(request.getName());
		entity.setPhone(request.getPhone());
		
		entity.domainEvents().add(new ContactCreatedEvent(entity));
		
		_dataAccess.Update(entity);
		entity.domainEvents().add(new ContactCreatedEvent(entity));
		}
		return entity.getId();
		 
	}

	@Override
	public UUID uhandle(UpdateContactRequest request) {
		// TODO Auto-generated method stub
		return null;
	}	
	
	
	
}
