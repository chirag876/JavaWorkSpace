package com.datapulse.Command;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.test.util.AssertionErrors.assertEquals;

public class UpdateAccountRequestTest extends AccountApplicationTests {
    @Autowired
    public IAccount dataAccess;

    @Test
    public void testUpdateAccount(){

        Account account = new Account("119042", "Harry Y. Parker", "Street5454","North", "NY", "US", "80726", "4545454545", "+912",11145L);
        assertAll(() -> assertEquals("pass", account,account));
    }


}
