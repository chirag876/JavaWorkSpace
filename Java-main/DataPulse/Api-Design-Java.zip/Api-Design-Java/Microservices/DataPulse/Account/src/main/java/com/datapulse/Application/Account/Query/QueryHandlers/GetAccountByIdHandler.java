package com.datapulse.Application.Account.Query.QueryHandlers;

import com.datapulse.Application.Account.Query.GetAccount.AccountDTO;
import com.datapulse.Application.Account.Query.GetAccountById.GetAccountByIdQuery;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Mediator.RequestHandler;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;
@Component
public class GetAccountByIdHandler implements RequestHandler<GetAccountByIdQuery, AccountDTO> {

    Logger _logger = LoggerFactory.getLogger(GetAccountByIdHandler.class);
    ModelMapper mapper = new ModelMapper();
    @Autowired
    private IAccount _dataAcces;
    @Override
    public UUID uhandle(GetAccountByIdQuery request) {
        return null;
    }

    @Override
    public AccountDTO handle(GetAccountByIdQuery request) {
        _logger.info("GetAccountByIdQuery.Handle - In process");
        Account account = new Account();
        account =_dataAcces.GetById(request.getId());
        AccountDTO dto1 = mapper.map(account, AccountDTO.class);
        return dto1;

    }
}
