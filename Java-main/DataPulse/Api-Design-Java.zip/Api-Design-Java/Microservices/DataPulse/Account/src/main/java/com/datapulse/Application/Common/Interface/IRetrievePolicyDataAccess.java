package com.datapulse.Application.Common.Interface;//package com.datapulse.Application.Common.Interface;
//
//import java.util.List;
//import java.util.UUID;
//
//
//
//import org.springframework.stereotype.Repository;
//
//import com.datapulse.Application.Domain.Entity.RetrievePolicy;
//
//@Repository
//
//public interface IRetrievePolicyDataAccess {
//
//	public RetrievePolicy AddPolicy(RetrievePolicy retrievepolicy);
//
//	public List<RetrievePolicy> GetList();
//
//	public RetrievePolicy GetById(UUID id);
//
//	public RetrievePolicy Update(RetrievePolicy retrievepolicy);
//
//	UUID delete(UUID id);
//
//}
