package com.datapulse.API.Controller;

import com.datapulse.Application.Account.Query.GetAccount.AccountDTO;
import com.datapulse.Application.Account.Query.GetAccount.AccountVm;
import com.datapulse.Application.Account.Query.GetAccount.GetAccountQuery;
import com.datapulse.Application.Account.Query.GetAccountById.GetAccountByIdQuery;
import com.datapulse.Application.Account.Request.CreateAccountRequest;
import com.datapulse.Application.Account.Request.DeleteAccountRequest;
import com.datapulse.Application.Account.Request.UpdateAccountRequest;
import com.datapulse.Application.Common.Interface.IAccount;
import com.datapulse.Application.Domain.Entity.Account.Account;
import com.datapulse.Mediator.Mediator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("Account")
@CrossOrigin("*")
public class AccountController {

    private Mediator _mediator;
    @Autowired
    private IAccount _dataAccess;

    public AccountController(Mediator _mediator) { this._mediator = _mediator;  }



    @PostMapping("/Create")
    public String Create(@RequestBody CreateAccountRequest request) {
        //return this.contactDataAccess.AddContact(request);

        return	_mediator.send(request);


    }

    @GetMapping()
    public AccountVm getAllContact(){

        return _mediator.send(new GetAccountQuery());

    }

    @GetMapping("/{id}")
    public AccountDTO getContactById(@PathVariable String id){

        return _mediator.send(new GetAccountByIdQuery(id));

    }

    @PutMapping("/{id}")
    public String  Update(@PathVariable String id,
                          @RequestBody UpdateAccountRequest request){


        Account account = _dataAccess.GetById(id);

        if (account.getId().equals(id)){
            return _mediator.send(request);

        }
        return "User Not Found..";
    }

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable String id){
        return _mediator.send(new DeleteAccountRequest(id));
    }


}
