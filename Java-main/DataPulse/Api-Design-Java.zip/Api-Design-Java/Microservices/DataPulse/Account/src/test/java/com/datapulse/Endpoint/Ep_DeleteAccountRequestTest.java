package com.datapulse.Endpoint;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Account.Request.DeleteAccountRequest;
import org.junit.jupiter.api.Test;

public class Ep_DeleteAccountRequestTest extends AccountApplicationTests {


    @Test
    public void testAccountDelete(){

        DeleteAccountRequest request = new DeleteAccountRequest("119042");

         restTemplate.delete(baseUrl+"/119042");

    }
}
