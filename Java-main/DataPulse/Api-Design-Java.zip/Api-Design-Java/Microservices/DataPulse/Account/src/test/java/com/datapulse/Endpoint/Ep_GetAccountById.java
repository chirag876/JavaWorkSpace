package com.datapulse.Endpoint;

import com.datapulse.AccountApplicationTests;
import com.datapulse.Application.Account.Query.GetAccount.AccountDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;

public class Ep_GetAccountById extends AccountApplicationTests {


    @Test
    public void GetAccountById(){

        AccountDTO responce = restTemplate.getForObject(baseUrl + "/{id}", AccountDTO.class, "testId");

        assertAll(

                () -> Assertions.assertEquals("testId", responce.getId()),
                () -> Assertions.assertEquals("John mee", responce.getName())
        );
    }
}
