package com.datapulse.Application.Contact.Command.CreateContactCommandHand;


import com.datapulse.Application.Common.Interface.IContact;
import com.datapulse.Application.Contact.Request.DeleteContactCommand;
import com.datapulse.Application.Domain.Entity.Contact;
import com.datapulse.Mediator.RequestHandler;
import org.springframework.stereotype.Component;

import java.util.UUID;
@Component
public class DeleteContactHandler implements RequestHandler<DeleteContactCommand,Integer> {

	private IContact _dataAccess;

	@Override
	public Integer handle(DeleteContactCommand request) {
		
		Contact entity =  	_dataAccess.GetById(request.getId());
		if(entity.getId()!=0) {
			_dataAccess.Delete(request.getId());
		}
		return request.getId();
	}

	@Override
	public UUID uhandle(DeleteContactCommand request) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
