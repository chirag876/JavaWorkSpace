package com.datapulse.Application.Account.Query.GetAccount;

import com.datapulse.Mediator.Request;

public class GetAccountQuery implements Request<AccountVm> {
}
