package com.datapulse.Application.Domain.Events.Contact;


import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Contact;

public class ContactCreatedEvent extends DomainEvent {
	
	private Contact contact;

	public ContactCreatedEvent(Contact contact) {
		this.contact = contact;		
	}
	public Contact getContact() {
		return contact;
	}
	
}
