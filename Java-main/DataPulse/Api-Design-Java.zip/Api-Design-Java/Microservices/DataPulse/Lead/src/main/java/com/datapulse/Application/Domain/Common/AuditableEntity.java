package com.datapulse.Application.Domain.Common;

import lombok.*;

import java.time.OffsetDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter

public abstract class AuditableEntity {
    public String createdBy;
    public Date createdDateTime;
    public String updatedBy;
    public Date updatedDateTime;
    public String updateReason;
    public String ownerId;
    public boolean isActive;
    public boolean isDeleted;
    public boolean isApproved;
    public String approverId;
    public OffsetDateTime approvedDateTime;
    public Boolean isAuthorized;
    public String authorizedById;
    public OffsetDateTime authorizedDateTime;
    public String sysData;
    public String tenantId;
    public String subTenantId;

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public Date getUpdatedDateTime() {
        return updatedDateTime;
    }

    public String getUpdateReason() {
        return updateReason;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public boolean getIsActive() {
        return isActive;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public boolean getIsApproved() {
        return isApproved;
    }

    public String getApproverId() {
        return approverId;
    }

    public OffsetDateTime getApprovedDateTime() {
        return approvedDateTime;
    }

    public Boolean getAuthorized() {
        return isAuthorized;
    }

    public String getAuthorizedById() {
        return authorizedById;
    }

    public OffsetDateTime getAuthorizedDateTime() {
        return authorizedDateTime;
    }

    public String getSysData() {
        return sysData;
    }

    public String getTenantId() {
        return tenantId;
    }

    public String getSubTenantId() {
        return subTenantId;
    }
}
