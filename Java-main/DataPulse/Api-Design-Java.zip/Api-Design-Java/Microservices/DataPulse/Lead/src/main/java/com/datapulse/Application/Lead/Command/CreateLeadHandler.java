package com.datapulse.Application.Lead.Command;


import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Entity.Lead;

import com.datapulse.Application.Lead.Request.CreateLeadRequest;

import com.datapulse.Mediator.RequestHandler;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@Component
public class CreateLeadHandler implements RequestHandler<CreateLeadRequest, String> {

    //1. Logging Information In Process
    Logger logger = LoggerFactory.getLogger(CreateLeadHandler.class);


    @Autowired
    private ILead leadDataAccess;

    public CreateLeadHandler(ILead leadDataAccess) {
        this.leadDataAccess = leadDataAccess;
    }


    @Override
    public UUID uhandle(CreateLeadRequest request) {
        return null;
    }

    /// <summary>
    /// Handler will recieve request ,process it and will return the response.
    /// </summary>
    /// <param name="request"></param>

    @Override
    public String handle(CreateLeadRequest request) {
        //2. Assign requested Lead values
        Lead entity = new Lead();
        try {
            logger.info("CreateLeadRequest: " + request);
            //setter of Account Entity fields
            entity.setId(request.getId());
            entity.setFirstName(request.getFirstName());
            entity.setLastName(request.getLastName());
            entity.setCompany(request.getCompany());
            entity.setEmail(request.getEmail());
            entity.setLeadSource(request.getLeadSource());
            entity.setPhone(request.getPhone());
            entity.setTitle(request.getTitle());
            entity.setWebsite(request.getWebsite());
            entity.setAnnualRevenue(request.getAnnualRevenue());
            entity.setIndustry(request.getIndustry());
            entity.setCreatedDate(request.getCreatedDate());
            entity.setLeadStatus(request.getLeadStatus());

            // set Default for Auditable Entity
            entity.setCreatedDateTime(Date.from(Instant.now()));
            entity.setUpdatedDateTime(Date.from(Instant.now()));
            entity.setAuthorizedById("");
            entity.setOwnerId("");
            entity.setApproved(true);
            entity.setSysData("");
            entity.setTenantId("");
            entity.setUpdateReason("");
            entity.setSubTenantId("");





//            entity.domainEvents().add(new AccountCreatedEvent(entity));
            //3. Add requested value to lead
            leadDataAccess.AddLead(entity);

            //4. Logging Information Completed
            logger.info("CreateLeadRequest.handle: " + "Completed");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        //5. Return generated Id
        return entity.getId();
    }



}