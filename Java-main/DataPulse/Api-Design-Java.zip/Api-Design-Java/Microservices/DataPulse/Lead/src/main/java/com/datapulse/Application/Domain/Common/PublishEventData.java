package com.datapulse.Application.Domain.Common;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class PublishEventData extends PublishEventBase {
    public String CollectionName;
    public List<Property> Data;
    public PublishEventData(List<Property> Data){
        this.Data = Data;
    }

}
