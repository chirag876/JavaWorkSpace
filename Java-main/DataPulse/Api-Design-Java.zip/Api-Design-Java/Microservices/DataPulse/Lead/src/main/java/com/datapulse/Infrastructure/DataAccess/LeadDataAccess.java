package com.datapulse.Infrastructure.DataAccess;

import an.awesome.pipelinr.Pipeline;
import an.awesome.pipelinr.Pipelinr;
import com.datapulse.Application.Common.DAO.LeadDAO;
import com.datapulse.Application.Common.Interface.IDomainEventService;
import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Domain.Common.DomainEvent;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Domain.Events.LeadCreatedEvent;
import com.datapulse.Application.Domain.Events.LeadUpdatedEvent;
import com.datapulse.Application.Lead.EventHandler.LeadCreatedEventHandler;
import com.datapulse.Application.Lead.EventHandler.LeadUpdatedEventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Stream;

@Service
public class LeadDataAccess implements ILead {

    //1. Logging Information In Process
    Logger _logger = LoggerFactory.getLogger(LeadDataAccess.class);

    @Autowired
    private LeadDAO leadDAO;
    @Autowired
    private IDomainEventService domainEventService;

    @Override
    public Lead AddLead(Lead lead) {

        try {
            _logger.info("LeadDataAccess.AddLead - In process");

            // 2. Adding Data Into database
            leadDAO.save(lead);

            _logger.info("LeadDataAccess.AddLead - Completed");

        } catch (Exception ex) {
            _logger.error("LeadDataAccess.AddLead" + ex.getMessage());

        }
        DispatchEvents(lead);
        return lead;

    }


    // Get All

    @Override
    public List<Lead> GetList() {

        return leadDAO.findAll();
    }

    @Override
    public Lead GetById(String id) {

        try {
            _logger.info("LeadDataAccess.AddLead - In process");
            Lead lead =  leadDAO.findById(id).get();
            _logger.info("LeadDataAccess.GetById - Completed");
            return  lead;




        } catch (Exception ex) {
            _logger.error("LeadDataAccess.GetById" + ex.getMessage());

        }

        return leadDAO.findById(id).get();
    }

    @Override
    public Lead Update(Lead lead) {

        try {
            _logger.info("LeadDataAccess.Update - In process");


            leadDAO.save(lead);
            _logger.info("LeadDataAccess.Update - In Completed");
        } catch (Exception ex) {
            _logger.error("OpportunityDataAccess.Update" + ex.getMessage());

        }
        UpdateDispatchEvents(lead);

        return lead;
    }

    @Override
    public Lead Delete(String id) {
        return null;
    }


    // DispatchEvents

    public void DispatchEvents(Lead entity) {

        // Assuming you have a list of DomainEvent objects
//        List<DomainEvent> domainEvents = entity.;

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }

            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }

            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }

            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

//        domainEvents.add(domainEvent);


        domainEventService.Publish(domainEvent);

        _logger.info("Setting Pipeline for EventHandler");
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new LeadCreatedEventHandler())
        );

        LeadCreatedEvent opportunityCreatedEvent = new LeadCreatedEvent();
        opportunityCreatedEvent.setLead(entity);
        opportunityCreatedEvent.send(pipeline);

    }

    public void UpdateDispatchEvents(Lead entity) {

        // Assuming you have a list of DomainEvent objects
//        List<DomainEvent> domainEvents = entity.domainEvents();

        OffsetDateTime offsetDT = OffsetDateTime.now();


        DomainEvent domainEvent = new DomainEvent() {
            @Override
            public OffsetDateTime getDateOccured() {
                return super.getDateOccured();
            }

            @Override
            public void setDateOccured(OffsetDateTime dateOccured) {
                super.setDateOccured(dateOccured);
            }

            @Override
            public Boolean getIsPublished() {
                return super.getIsPublished();
            }

            @Override
            public void setIsPublished(Boolean isPublished) {
                super.setIsPublished(isPublished);
            }
        };
        domainEvent.setIsPublished(true);
        domainEvent.setDateOccured(offsetDT);

//        domainEvents.add(domainEvent);
        domainEventService.Publish(domainEvent);
        Pipeline pipeline = new Pipelinr().with(
                () -> Stream.of(new LeadUpdatedEventHandler())
        );

        LeadUpdatedEvent opportunityUpdatedEvent = new LeadUpdatedEvent();
        opportunityUpdatedEvent.setLead(entity);
        opportunityUpdatedEvent.send(pipeline);


    }
}
