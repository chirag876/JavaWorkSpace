package com.datapulse.API.Controller;

import com.datapulse.API.Configuration.ElasticsearchConfig;
import org.elasticsearch.ElasticsearchStatusException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;

@RestController
public class ElasticSearchController {

    @Autowired
   private ElasticsearchConfig config;

//    public ElasticSearchController(RestHighLevelClient elasticsearchClient) {
//        this.elasticsearchClient = elasticsearchClient;
//    }

    @GetMapping("/search")
    public SearchResponse searchElasticsearch( String query) {
        try {
            SearchRequest searchRequest = new SearchRequest("lead-stream-1");
            SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();

            MatchQueryBuilder matchQuery = QueryBuilders.matchQuery("EventName", query)
                    .operator(Operator.AND);

            sourceBuilder.query(matchQuery);
            searchRequest.source(sourceBuilder);

            return config.elasticsearchClient().search(searchRequest, RequestOptions.DEFAULT);
        } catch (ElasticsearchStatusException ese) {
            // Handle Elasticsearch-specific exceptions here
            ese.printStackTrace();
            return null;
        } catch (IOException ioe) {
            // Handle IO-related exceptions here
            ioe.printStackTrace();
            return null;
        } catch (Exception e) {
            // Handle other exceptions here
            e.printStackTrace();
            return null;
        }
    }
}