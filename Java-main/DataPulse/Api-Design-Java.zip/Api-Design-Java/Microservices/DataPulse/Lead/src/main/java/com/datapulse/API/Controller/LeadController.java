package com.datapulse.API.Controller;

import com.datapulse.Application.Common.Interface.ILead;
import com.datapulse.Application.Common.Interface.TrackExecutionTime;
import com.datapulse.Application.Domain.Entity.Lead;
import com.datapulse.Application.Lead.Query.GetLead.GetLeadQuery;
import com.datapulse.Application.Lead.Query.GetLead.LeadDTO;
import com.datapulse.Application.Lead.Query.GetLead.LeadVm;
import com.datapulse.Application.Lead.Query.GetLeadById.GetLeadByIdQuery;
import com.datapulse.Application.Lead.Request.CreateLeadRequest;
import com.datapulse.Application.Lead.Request.DeleteLeadRequest;
import com.datapulse.Application.Lead.Request.UpdateLeadRequest;
import com.datapulse.Infrastructure.DataAccess.LeadDataAccess;
import com.datapulse.Mediator.Mediator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("Lead")
@CrossOrigin("*")
@CacheConfig(cacheNames = "LeadCache")
public class LeadController {
    private Mediator _mediator;

    @Autowired
    private ILead _dataAccess;

    public LeadController(Mediator _mediator) { this._mediator = _mediator;  }

    /// <summary>
    /// Create Lead
    /// </summary>
    /// <param name="request">request</param>

    @PostMapping("/Create")
    @TrackExecutionTime
    public String Create(@RequestBody CreateLeadRequest request) {

        // mediator's send method will call the CreateLeadRequest to create a Lead

        return	_mediator.send(request);


    }
    /// <summary>
    /// Get Lead list
    /// </summary>
    /// <returns>Lead</returns>

    @Cacheable
    @GetMapping()
    @TrackExecutionTime
    public LeadVm getAllContact(){
        // mediator's send method will call the GetLeadListQuery for reading Lead

        return _mediator.send(new GetLeadQuery());

    }
    /// <summary>
    /// Get Lead By id
    /// </summary>
    /// <returns>Lead</returns>

    @Cacheable
    @GetMapping("/{id}")
    @TrackExecutionTime
    public LeadDTO getContactById(@PathVariable String id){

        // mediator's send method will call the GetLeadListQuery for reading Lead
        return _mediator.send(new GetLeadByIdQuery(id));

    }


    /// <summary>
    /// Update Lead
    /// </summary>
    /// <param name="id"></param>
    /// <param name="request"></param>
    @PutMapping("/{id}")
    @TrackExecutionTime
    public String  Update(@PathVariable String id,  @RequestBody UpdateLeadRequest request){

        Lead lead = _dataAccess.GetById(id);

        if (lead.getId().equals(id)){
            return _mediator.send(request);

        }
        return "User Not Found..";
    }

    /// <summary>
    /// Delete Lead By id
    /// </summary>
    /// <returns>Lead</returns>

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable String id){
        return _mediator.send(new DeleteLeadRequest(id));
    }



}
