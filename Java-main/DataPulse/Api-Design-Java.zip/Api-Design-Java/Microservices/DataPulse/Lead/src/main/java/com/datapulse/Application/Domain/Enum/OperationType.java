package com.datapulse.Application.Domain.Enum;

public enum OperationType {

    INSERT,
    UPDATE,
    DELETE

}
