package com.datapulse.Application.Lead.Command;

import com.datapulse.Application.Common.Interface.ILead;

import com.datapulse.Application.Domain.Entity.Lead;

import com.datapulse.Application.Lead.Request.DeleteLeadRequest;

import com.datapulse.Mediator.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class DeleteLeadHandler implements RequestHandler<DeleteLeadRequest, String> {

    //1. Logging Information In Process
    Logger logger = LoggerFactory.getLogger(DeleteLeadHandler.class);


    @Autowired
    private ILead leadDataAccess;
    @Override
    public UUID uhandle(DeleteLeadRequest request) {
        return null;
    }

    @Override
    public String handle(DeleteLeadRequest request) {

        logger.info("DeleteLeadHandler: " + request);

        Lead dto =  this.leadDataAccess.GetById(request.getId());
        if (dto.getId().equals(request.getId())){

        }

        logger.info("DeleteLeadRequest.Handle - Completed");

        return request.getId();
    }
}
