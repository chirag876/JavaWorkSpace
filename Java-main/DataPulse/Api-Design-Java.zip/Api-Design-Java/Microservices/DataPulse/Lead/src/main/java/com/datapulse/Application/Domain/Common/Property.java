package com.datapulse.Application.Domain.Common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Property {
    public String PropertyName;
    public String NewValue;
    public String OldValue;
}
