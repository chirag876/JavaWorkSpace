package com.datapulse.Application.Lead.Query.GetLead;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class LeadDTO {
    private String id;
    private String firstName;
    private String lastName;
    private String phone;
    private String company;
    private String title;
    private String leadSource;
    private String email;
    private String leadStatus;
    private String website;
    private String industry;
    private Double annualRevenue;
    private String createdDate;
}
